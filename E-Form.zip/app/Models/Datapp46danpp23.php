<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Datapp46danpp23 extends Model
{
    use HasFactory;
    protected $fillable = ['pp46danpp23_id','npwp','masa_pajak','alamat','peredaran_bruto','jumlahPPhFinal_dibayar'];
    public $timestamps = true;
}