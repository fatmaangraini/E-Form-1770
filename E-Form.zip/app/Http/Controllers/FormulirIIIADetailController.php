<?php

namespace App\Http\Controllers;
use App\Models\FormulirIIIADetail;
use App\Models\FormulirIII;



use Illuminate\Http\Request;

class FormulirIIIADetailController extends Controller
{
    //
}
