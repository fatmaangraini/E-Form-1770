<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FormulirI2BPointController extends Controller
{
    //
}
