<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TreasureController extends Controller
{
    //
}
