<?php

namespace App\Http\Controllers;

use App\Models\DataHarta;
use App\Models\DataUtang;
use App\Models\DataKel;
use App\Models\DataPotongPungut;
use App\Models\Datapp46danpp23;
use App\Models\Form;
use App\Models\FormSpt;
use App\Models\FormulirIV;
use App\Models\FormulirIII;
use App\Models\FormulirII;
use App\Models\pp46danpp23;
use App\Models\Treasure;
use App\Models\FormulirIIIA_Detail;
use App\Models\FormulirIIIB_Detail;
use App\Models\FormulirI;
use App\Models\Audit;
use App\Models\FormulirI2;
use App\Models\FormulirI2B_Detail;
use App\Models\FormulirI_Detail;
use App\Models\FormulirIIIC_Detail;
use Illuminate\Http\Request;

class FormController extends Controller
{
    //
    public function arsip()
    {
        $data = [
            'nama' => auth()->user()->name
        ];
        return view('arsip', $data);
    }
    public function index()
    {
        $data = [
            'npwp' => auth()->user()->npwp,
            'nama' => auth()->user()->name
        ];
        return view('formulir-IV', $data);
    }
    public function formulir4()
    {

        $spt = FormSpt::latest()->first();
        $form4 = FormulirIV::latest()->first();
        $data_harta = DataHarta::where('formuliriv_id', $form4->id)->get();
        $data_utang = DataUtang::where('formuliriv_id', $form4->id)->get();
        $data_kel = DataKel::where('formuliriv_id', $form4->id)->get();
        $data = [
            'spt' =>  $spt,
            'data_harta' => $data_harta,
            'data_utang' => $data_utang,
            'data_kel' => $data_kel,
            'npwp' => auth()->user()->npwp,
            'nama' => auth()->user()->name
        ];
        // dd($data);
        return view('formulir-IV', $data);
    }
    public function formulir3()
    {
        $spt = FormSpt::latest()->first();
        $form3 = FormulirIII::latest()->first();
        $formulir_iiia = FormulirIIIA_Detail::where('formuliriii_id', $form3->id)->get();
        $formulir_iiib = FormulirIIIB_Detail::where('formuliriii_id', $form3->id)->get();
        $formulir_iiic = FormulirIIIC_Detail::where('formuliriii_id', $form3->id)->get();

        //    return  response()->json($formulir_iiia,200);
        $data = [
            'spt' =>  $spt,
            'formulir_iiia' => $formulir_iiia,
            'formulir_iiib' => $formulir_iiib,
            'formulir_iiic' => $formulir_iiic,

            'npwp' => auth()->user()->npwp,
            'nama' => auth()->user()->name
        ];
        return view('formulir-III', $data);
    }
    public function formulir2()
    {
        $spt = FormSpt::latest()->first();
        $form2 = FormulirII::latest()->first();
        $data_potong_pungut = DataPotongPungut::where('formulirii_id', $form2->id)->get();
        $data = [
            'spt' =>  $spt,
            'data_potong_pungut' => $data_potong_pungut,
            'npwp' => auth()->user()->npwp,
            'nama' => auth()->user()->name
        ];
        return view('formulir-II', $data);
    }
    public function formulir1()
    {
        $spt = FormSpt::latest()->first();
        $form1 = FormulirI::latest()->first();
        $audit = Audit::where('formuliri_id', $form1->id)->get();
        $formuliri = FormulirI_Detail::where('formuliri_id', $form1->id)->get();
        $data = [
            'spt' =>  $spt,
            'audit' => $audit,
            'formuliri' => $formuliri,
            'npwp' => auth()->user()->npwp,
            'nama' => auth()->user()->name
        ];
        return view('formulir-I', $data);
    }
    public function formulir1_2()
    {
        $spt = FormSpt::latest()->first();
        $form1_2 = FormulirI2::latest()->first();
        $formulir_i2b = FormulirI2B_Detail::where('formuliri2_id', $form1_2->id)->get();
        // dd($formulir_i2b);
        $data = [
            'spt' =>  $spt,
            'formulir_i2b' => $formulir_i2b,

            'npwp' => auth()->user()->npwp,
            'nama' => auth()->user()->name
        ];
        return view('formulir-I hal 2', $data);
    }
    public function PP46()
    {
        // $form2 = pp46danpp23::latest()->first();
        $datadaftarpp4623 = Datapp46danpp23::get();
        $data = [
            'datadaftarpp4623' => $datadaftarpp4623,
            'npwp' => auth()->user()->npwp,
            'nama' => auth()->user()->name
        ];
        return view('PP46atau23', $data);
    }
    public function formulir()
    {
        $spt = FormSpt::latest()->first();
        // dd(response()->json($spt));
        $data = [
            'spt' =>  $spt,
            'npwp' => auth()->user()->npwp,
            'nama' => auth()->user()->name
        ];
        return view('formulir1770', $data);
    }
    public function addform(Request $request)
    {
        $i = 0;
        $data = [];
        // dd($request->all());
        if ($request->post()) {
            $form = new Form();
            $form->name = $request->name;
            $form->nik = $request->nik;
            $form->tempat_lahir = $request->tempat_lahir;
            $form->tahun_lahir = $request->tanggal_lahir;
            $form->npwp = $request->npwp;
            $form->tahun = $request->tahun;
            $form->jenis_pelaporan = $request->jenis_pelaporan;
            $form->pembetulan = $request->pembetulan ? $request->pembetulan : 0;
            $form->save();

            $form = Form::orderBy('id', 'DESC')->first();
            for ($i; $i < count($request->choice); $i++) {
                array_push($data, [
                    'choice' => $request->choice[$i],
                    'name_treasure' => $request->name_treasure[$i],
                    'acquisition_year' => $request->acquisition_year[$i],
                    'acquisition_cost' => $request->acquisition_cost[$i],
                    'description' => $request->description[$i],
                    'form_id' => $form->id
                ]);
            }
            Treasure::insert($data);
            // $treasure = new Treasure();
            // $treasure->choice = $request->choice;
            // $treasure->name_treasure = $request->name_treasure;
            // $treasure->acquisition_year = $request->acquisition_year;
            // $treasure->acquisition_cost = $request->acquisition_cost;
            // $treasure->description = $request->description;
            // $treasure->save();
        }
    }
    public function prosestambahspt(Request $request)
    {
        $data = $request->all();
        // dd($data);
        // FormSpt::insert([
        //     'tahun' => $data['tahun'],
        //     'status_spt' => $data['status_spt'],
        //     'pembetulan' => $data['pembetulan'] ?? 0,
        //     'media_pengiriman_token' => $data['media_pengiriman_token'],

        // ]);
        $form  = new FormSpt();
        $form->tahun = $data['tahun'];
        $form->status_spt = $data['status_spt'];
        $form->pembetulan = $data['pembetulan'] ?? 0;
        $form->media_pengiriman_token = $data['media_pengiriman_token'];
        $form->save();
        return redirect('formulir-IV');
    }
}
