<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use App\Imports\DataDaftar4623Import;
use App\Models\Datapp46danpp23;
use App\Models\pp46danpp23;


class PP46danPP23Controller extends Controller
{
    public function importexcel(Request $request)
    {
        $data = $request->file('file');

        $namafile = rand().$data->getClientOriginalName();
        $data->move('DaftarPP4623', $namafile);
        Excel::import(new DataDaftar4623Import, public_path('/DaftarPP4623/'.$namafile));
        return redirect()->back();
    }
    public function store (Request $request){
        $lastform = pp46danpp23::orderBy('id', 'desc')->first();
        $datadaftarpp4623 = new Datapp46danpp23();
        $datadaftarpp4623->pp46danpp23_id = $lastform->id;
        $datadaftarpp4623->npwp = $request->npwp;
        $datadaftarpp4623->masa_pajak = $request->masa_pajak;
        $datadaftarpp4623->alamat = $request->alamat;
        $datadaftarpp4623->peredaran_bruto = $request->peredaran_bruto;
        $datadaftarpp4623->jumlahPPhFinal_dibayar = $request->jumlahPPhFinal_dibayar;
        $datadaftarpp4623->save();
        return response()->json('berhasil',200);
    }
    public function delete(){
        $lastId = Datapp46danpp23::orderBy('id','desc')->first();
        // return response()->json($lastId,200);
       
        $datadaftarpp4623 = Datapp46danpp23::find($lastId->id);
        $datadaftarpp4623->delete();
        return response()->json('berhasil',200);
    }

    public function save(Request $request){
        $i = 0;
        $data = [];
        $lastform = pp46danpp23::orderBy('id', 'desc')->first();
        if ((int) $request->counted > 0){
            $i = (int) $request->counted;
        }

        for ($i; $i < count($request->npwp); $i++){
            $tmp = [
                'pp46danpp23_id' => $lastform->id,
                'npwp' => $request->npwp[$i],
                'masa_pajak' => $request->masa_pajak[$i],
                'alamat' => $request->alamat[$i],
                'peredaran_bruto' => $request->peredaran_bruto[$i],
                'jumlahPPhFinal_dibayar' => $request->jumlahPPhFinal_dibayar[$i],
                'created_at' => date('Y-m-d H:i:s', time()),
                'updated_at' => date('Y-m-d H:i:s', time()),

            ];
            array_push($data, $tmp);
        }
        if (count($data) > 0){
            $datadaftarpp4623 = Datapp46danpp23::insert($data);
        }
        return redirect('PP46atau23');
    }
}