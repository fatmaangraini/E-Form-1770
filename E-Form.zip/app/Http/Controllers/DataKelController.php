<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\DataKel;
use App\Models\FormulirIV;

class DataKelController extends Controller
{
    public function store (Request $request){
        $lastform = FormulirIV::orderBy('id', 'desc')->first();

        $datakel = new DataKel();
        $datakel->formuliriv_id = $lastform->id;
        $datakel->nama_anggota_kel = $request->nama_anggota_kel;
        $datakel->nik = $request->nik;
        $datakel->hubungan = $request->hubungan;
        $datakel->pekerjaan = $request->pekerjaan;
        $datakel->save();
        return response()->json('berhasil',200);
    }

    public function delete(){
        $lastId = DataKel::orderBy('id','desc')->first();
        $datakel = DataKel::find($lastId->id);
        $datakel->delete();
        return response()->json('berhasil',200);

    }

    public function save(Request $request){
        $i = 0;
        $data = [];
        $lastform = FormulirIV::orderBy('id', 'desc')->first();

        if ((int) $request->counted > 0) {
            $i = (int) $request->counted;
        }
        for ($i; $i < count($request->nama_anggota_kel); $i++) {
            $tmp = [
                'formuliriv_id' => $lastform->id,
                'nama_anggota_kel' => $request->nama_anggota_kel[$i],
                'nik' => $request->nik[$i],
                'hubungan' => $request->hubungan[$i],
                'pekerjaan' => $request->pekerjaan[$i],
                'created_at' => date('Y-m-d H:i:s', time()),
                'updated_at' => date('Y-m-d H:i:s', time()),
            ];
            array_push($data, $tmp);
        }
        if (count($data) > 0) {
            $datakel = DataKel::insert($data);
        }
        // dd($data);
        return redirect('formulir-IV');
    }
}
