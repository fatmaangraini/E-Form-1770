<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use App\Imports\DataPotongPungutImport;
use App\Models\DataPotongPungut;
use App\Models\FormulirII;

use function GuzzleHttp\Promise\all;

class DataPotongPungutController extends Controller
{
    public function importexcel(Request $request)
    {
        $data = $request->file('file');

        $namafile = rand().$data->getClientOriginalName();
        $data->move('PotongPungutData', $namafile);
        Excel::import(new DataPotongPungutImport, public_path('/PotongPungutData/'.$namafile));
        return redirect()->back();
    }
    public function store (Request $request){
        $lastform = FormulirII::orderBy('id', 'desc')->first();
        $datapotongpungut = new DataPotongPungut();
        $datapotongpungut->formulirii_id = $lastform->id;
        $datapotongpungut->nama_pemotong = $request->nama_pemotong;
        $datapotongpungut->npwp_pemotong = $request->npwp_pemotong;
        $datapotongpungut->nomor_bupot = $request->nomor_bupot;
        $datapotongpungut->tgl_bupot = $request->tgl_bupot;
        $datapotongpungut->jenis_pajak = $request->jenis_pajak;
        $datapotongpungut->jumlahPPh_potong = $request->jumlahPPh_potong;
        $datapotongpungut->save();
        return response()->json('berhasil',200);
    }
    public function delete(){
        $lastId = DataPotongPungut::orderBy('id','desc')->first();
        $datapotongpungut = DataPotongPungut::find($lastId->id);
        $datapotongpungut->delete();
        return response()->json('berhasil',200);

    }

    public function save(Request $request){
        $i = 0;
        $data = [];
        $lastform = FormulirII::orderBy('id', 'desc')->first();

        if ((int) $request->counted > 0) {
            $i = (int) $request->counted;
        }
        for ($i; $i < count($request->nama_pemotong); $i++) {
            $tmp = [
                'formulirii_id' => $lastform->id,
                'nama_pemotong' => $request->nama_pemotong[$i],
                'npwp_pemotong' => $request->npwp_pemotong[$i],
                'nomor_bupot' => $request->nomor_bupot[$i],
                'tgl_bupot' => $request->tgl_bupot[$i],
                'jenis_pajak' => $request->jenis_pajak[$i],
                'jumlahPPh_potong' => $request->jumlahPPh_potong[$i],
                'created_at' => date('Y-m-d H:i:s', time()),
                'updated_at' => date('Y-m-d H:i:s', time()),
            ];
            array_push($data, $tmp);
        }
        if (count($data) > 0) {
            $datapotongpungut = DataPotongPungut::insert($data);
        }
        return redirect('formulir-II');
    }
}