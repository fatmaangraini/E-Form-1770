<?php

namespace App\Http\Controllers;

use App\Models\FormulirI2;
use App\Models\FormulirI2B_Detail;
use Illuminate\Http\Request;

class FormulirI2Controller extends Controller
{
    public function store(Request $request)
    {
        $lastform = FormulirI2::orderBy('id', 'desc')->first();
        // dd($request->all());
        $data = [
            [
                'formuliri2_id' => $lastform->id,
                'formuliri2b_point' => 1,
                'rupiah_peredaran_usaha' => $request->PeredaranUsaha[0],
                'norma' => $request->Norma[0] ? $request->Norma[0] : '0',
                'rupiah_penghasilan_neto' => $request->PenghasilanNeto[0] ? $request->PenghasilanNeto[0] : '0',
            ],
            [
                'formuliri2_id' => $lastform->id,
                'formuliri2b_point' => 2,
                'rupiah_peredaran_usaha' => $request->PeredaranUsaha[1],
                'norma' => $request->Norma[1] ? $request->Norma[1] : '0',
                'rupiah_penghasilan_neto' => $request->PenghasilanNeto[1] ? $request->PenghasilanNeto[1] : '0',
            ],
            [
                'formuliri2_id' => $lastform->id,
                'formuliri2b_point' => 3,
                'rupiah_peredaran_usaha' => $request->PeredaranUsaha[2],
                'norma' => $request->Norma[2] ? $request->Norma[2] : '0',
                'rupiah_penghasilan_neto' => $request->PenghasilanNeto[2] ? $request->PenghasilanNeto[2] : '0',
            ],
            [
                'formuliri2_id' => $lastform->id,
                'formuliri2b_point' => 4,
                'rupiah_peredaran_usaha' => $request->PeredaranUsaha[3],
                'norma' => $request->Norma[3] ? $request->Norma[3] : '0',
                'rupiah_penghasilan_neto' => $request->PenghasilanNeto[3] ? $request->PenghasilanNeto[3] : '0',
            ],
            [
                'formuliri2_id' => $lastform->id,
                'formuliri2b_point' => 5,
                'rupiah_peredaran_usaha' => $request->PeredaranUsaha[4],
                'norma' => $request->Norma[4] ? $request->Norma[4] : '0',
                'rupiah_penghasilan_neto' => $request->PenghasilanNeto[4] ? $request->PenghasilanNeto[4] : '0',
            ],
        ];
        $i2bpointdetail = new FormulirI2B_Detail;
        $i2bpointdetail->insert($data);
        return response()->json('berhasil', 200);
    }

    public function delete()
    {
        $lastId = FormulirI2::orderBy('id', 'desc')->first();
        $formulir_i2b = FormulirI2B_Detail::where('formuliri2_id', $lastId->id);
        $formulir_i2b->delete();
        return response()->json('berhasil', 200);
    }
}
