<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FormulirIPointController extends Controller
{
    //
}
