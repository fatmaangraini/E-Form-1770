<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FormulirIDetailController extends Controller
{
    //
}
