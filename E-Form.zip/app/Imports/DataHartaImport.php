<?php

namespace App\Imports;

use App\Models\DataHarta;
use App\Models\FormulirIV;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithStartRow;
use Maatwebsite\Excel\Concerns\WithCustomCsvSettings;

class DataHartaImport implements ToModel, WithStartRow
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        $lastform = FormulirIV::orderBy('id', 'desc')->first();
        return new DataHarta([
            'formuliriv_id' => $lastform->id,
            'kode_harta' => $row[0],
            'nama_harta' => $row[1],
            'tahun_perolehan' => $row[2],
            'harta_perolehan' => $row[3],
            'keterangan' => $row[4],
        ]);
    }
    public function startRow(): int
    {
        return 2;
    }
}
