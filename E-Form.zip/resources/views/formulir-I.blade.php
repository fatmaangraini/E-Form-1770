<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}" />


    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js" integrity="sha512-aVKKRRi/Q/YV+4mjoKBsE4x3H+BkegoM/em46NNlCqNTmUYADjBbeNefNxYV7giUp0VxICtqdrbqU7iVaeZNXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <title>Formulir 1770-I</title>
    <style>
        .bg-grey {
            font-family: arial;
            background-color: #ccc;
        }

        .vericaltext {
            writing-mode: vertical-lr;
            text-orientation: use-glyph-orientation;
        }

        .year {
            border: 1px solid black;
            width: 20px;
            font-size: 25px;
        }

        table tr th {
            border: 1px solid black;
            font-size: 25px;
        }
    </style>
</head>

<body class="bg-grey" style="padding: 1% 10% 1% 10%">
    <div class="container " style="width: 90%; background-color: #fff">
        <div class="row" style="border-bottom: 2px solid black;">
            <div class="col-2" style="padding: 50px 0px 10px 10px">
                <h6 style="font-size: 10px; font-weight: bold; text-align: center; margin-top: -30px">HALAMAN 1</h6>
                <h1 style="font-size: 20px; font-weight: bold; text-align: center;">FORMULIR</h1>
                <h1 style="font-size: 40px; font-weight: bold; text-align: center; margin-top: 30px">1770-I</h1>
                <p style="font-size: 10px; font-weight: bold; text-align: center; margin-top: 30px">KEMENTERIAN KEUANGAN
                    RI DIREKTORAT JENDERAL PAJAK
                </p>
            </div>
            <div class="col-6" style="border-left: 2px solid black; border-right:2px solid black;">
                <div class="row">
                    <b style="font-size: 18px; text-align: center;">LAMPIRAN-I</b>
                    <p style=" font-size: 18px; font-weight: bold;  text-align: center; border-bottom: 2px solid black">
                        SPT TAHUNAN PPh WAJIB PAJAK ORANG PRIBADI</p>
                </div>
                <div class="row" style="font-size: 12px; text-align:center">
                    <b>PERHITUNGAN PENGHASILAN NETO DALAM NEGERI DARI USAHA DAN/ATAU</b>
                    <b>PEKERJAAN BEBAS BAGI WAJIB PAJAK YANG</b>
                    <b>MENYELENGGARAKAN PEMBUKUAN</b>
                </div>
            </div>

            <div class="col-4" style="padding: 10px 10px 10px 10px">
                <!-- <b class="vericaltext fs-7">
                    TAHUN PAJAK
                </b> -->
                <form action="/formulir-I hal 2">
                    @csrf
                    <input type="hidden" name="hasil" value="{{ request()->all()['hasil'] ?? 0 }}">
                    <input type="hidden" name="hasilPPhDipotongDipungut" value="{{ request()->all()['hasilPPhDipotongDipungut'] ?? 0 }}">
                    <a href="/formulir-II" class="btn btn-secondary" style="font-size: 12px; width: 120px; height: 30px; margin-left: 10px">Sebelumnya</a>
                    <button type="submit" class="btn btn-secondary" style="font-size: 12px; width: 120px; height: 30px; margin-left: 10px; display:inline-block">Selanjutnya</button>
                    <div class="row" style="padding: 4% 10%;">
                        <div class="col">
                            <table>
                                <tr>
                                    <th style="text-align: center" width="60px">{{ mb_substr($spt['tahun'], 0, 1); }}</th>
                                    <th style="text-align: center" width="60px">{{ mb_substr($spt['tahun'], 1, 1); }}</th>
                                    <th style="text-align: center" width="60px">{{ mb_substr($spt['tahun'], 2, 1); }}</th>
                                    <th style="text-align: center" width="60px">{{ mb_substr($spt['tahun'], 3, 1); }}</th>
                                </tr>
                            </table>
                        </div>
                    </div>
                    <div class="row" style="padding: 1% 10%;">
                        <div class="col-4">
                            <table>
                                <tr>
                                    <th>0</th>
                                    <th>1</th>
                                    <th>{{ mb_substr($spt['tahun'], 2, 1); }}</th>
                                    <th>{{ mb_substr($spt['tahun'], 3, 1); }}</th>
                                </tr>
                            </table>
                        </div>
                        <div class="col-2">
                            <p style="margin: 15px;">sd</p>
                        </div>
                        <div class="col-4">
                            <table>
                                <tr>
                                    <th>1</th>
                                    <th>2</th>
                                    <th>{{ mb_substr($spt['tahun'], 2, 1); }}</th>
                                    <th>{{ mb_substr($spt['tahun'], 3, 1); }}</th>
                                </tr>
                            </table>
                        </div>
                    </div>

                    <div class="form-check" style="display:inline-block">
                        <input style="display:inline;" class="form-check-input" type="radio" name="pembukuan" checked onclick="Pembukuan()">
                        <label class="form-check-label" for="flexRadioDisabled" style="font-size: 14px;">
                            Pembukuan
                        </label>
                    </div>
                    <div class="form-check" style="display:inline-block">
                        <input class="form-check-input" type="radio" name="pembukuan" onclick="Pencatatan()">
                        <label class="form-check-label" for="flexRadioCheckedDisabled" style="font-size: 14px;">
                            Pencatatan
                        </label>
                    </div>
                    <div class="col-sm-12" style="background-color: #F0E68C ; padding: 4px 10px 10px 10px ; height: 30PX">
                        <div class="input-group mb-6">
                            <div class="input-group-prepend">
                                <div style="margin-left: -11px">
                                    <input type="checkbox" aria-label="Checkbox for following text input" style="width: 20px;">
                                </div>
                            </div>
                            <label class="col-sm-9" style="font-size: 11px; text-align: center">SPT Pembetulan Ke</label>
                            <input style="width:20px; height: 20px; border: 1px solid;">
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <b style="font-size: 10px;">PERHATIAN *SEBELUM MENGISI BACALAH PETUNJUK PENGISIAN *ISI DENGAN HURU CETAK/DIKETIK
            DENGAN TINTA HITAM *BERI TANDA X DALAM KOTAK SESUAI PILIHAN</b>

        <div class="col-sm-11.5" style=" border: 1px solid black; background-color: #F0E68C ; padding: 4px 20px 10px 10px ; height: 75px; border: 2px solid; margin-left: 10px">
            <div class="row">
                <label class="col-sm-4 col-form-label" style="font-size: 12px;">NPWP</label>
                <div class="col-sm-8">
                    <input class="form-control" type="text" style="border: 1px solid black; height: 30px; border-radius: 1px; " value="{{ $npwp }}" disabled="disabled" id="formatnpwpfix">
                </div>
            </div>
            <div class="row">
                <label class="col-sm-4 col-form-label" style="font-size: 12px;">NAMA WAJIB PAJAK</label>
                <div class="col-sm-8">
                    <input class="form-control" type="text" style="border: 1px solid black; height: 30px; border-radius: 1px;" value="{{ $nama }}" disabled="disabled">
                </div>
            </div>
        </div>
        <form action="/SaveAudit" method="POST">
            @csrf
            <input type="hidden" name="counted" value="{{ count($audit)  }}">
            <div style="padding: 10px">
                <p style="font-size: 11px; padding: 0px 0px -7px 0px">BAGIAN A. PENGHASILAN NETO DALAM NEGERI DARI USAHA
                    DAN/ATAU PEKERJAAN BEBAS
                    (BAGI WAJIB PAJAK YANG MENYELENGGARAKAN PEMBUKUAN)</p>
            </div>
            <div class="table" style=" border: 1px solid black; height: auto">
                <label style="font-size: 12px; margin-left: 5px">PEMBUKUAN/LAPORAN KEUANGAN</label>
                <div class="form-check" style="display:inline-block; margin-left: 15px">
                    <input style="display:inline;" class="form-check-input" type="radio" onchange="handleChange(this);" name="Audit" id="Audit">
                    <label class="form-check-label" for="flexRadioDisabled" style="font-size: 14px;">
                        Di Audit
                    </label>
                </div>
                <div class="form-check" style="display:inline-block; margin-left: 10px">
                    <input class="form-check-input" type="radio" name="Audit" onchange="handleChange2(this);" id="TidakAudit" checked>
                    <label class="form-check-label" for="flexRadioCheckedDisabled" style="font-size: 14px; ">
                        Tidak Di Audit
                    </label>
                </div>

                <div id="eformspt" style="display: none;">
                    <div class="row">
                        <label class="col-sm-3 col-form-label" style="font-size: 14px; margin-left: 5px">Opini
                            Akuntan</label>
                        <select class="col-sm-8" style="height: 32px; border: 1px solid black; font-size: 12px;" id="opini_akuntan">
                            <option selected>Pilih...</option>
                            <option value='1. Wajar Tanpa Pengecualian' <?php if ($audit[0]['opini_akuntan'] ?? false) {
                                                                            if ($audit[0]['opini_akuntan'] == "1. Wajar Tanpa Pengecualian") {
                                                                                echo "selected='selected'";
                                                                            }
                                                                        } ?>>1. Wajar Tanpa Pengecualian</option>
                            <option value='2. Wajar Dengan Pengecualian' <?php if ($audit[0]['opini_akuntan'] ?? false) {
                                                                                if ($audit[0]['opini_akuntan'] == "2. Wajar Dengan Pengecualian") {
                                                                                    echo "selected='selected'";
                                                                                }
                                                                            } ?>>2. Wajar Dengan Pengecualian</option>
                            <option value='3. Tidak Wajar' <?php if ($audit[0]['opini_akuntan'] ?? false) {
                                                                if ($audit[0]['opini_akuntan'] == "3. Tidak Wajar") {
                                                                    echo "selected='selected'";
                                                                }
                                                            } ?>>3. Tidak Wajar</option>
                            <option value='4. Tidak Ada Opini' <?php if ($audit[0]['opini_akuntan'] ?? false) {
                                                                    if ($audit[0]['opini_akuntan'] == "4. Tidak Ada Opini") {
                                                                        echo "selected='selected'";
                                                                    }
                                                                } ?>>4. Tidak Ada Opini</option>
                        </select>
                    </div>
                    <div class="row">
                        <label class="col-sm-3 col-form-label" style="font-size: 12px; margin-left: 5px">NAMA AKUNTAN
                            PUBLIK</label>
                        <div class="col-sm-8" style="padding: 1px;">
                            <input class="form-control" type="text" style="border: 1px solid black; height: 30px; border-radius: 1px; text-transform:uppercase" value="{{ $audit[0]['nama_AKpublik'] ?? '' }}" id="nama_AKpublik">
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-sm-3 col-form-label" style="font-size: 12px; margin-left: 5px">NPWP AKUNTAN
                            PUBLIK</label>
                        <div class="col-sm-8" style="padding: 1px;">
                            <input class="form-control" type="text" style="border: 1px solid black; height: 30px; border-radius: 1px; text-transform:uppercase" maxlength="20" oninput="formatNpwpAkuntan(this)" value="{{ $audit[0]['npwp_AKpublik'] ?? '' }}" id="npwp_AKpublik">
                        </div>
                    </div>
                    <script>
                        function formatNpwpAkuntan() {
                            npwp_AKpublik = document.getElementById('npwp_AKpublik').value
                            npwp_AKpublik2 = document.getElementById('npwp_AKpublik')
                            if (!npwp_AKpublik.match(/^[0-9./-]+$/i) && npwp_AKpublik2.value.length != 0) {
                                alert('Angka saja')
                                npwp_AKpublik2.value = npwp_AKpublik.slice(0, -1);
                                return;
                            }
                            npwp_AKpublik2.value = npwp_AKpublik.replace(/(\d{2})(\d{3})(\d{3})(\d{1})(\d{3})(\d{3})/, '$1.$2.$3.$4-$5.$6');
                        }

                        function formatNpwpKantorAkuntan() {
                            npwp_kantor_AKpublik = document.getElementById('npwp_kantor_AKpublik').value
                            npwp_kantor_AKpublik2 = document.getElementById('npwp_kantor_AKpublik')
                            if (!npwp_kantor_AKpublik.match(/^[0-9./-]+$/i) && npwp_kantor_AKpublik2.value.length != 0) {
                                alert('Angka saja')
                                npwp_kantor_AKpublik2.value = npwp_kantor_AKpublik.slice(0, -1);
                                return;
                            }
                            npwp_kantor_AKpublik2.value = npwp_kantor_AKpublik.replace(/(\d{2})(\d{3})(\d{3})(\d{1})(\d{3})(\d{3})/, '$1.$2.$3.$4-$5.$6');
                        }

                        function formatNpwpKonsultan() {
                            npwp_Kpajak = document.getElementById('npwp_Kpajak').value
                            npwp_Kpajak2 = document.getElementById('npwp_Kpajak')
                            if (!npwp_Kpajak.match(/^[0-9./-]+$/i) && npwp_Kpajak2.value.length != 0) {
                                alert('Angka saja')
                                npwp_Kpajak2.value = npwp_Kpajak.slice(0, -1);
                                return;
                            }
                            npwp_Kpajak2.value = npwp_Kpajak.replace(/(\d{2})(\d{3})(\d{3})(\d{1})(\d{3})(\d{3})/, '$1.$2.$3.$4-$5.$6');
                        }

                        function formatNpwpKantorKonsultan() {
                            npwp_kantor_Kpajak = document.getElementById('npwp_kantor_Kpajak').value
                            npwp_kantor_Kpajak2 = document.getElementById('npwp_kantor_Kpajak')
                            if (!npwp_kantor_Kpajak.match(/^[0-9./-]+$/i) && npwp_kantor_Kpajak2.value.length != 0) {
                                alert('Angka saja')
                                npwp_kantor_Kpajak2.value = npwp_kantor_Kpajak.slice(0, -1);
                                return;
                            }
                            npwp_kantor_Kpajak2.value = npwp_kantor_Kpajak.replace(/(\d{2})(\d{3})(\d{3})(\d{1})(\d{3})(\d{3})/, '$1.$2.$3.$4-$5.$6');
                        }
                    </script>
                    <div class="row">
                        <label class="col-sm-3 col-form-label" style="font-size: 12px; margin-left: 5px">NAMA KANTOR
                            AKUNTAN PUBLIK</label>
                        <div class="col-sm-8" style="padding: 1px;">
                            <input class="form-control" type="text" style="border: 1px solid black; height: 30px; border-radius: 1px; text-transform:uppercase" value="{{ $audit[0]['nama_kantor_AKpublik'] ?? '' }}" id="nama_kantor_AKpublik">
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-sm-3 col-form-label" style="font-size: 12px; margin-left: 5px">NPWP KANTOR
                            AKUNTAN PUBLIK</label>
                        <div class="col-sm-8" style="padding: 1px;">
                            <input class="form-control" type="text" style="border: 1px solid black; height: 30px; border-radius: 1px; text-transform:uppercase" maxlength="20" oninput="formatNpwpKantorAkuntan(this)" value="{{ $audit[0]['npwp_kantor_AKpublik'] ?? '' }}" id="npwp_kantor_AKpublik">
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-sm-3 col-form-label" style="font-size: 12px; margin-left: 5px">NAMA KONSULTAN
                            PAJAK</label>
                        <div class="col-sm-8" style="padding: 1px;">
                            <input class="form-control" type="text" style="border: 1px solid black; height: 30px; border-radius: 1px; text-transform:uppercase" value="{{ $audit[0]['nama_Kpajak'] ?? '' }}" id="nama_Kpajak">
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-sm-3 col-form-label" style="font-size: 12px; margin-left: 5px">NPWP KONSULTAN
                            PAJAK</label>
                        <div class="col-sm-8" style="padding: 1px;">
                            <input class="form-control" type="text" style="border: 1px solid black; height: 30px; border-radius: 1px; text-transform:uppercase" maxlength="20" oninput="formatNpwpKonsultan(this)" value="{{ $audit[0]['npwp_Kpajak'] ?? '' }}" id="npwp_Kpajak">
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-sm-3 col-form-label" style="font-size: 12px; margin-left: 5px">NAMA KANTOR
                            KONSULTAN PAJAK</label>
                        <div class="col-sm-8" style="padding: 1px;">
                            <input class="form-control" type="text" style="border: 1px solid black; height: 30px; border-radius: 1px; text-transform:uppercase" value="{{ $audit[0]['nama_kantor_Kpajak'] ?? '' }}" id="nama_kantor_Kpajak">
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-sm-3 col-form-label" style="font-size: 12px; margin-left: 5px">NPWP KANTOR
                            KONSULTAN PAJAK</label>
                        <div class="col-sm-8" style="padding: 1px;">
                            <input class="form-control" type="text" style="border: 1px solid black; height: 30px; border-radius: 1px; text-transform:uppercase" maxlength="20" oninput="formatNpwpKantorKonsultan(this)" value="{{ $audit[0]['npwp_kantor_Kpajak'] ?? '' }}" id="npwp_kantor_Kpajak">
                        </div>
                    </div>
                </div>
                <div id="eformspt2">
                    <div class="row">
                        <label class="col-sm-3 col-form-label" style="font-size: 12px; margin-left: 5px">NAMA AKUNTAN
                            PUBLIK</label>
                        <div class="col-sm-8" style="padding: 1px;">
                            <input class="form-control" type="text" style="border: 1px solid black; height: 30px; border-radius: 1px; background-color: #808080" disabled="disabled">
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-sm-3 col-form-label" style="font-size: 12px; margin-left: 5px">NPWP AKUNTAN
                            PUBLIK</label>
                        <div class="col-sm-8" style="padding: 1px;">
                            <input class="form-control" type="text" style="border: 1px solid black; height: 30px; border-radius: 1px; background-color: #808080" disabled="disabled">
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-sm-3 col-form-label" style="font-size: 12px; margin-left: 5px">NAMA KANTOR
                            AKUNTAN PUBLIK</label>
                        <div class="col-sm-8" style="padding: 1px;">
                            <input class="form-control" type="text" style="border: 1px solid black; height: 30px; border-radius: 1px; background-color: #808080" disabled="disabled">
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-sm-3 col-form-label" style="font-size: 12px; margin-left: 5px">NPWP KANTOR
                            AKUNTAN PUBLIK</label>
                        <div class="col-sm-8" style="padding: 1px;">
                            <input class="form-control" type="text" style="border: 1px solid black; height: 30px; border-radius: 1px; background-color: #808080" disabled="disabled">
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-sm-3 col-form-label" style="font-size: 12px; margin-left: 5px">NAMA KONSULTAN
                            PAJAK</label>
                        <div class="col-sm-8" style="padding: 1px;">
                            <input class="form-control" type="text" style="border: 1px solid black; height: 30px; border-radius: 1px; background-color: #808080" disabled="disabled">
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-sm-3 col-form-label" style="font-size: 12px; margin-left: 5px">NPWP KONSULTAN
                            PAJAK</label>
                        <div class="col-sm-8" style="padding: 1px;">
                            <input class="form-control" type="text" style="border: 1px solid black; height: 30px; border-radius: 1px; background-color: #808080" disabled="disabled">
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-sm-3 col-form-label" style="font-size: 12px; margin-left: 5px">NAMA KANTOR
                            KONSULTAN PAJAK</label>
                        <div class="col-sm-8" style="padding: 1px;">
                            <input class="form-control" type="text" style="border: 1px solid black; height: 30px; border-radius: 1px; background-color: #808080" disabled="disabled">
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-sm-3 col-form-label" style="font-size: 12px; margin-left: 5px">NPWP KANTOR
                            KONSULTAN PAJAK</label>
                        <div class="col-sm-8" style="padding: 1px;">
                            <input class="form-control" type="text" style="border: 1px solid black; height: 30px; border-radius: 1px; background-color: #808080">
                        </div>
                    </div>
                </div>
            </div>
        </form>

        <div id="tampil">
            <table style="width: 100%;">
                <tr>
                    <th style="width: 3%; border-bottom: 0px"></th>
                    <th style="width: 72%; font-size: 12px; border-bottom: 0px; border-right: 0px">PENGHASILAN DARI USAHA DAN/ATAU PEKERJAAN BEBAS BERDASARKAN LAPORAN KEUANGAN KOMERSIAL :</th>
                    <th style="width: 5%; border-bottom: 0px; border-left: 0px; border-right: 0px"></th>
                    <th style="width: 20%; font-size: 12px; text-align: center; border-bottom: 0px; border-left: 0px ">Rupiah</th>
                </tr>
                <tr>
                    <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px"></td>
                    <td style="border-bottom: 0px"> <span style="margin-left: 5px;  font-size: 12px">a. PEREDARAN USAHA</span></td>
                    <td style="border-left: 1px dotted black; border-top: 1px dotted black; border-bottom: 0px; font-size: 12px; text-align:center">1a.</td>
                    <td style="font-size: 12px; text-align: center; border: 1px solid black; border-bottom: 0px"><input value="{{ $formuliri[0]->rupiah_JenisPenghasilan ?? '' }}" type="text" class="form-control" style="width: 100%; height: 30px; border: 0px; text-align:right; font-size:14px" oninput="formatPengNetoDlmNegeri()" name="peredaran_usaha" id="peredaran_usaha" placeholder="0"></td>
                </tr>
                <tr>
                    <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px"></td>
                    <td style="border-bottom: 0px"><span style="margin-left: 5px;  font-size: 12px">b. HARGA POKOK PENJUALAN</span></td>
                    <td style="border-left: 1px dotted black; border-top: 1px solid black; border-bottom: 0px; font-size: 12px; text-align:center">1b.</td>
                    <td style="font-size: 12px; text-align: center; border: 1px solid black; border-bottom: 0px"><input value="{{ $formuliri[1]->rupiah_JenisPenghasilan ?? '' }}" type="text" class="form-control" style="width: 100%; height: 30px; border: 0px; text-align:right; font-size:14px" oninput="formatPengNetoDlmNegeri()" name="harga_pokok_penjualan" id="harga_pokok_penjualan" placeholder="0"></td>
                </tr>
                <tr>
                    <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px; font-size: 12px; text-align: center">1</td>
                    <td style="border-bottom: 0px"><span style="margin-left: 5px;  font-size: 12px">c. LABA/RUGI BRUTO USAHA (1a - 1b)</span></td>
                    <td style="border-left: 1px dotted black; border-top: 1px solid black; border-bottom: 0px; font-size: 12px; text-align:center">1c.</td>
                    <td style="font-size: 12px; text-align: center; border: 1px solid black; border-bottom: 0px; background-color: #F0E68C"><input type="text" disabled="true" readonly="readonly" style="width: 100%; height: 30px; border: 0px;background-color: #F0E68C; text-align:right; font-size:14px" name="hasil1c" id="hasil1c"></td>
                </tr>
                <tr>
                    <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px"></td>
                    <td style="border-bottom: 0px"><span style="margin-left: 5px;  font-size: 12px">d. BIAYA USAHA</span></td>
                    <td style="border-left: 1px dotted black; border-top: 1px solid black; border-bottom: 0px; font-size: 12px; text-align:center">1d.</td>
                    <td style="font-size: 12px; text-align: center; border: 1px solid black; border-bottom: 0px"><input value="{{ $formuliri[2]->rupiah_JenisPenghasilan ?? '' }}" type="text" class="form-control" style="width: 100%; height: 30px; border: 0px; text-align:right; font-size:14px" oninput="formatPengNetoDlmNegeri()" name="biaya_usaha" id="biaya_usaha" placeholder="0"></td>
                </tr>
                <tr>
                    <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px"></td>
                    <td style="border-bottom: 0px"><span style="margin-left: 5px;  font-size: 12px">e. PENGHASILAN NETO (1c - 1d)</span></td>
                    <td style="border-left: 1px dotted black; border-top: 1px solid black; border-bottom: 0px; font-size: 12px; text-align:center">1e.</td>
                    <td style="font-size: 12px; text-align: center; border: 1px solid black; border-bottom: 0px;background-color: #F0E68C"><input type="text" readonly="readonly" style="width: 100%; height: 30px; border: 0px;background-color: #F0E68C; text-align:right; font-size:14px" name="hasil1" id="hasil1"></td>
                </tr>
            </table>
            <table style="width: 100%;">
                <tr>
                    <th style="width: 3%; border-bottom: 0px"></th>
                    <th style="width: 72%; font-size: 12px; border-bottom: 0px; border-right: 0px">PENYESUAIAN FISIKAL POSITIF</th>
                    <th style="width: 5%; border-bottom: 0px; border-left: 0px; border-right: 0px"></th>
                    <th style="width: 20%; font-size: 12px; text-align: center; border-bottom: 0px;  border-left: 0px"></th>
                </tr>
                <tr>
                    <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px"></td>
                    <td style="border-bottom: 0px"> <span style="margin-left: 5px;  font-size: 12px">a. BIAYA YANG DIBEBANKAN /DIKELUARKAN UNTUK KEPENTINGAN RPIBADI WAJIB PAJAK ATAU ORANG YANG MENJADI TANGGUNGANNYA</span></td>
                    <td style="border-left: 1px dotted black; border-top: 1px dotted black; border-bottom: 0px; font-size: 12px; text-align:center">2a.</td>
                    <td style="font-size: 12px; text-align: center; border: 1px solid black; border-bottom: 0px"><input value="{{ $formuliri[3]->rupiah_JenisPenghasilan ?? '' }}" type="text" class="form-control" style="width: 100%; height: 40px; border: 0px; text-align:right; font-size:14px" oninput="formatPengNetoDlmNegeri()" name="biaya_dibebankan_dikeluarkan" id="biaya_dibebankan_dikeluarkan" placeholder="0"></td>
                </tr>
                <tr>
                    <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px"></td>
                    <td style="border-bottom: 0px"><span style="margin-left: 5px;  font-size: 12px">b. PREMI ASURANSI KESEHATAN, ASURANSI KECELAKAAN, ASURANSI JIWA, ASURANSI DWIGUNA, DAN ASURANSI BEASISWA YANG DIBAYAR OLEH WAJIB PAJAK</span></td>
                    <td style="border-left: 1px dotted black; border-top: 1px solid black; border-bottom: 0px; font-size: 12px; text-align:center">2b.</td>
                    <td style="font-size: 12px; text-align: center; border: 1px solid black; border-bottom: 0px"><input value="{{ $formuliri[4]->rupiah_JenisPenghasilan ?? '' }}" type="text" class="form-control" style="width: 100%; height: 40px; border: 0px; text-align:right; font-size:14px" oninput="formatPengNetoDlmNegeri()" name="premi_asuransi" id="premi_asuransi" placeholder="0"></td>
                </tr>
                <tr>
                    <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px"></td>
                    <td style="border-bottom: 0px"><span style="margin-left: 5px;  font-size: 12px">c. PENGGANTIAN ATAU IMBALAN SEHUBUNGAN DENGAN PEKERJAAN ATAU JASA YANG DIBERIKAN DALAM BENTUK NATURA ATAU KENIKMATAN</span></td>
                    <td style="border-left: 1px dotted black; border-top: 1px solid black; border-bottom: 0px; font-size: 12px; text-align:center">2c.</td>
                    <td style="font-size: 12px; text-align: center; border: 1px solid black; border-bottom: 0px"><input value="{{ $formuliri[5]->rupiah_JenisPenghasilan ?? '' }}" type="text" class="form-control" style="width: 100%; height: 40px; border: 0px; text-align:right; font-size:14px" oninput="formatPengNetoDlmNegeri()" name="penggantian_imbalan" id="penggantian_imbalan" placeholder="0"></td>
                </tr>
                <tr>
                    <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px"></td>
                    <td style="border-bottom: 0px"><span style="margin-left: 5px;  font-size: 12px">d. JUMLAH YANG MELEBIHI KEWAJARAN YANG DIBAYARKAN KEPADA PIHAK YANG MEMPUNYAI HUBUNGAN ISTIMEWA SEHUBUNGAN DENGAN PEKERJAAN YANG DILAKUKAN</span></td>
                    <td style="border-left: 1px dotted black; border-top: 1px solid black; border-bottom: 0px; font-size: 12px; text-align:center">2d.</td>
                    <td style="font-size: 12px; text-align: center; border: 1px solid black; border-bottom: 0px"><input value="{{ $formuliri[6]->rupiah_JenisPenghasilan ?? '' }}" type="text" class="form-control" style="width: 100%; height: 40px; border: 0px; text-align:right; font-size:14px" oninput="formatPengNetoDlmNegeri()" name="jumlahmelebihi_kewajaran" id="jumlahmelebihi_kewajaran" placeholder="0"></td>
                </tr>
                <tr>
                    <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px; font-size: 12px; text-align: center">2</td>
                    <td style="border-bottom: 0px"><span style="margin-left: 5px;  font-size: 12px">e. HARTA YANG DIHIBAHKAN, BANTUAN ATAU SUMBANGAN</span></td>
                    <td style="border-left: 1px dotted black; border-top: 1px solid black; border-bottom: 0px; font-size: 12px; text-align:center">2e.</td>
                    <td style="font-size: 12px; text-align: center; border: 1px solid black; border-bottom: 0px"><input value="{{ $formuliri[7]->rupiah_JenisPenghasilan ?? '' }}" type="text" class="form-control" style="width: 100%; height: 30px; border: 0px; text-align:right; font-size:14px" oninput="formatPengNetoDlmNegeri()" name="harta" id="harta" placeholder="0"></td>
                </tr>
                <tr>
                    <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px"></td>
                    <td style="border-bottom: 0px"><span style="margin-left: 5px;  font-size: 12px">f. PAJAK PENGHASILAN</span></td>
                    <td style="border-left: 1px dotted black; border-top: 1px solid black; border-bottom: 0px; font-size: 12px; text-align:center">2f.</td>
                    <td style="font-size: 12px; text-align: center; border: 1px solid black; border-bottom: 0px"><input value="{{ $formuliri[8]->rupiah_JenisPenghasilan ?? '' }}" type="text" class="form-control" style="width: 100%; height: 30px; border: 0px; text-align:right; font-size:14px" oninput="formatPengNetoDlmNegeri()" name="pajak_penghasilan" id="pajak_penghasilan" placeholder="0"></td>
                </tr>
                <tr>
                    <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px"></td>
                    <td style="border-bottom: 0px"><span style="margin-left: 5px;  font-size: 12px">g. GAJI YANG DIBAYARKAN KEPADA PEMILIK / ORANG YANG MENJADI TANGGUNGANNYA</span></td>
                    <td style="border-left: 1px dotted black; border-top: 1px solid black; border-bottom: 0px; font-size: 12px; text-align:center">2g.</td>
                    <td style="font-size: 12px; text-align: center; border: 1px solid black; border-bottom: 0px"><input value="{{ $formuliri[9]->rupiah_JenisPenghasilan ?? '' }}" type="text" class="form-control" style="width: 100%; height: 30px; border: 0px; text-align:right; font-size:14px" oninput="formatPengNetoDlmNegeri()" name="gaji_yangdibayarkan" id="gaji_yangdibayarkan" placeholder="0"></td>
                </tr>
                <tr>
                    <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px"></td>
                    <td style="border-bottom: 0px"><span style="margin-left: 5px;  font-size: 12px">h. SANKSI ADMINISTRASI</span></td>
                    <td style="border-left: 1px dotted black; border-top: 1px solid black; border-bottom: 0px; font-size: 12px; text-align:center">2h.</td>
                    <td style="font-size: 12px; text-align: center; border: 1px solid black; border-bottom: 0px"><input value="{{ $formuliri[10]->rupiah_JenisPenghasilan ?? '' }}" type="text" class="form-control" style="width: 100%; height: 30px; border: 0px; text-align:right; font-size:14px" oninput="formatPengNetoDlmNegeri()" name="sanksi_administrasi" id="sanksi_administrasi" placeholder="0"></td>
                </tr>
                <tr>
                    <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px"></td>
                    <td style="border-bottom: 0px"><span style="margin-left: 5px;  font-size: 12px">i. SELISIH PENYUSUTAN/AMORTISASI KOMERSIAL DIATAS PENYUSUTAN/AMORTISASI FISIKAL</span></td>
                    <td style="border-left: 1px dotted black; border-top: 1px solid black; border-bottom: 0px; font-size: 12px; text-align:center">2i.</td>
                    <td style="font-size: 12px; text-align: center; border: 1px solid black; border-bottom: 0px"><input value="{{ $formuliri[11]->rupiah_JenisPenghasilan ?? '' }}" type="text" class="form-control" style="width: 100%; height: 30px; border: 0px; text-align:right; font-size:14px" oninput="formatPengNetoDlmNegeri()" name="selisih" id="selisih" placeholder="0"></td>
                </tr>
                <tr>
                    <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px"></td>
                    <td style="border-bottom: 0px"><span style="margin-left: 5px;  font-size: 12px">j. BIAYA UNTUK MENDAPATKAN, MENAGIH DAN MEMELIHARA PENGHASILAN YANG DIKENAKAN PPh FINAL DAN PENGHASILAN YANG TIDAK TERMASUK OBJEK PAJAK</span></td>
                    <td style="border-left: 1px dotted black; border-top: 1px solid black; border-bottom: 0px; font-size: 12px; text-align:center">2j.</td>
                    <td style="font-size: 12px; text-align: center; border: 1px solid black; border-bottom: 0px"><input value="{{ $formuliri[12]->rupiah_JenisPenghasilan ?? '' }}" type="text" class="form-control" style="width: 100%; height: 40px; border: 0px; text-align:right; font-size:14px" oninput="formatPengNetoDlmNegeri()" name="biaya_yangmendapatkan" id="biaya_yangmendapatkan" placeholder="0"></td>
                </tr>
                <tr>
                    <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px"></td>
                    <td style="border-bottom: 0px"><span style="margin-left: 5px;  font-size: 12px">k. PENYESUAIAN FISIKAL POSITIF LAINNYA</span></td>
                    <td style="border-left: 1px dotted black; border-top: 1px solid black; border-bottom: 0px; font-size: 12px; text-align:center">2k.</td>
                    <td style="font-size: 12px; text-align: center; border: 1px solid black; border-bottom: 0px"><input value="{{ $formuliri[13]->rupiah_JenisPenghasilan ?? '' }}" type="text" class="form-control" style="width: 100%; height: 40px; border: 0px; text-align:right; font-size:14px" oninput="formatPengNetoDlmNegeri()" name="penyesuaian_fisikal_positif" id="penyesuaian_fisikal_positif" placeholder="0"></td>
                </tr>
                <tr>
                    <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px"></td>
                    <td style="border-bottom: 0px"><span style="margin-left: 5px;  font-size: 12px">l. JUMLAH (2a s.d 2k)</span></td>
                    <td style="border-left: 1px dotted black; border-top: 1px solid black; border-bottom: 0px; font-size: 12px; text-align:center">2l.</td>
                    <td style="font-size: 12px; text-align: center; border: 1px solid black; border-bottom: 0px; background-color: #F0E68C"><input type="text" disabled="true" readonly="readonly" style="width: 100%; height: 30px; border: 0px;background-color: #F0E68C; text-align:right; font-size:14px" name="jumlah(2a-2k)" id="jumlah(2a-2k)"></td>
                </tr>
            </table>
            <table style="width: 100%;">
                <tr>
                    <th style="width: 3%; border-bottom: 0px"></th>

                    <th style="width: 72%; font-size: 12px; border-bottom: 0px; border-right: 0px;">PENGHASILAN FISIKAL NEGATIF</th>
                    <th style="width: 5%; border-bottom: 0px; border-left: 0px; border-right: 0px;"></th>
                    <th style="width: 20%; font-size: 12px; text-align: center; border-bottom: 0px; border-left: 0px "></th>
                </tr>
                <tr>
                    <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px"></td>
                    <td style="border-bottom: 0px"> <span style="margin-left: 5px;  font-size: 12px">a. PENGHASILAN YANG DIKENAKAN PPh FINAL DAN PENGHASILAN YANG TIDAK TERMASUK OBJEK PAJAK TETAPI TERMASUK DALAM PEREDARAN USAHA</span></td>
                    <td style="border-left: 1px dotted black; border-top: 1px dotted black; border-bottom: 0px; font-size: 12px; text-align:center">3a.</td>
                    <td style="font-size: 12px; text-align: center; border: 1px solid black; border-bottom: 0px"><input value="{{ $formuliri[14]->rupiah_JenisPenghasilan ?? '' }}" type="text" class="form-control" style="width: 100%; height: 40px; border: 0px; text-align:right; font-size:14px" oninput="formatPengNetoDlmNegeri()" name="penghasilan_dikenakanPPhfinal" id="penghasilan_dikenakanPPhfinal" placeholder="0"></td>
                </tr>
                <tr>
                    <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px; font-size: 12px; text-align: center">3</td>
                    <td style="border-bottom: 0px"><span style="margin-left: 5px;  font-size: 12px">b. SELISIH PENYUSUTAN / AMORTISASI KOMERSIAL DI BAWAH PENYUSUTAN AMORTISASI FISIKAL</span></td>
                    <td style="border-left: 1px dotted black; border-top: 1px solid black; border-bottom: 0px; font-size: 12px; text-align:center">3b.</td>
                    <td style="font-size: 12px; text-align: center; border: 1px solid black; border-bottom: 0px"><input value="{{ $formuliri[15]->rupiah_JenisPenghasilan ?? '' }}" type="text" class="form-control" style="width: 100%; height: 30px; border: 0px; text-align:right; font-size:14px" oninput="formatPengNetoDlmNegeri()" name="selisih1" id="selisih1" placeholder="0"></td>
                </tr>
                <tr>
                    <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px"></td>
                    <td style="border-bottom: 0px"><span style="margin-left: 5px;  font-size: 12px">c. PENYUSUTAN FISIKAL NEGATIF LAINNYA</span></td>
                    <td style="border-left: 1px dotted black; border-top: 1px solid black; border-bottom: 0px; font-size: 12px; text-align:center">3c.</td>
                    <td style="font-size: 12px; text-align: center; border: 1px solid black; border-bottom: 0px"><input value="{{ $formuliri[16]->rupiah_JenisPenghasilan ?? '' }}" type="text" class="form-control" style="width: 100%; height: 30px; border: 0px; text-align:right; font-size:14px" oninput="formatPengNetoDlmNegeri()" name="penyesuaian_fisikal_negatif" id="penyesuaian_fisikal_negatif" placeholder="0"></td>
                </tr>
                <tr>
                    <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px"></td>
                    <td style="border-bottom: 0px"><span style="margin-left: 5px;  font-size: 12px">d. JUMLAH (3a s.d 3c)</span></td>
                    <td style="border-left: 1px dotted black; border-top: 1px solid black; border-bottom: 0px; font-size: 12px; text-align:center">3d.</td>
                    <td style="font-size: 12px; text-align: center; border: 1px solid black; border-bottom: 0px; background-color: #F0E68C"><input type="text" disabled="true" readonly="readonly" style="width: 100%; height: 30px; border: 0px;background-color: #F0E68C; text-align:right; font-size:14px" name="jumlah(3a-3c)" id="jumlah(3a-3c)"></td>
                </tr>
                <tr>
                    <th style="width: 3%; font-size: 12px; text-align: center">4</th>
                    <th style="width: 72%; font-size: 12px; border-right: 0px">JUMLAH BAGIAN A (1e + 2l -3d)</th>
                    <th style="border-left: 1px solid black; border-top: 1px solid black; font-size: 12px; text-align:center">4.</th>
                    <th style="font-size: 12px; text-align: center; border: 1px solid black; background-color: #F0E68C"><input type="text" disabled="true" readonly="readonly" style="width: 100%; height: 30px; border: 0px;background-color: #F0E68C; text-align:right; font-size:14px" name="jumlah(1e+2l-3d)" id="jumlah(1e+2l-3d)"></th>
                </tr>

            </table>

        </div>
        <div id="disabled" style="display: none;">
            <table style="width: 100%;">
                <tr>
                    <th style="width: 3%; border-bottom: 0px"></th>
                    <th style="width: 72%; font-size: 12px; border-bottom: 0px; border-right: 0px">PENGHASILAN DARI USAHA DAN/ATAU PEKERJAAN BEBAS BERDASARKAN LAPORAN KEUANGAN KOMERSIAL :</th>
                    <th style="width: 5%; border-bottom: 0px; border-left: 0px; border-right: 0px"></th>
                    <th style="width: 20%; font-size: 12px; text-align: center; border-bottom: 0px; border-left: 0px ">Rupiah</th>
                </tr>
                <tr>
                    <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px"></td>
                    <td style="border-bottom: 0px"> <span style="margin-left: 5px;  font-size: 12px">a. PEREDARAN USAHA</span></td>
                    <td style="border-left: 1px dotted black; border-top: 1px dotted black; border-bottom: 0px; font-size: 12px; text-align:center">1a.</td>
                    <td style="font-size: 12px; text-align: center; border: 1px solid black; border-bottom: 0px"><input type="text" class="form-control" style="width: 100%; height: 30px; border: 0px; text-align:right; font-size:14px" placeholder="0" disabled></td>
                </tr>
                <tr>
                    <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px"></td>
                    <td style="border-bottom: 0px"><span style="margin-left: 5px;  font-size: 12px">b. HARGA POKOK PENJUALAN</span></td>
                    <td style="border-left: 1px dotted black; border-top: 1px solid black; border-bottom: 0px; font-size: 12px; text-align:center">1b.</td>
                    <td style="font-size: 12px; text-align: center; border: 1px solid black; border-bottom: 0px"><input type="text" class="form-control" style="width: 100%; height: 30px; border: 0px; text-align:right; font-size:14px" placeholder="0" disabled></td>
                </tr>
                <tr>
                    <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px; font-size: 12px; text-align: center">1</td>
                    <td style="border-bottom: 0px"><span style="margin-left: 5px;  font-size: 12px">c. LABA/RUGI BRUTO USAHA (1a - 1b)</span></td>
                    <td style="border-left: 1px dotted black; border-top: 1px solid black; border-bottom: 0px; font-size: 12px; text-align:center">1c.</td>
                    <td style="font-size: 12px; text-align: center; border: 1px solid black; border-bottom: 0px; background-color: #F0E68C"><input type="text" disabled="true" readonly="readonly" style="width: 100%; height: 30px; border: 0px;background-color: #F0E68C; text-align:right; font-size:14px"></td>
                </tr>
                <tr>
                    <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px"></td>
                    <td style="border-bottom: 0px"><span style="margin-left: 5px;  font-size: 12px">d. BIAYA USAHA</span></td>
                    <td style="border-left: 1px dotted black; border-top: 1px solid black; border-bottom: 0px; font-size: 12px; text-align:center">1d.</td>
                    <td style="font-size: 12px; text-align: center; border: 1px solid black; border-bottom: 0px"><input type="text" class="form-control" style="width: 100%; height: 30px; border: 0px; text-align:right; font-size:14px" placeholder="0" disabled></td>
                </tr>
                <tr>
                    <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px"></td>
                    <td style="border-bottom: 0px"><span style="margin-left: 5px;  font-size: 12px">e. PENGHASILAN NETO (1c - 1d)</span></td>
                    <td style="border-left: 1px dotted black; border-top: 1px solid black; border-bottom: 0px; font-size: 12px; text-align:center">1e.</td>
                    <td style="font-size: 12px; text-align: center; border: 1px solid black; border-bottom: 0px;background-color: #F0E68C"><input type="text" readonly="readonly" style="width: 100%; height: 30px; border: 0px;background-color: #F0E68C; text-align:right; font-size:14px"></td>
                </tr>
            </table>
            <table style="width: 100%;">
                <tr>
                    <th style="width: 3%; border-bottom: 0px"></th>
                    <th style="width: 72%; font-size: 12px; border-bottom: 0px; border-right: 0px">PENYESUAIAN FISIKAL POSITIF</th>
                    <th style="width: 5%; border-bottom: 0px; border-left: 0px; border-right: 0px"></th>
                    <th style="width: 20%; font-size: 12px; text-align: center; border-bottom: 0px;  border-left: 0px"></th>
                </tr>
                <tr>
                    <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px"></td>
                    <td style="border-bottom: 0px"> <span style="margin-left: 5px;  font-size: 12px">a. BIAYA YANG DIBEBANKAN /DIKELUARKAN UNTUK KEPENTINGAN RPIBADI WAJIB PAJAK ATAU ORANG YANG MENJADI TANGGUNGANNYA</span></td>
                    <td style="border-left: 1px dotted black; border-top: 1px dotted black; border-bottom: 0px; font-size: 12px; text-align:center">2a.</td>
                    <td style="font-size: 12px; text-align: center; border: 1px solid black; border-bottom: 0px"><input type="text" class="form-control" style="width: 100%; height: 40px; border: 0px; text-align:right; font-size:14px" placeholder="0" disabled></td>
                </tr>
                <tr>
                    <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px"></td>
                    <td style="border-bottom: 0px"><span style="margin-left: 5px;  font-size: 12px">b. PREMI ASURANSI KESEHATAN, ASURANSI KECELAKAAN, ASURANSI JIWA, ASURANSI DWIGUNA, DAN ASURANSI BEASISWA YANG DIBAYAR OLEH WAJIB PAJAK</span></td>
                    <td style="border-left: 1px dotted black; border-top: 1px solid black; border-bottom: 0px; font-size: 12px; text-align:center">2b.</td>
                    <td style="font-size: 12px; text-align: center; border: 1px solid black; border-bottom: 0px"><input type="text" class="form-control" style="width: 100%; height: 40px; border: 0px; text-align:right; font-size:14px" placeholder="0" disabled></td>
                </tr>
                <tr>
                    <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px"></td>
                    <td style="border-bottom: 0px"><span style="margin-left: 5px;  font-size: 12px">c. PENGGANTIAN ATAU IMBALAN SEHUBUNGAN DENGAN PEKERJAAN ATAU JASA YANG DIBERIKAN DALAM BENTUK NATURA ATAU KENIKMATAN</span></td>
                    <td style="border-left: 1px dotted black; border-top: 1px solid black; border-bottom: 0px; font-size: 12px; text-align:center">2c.</td>
                    <td style="font-size: 12px; text-align: center; border: 1px solid black; border-bottom: 0px"><input type="text" class="form-control" style="width: 100%; height: 40px; border: 0px; text-align:right; font-size:14px" placeholder="0" disabled></td>
                </tr>
                <tr>
                    <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px"></td>
                    <td style="border-bottom: 0px"><span style="margin-left: 5px;  font-size: 12px">d. JUMLAH YANG MELEBIHI KEWAJARAN YANG DIBAYARKAN KEPADA PIHAK YANG MEMPUNYAI HUBUNGAN ISTIMEWA SEHUBUNGAN DENGAN PEKERJAAN YANG DILAKUKAN</span></td>
                    <td style="border-left: 1px dotted black; border-top: 1px solid black; border-bottom: 0px; font-size: 12px; text-align:center">2d.</td>
                    <td style="font-size: 12px; text-align: center; border: 1px solid black; border-bottom: 0px"><input type="text" class="form-control" style="width: 100%; height: 40px; border: 0px; text-align:right; font-size:14px" placeholder="0" disabled></td>
                </tr>
                <tr>
                    <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px; font-size: 12px; text-align: center">2</td>
                    <td style="border-bottom: 0px"><span style="margin-left: 5px;  font-size: 12px">e. HARTA YANG DIHIBAHKAN, BANTUAN ATAU SUMBANGAN</span></td>
                    <td style="border-left: 1px dotted black; border-top: 1px solid black; border-bottom: 0px; font-size: 12px; text-align:center">2e.</td>
                    <td style="font-size: 12px; text-align: center; border: 1px solid black; border-bottom: 0px"><input type="text" class="form-control" style="width: 100%; height: 30px; border: 0px; text-align:right; font-size:14px" placeholder="0" disabled></td>
                </tr>
                <tr>
                    <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px"></td>
                    <td style="border-bottom: 0px"><span style="margin-left: 5px;  font-size: 12px">f. PAJAK PENGHASILAN</span></td>
                    <td style="border-left: 1px dotted black; border-top: 1px solid black; border-bottom: 0px; font-size: 12px; text-align:center">2f.</td>
                    <td style="font-size: 12px; text-align: center; border: 1px solid black; border-bottom: 0px"><input type="text" class="form-control" style="width: 100%; height: 30px; border: 0px; text-align:right; font-size:14px" placeholder="0" disabled></td>
                </tr>
                <tr>
                    <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px"></td>
                    <td style="border-bottom: 0px"><span style="margin-left: 5px;  font-size: 12px">g. GAJI YANG DIBAYARKAN KEPADA PEMILIK / ORANG YANG MENJADI TANGGUNGANNYA</span></td>
                    <td style="border-left: 1px dotted black; border-top: 1px solid black; border-bottom: 0px; font-size: 12px; text-align:center">2g.</td>
                    <td style="font-size: 12px; text-align: center; border: 1px solid black; border-bottom: 0px"><input type="text" class="form-control" style="width: 100%; height: 30px; border: 0px; text-align:right; font-size:14px" placeholder="0" disabled></td>
                </tr>
                <tr>
                    <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px"></td>
                    <td style="border-bottom: 0px"><span style="margin-left: 5px;  font-size: 12px">h. SANKSI ADMINISTRASI</span></td>
                    <td style="border-left: 1px dotted black; border-top: 1px solid black; border-bottom: 0px; font-size: 12px; text-align:center">2h.</td>
                    <td style="font-size: 12px; text-align: center; border: 1px solid black; border-bottom: 0px"><input type="text" class="form-control" style="width: 100%; height: 30px; border: 0px; text-align:right; font-size:14px" placeholder="0" disabled></td>
                </tr>
                <tr>
                    <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px"></td>
                    <td style="border-bottom: 0px"><span style="margin-left: 5px;  font-size: 12px">i. SELISIH PENYUSUTAN/AMORTISASI KOMERSIAL DIATAS PENYUSUTAN/AMORTISASI FISIKAL</span></td>
                    <td style="border-left: 1px dotted black; border-top: 1px solid black; border-bottom: 0px; font-size: 12px; text-align:center">2i.</td>
                    <td style="font-size: 12px; text-align: center; border: 1px solid black; border-bottom: 0px"><input type="text" class="form-control" style="width: 100%; height: 30px; border: 0px; text-align:right; font-size:14px" placeholder="0" disabled></td>
                </tr>
                <tr>
                    <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px"></td>
                    <td style="border-bottom: 0px"><span style="margin-left: 5px;  font-size: 12px">j. BIAYA UNTUK MENDAPATKAN, MENAGIH DAN MEMELIHARA PENGHASILAN YANG DIKENAKAN PPh FINAL DAN PENGHASILAN YANG TIDAK TERMASUK OBJEK PAJAK</span></td>
                    <td style="border-left: 1px dotted black; border-top: 1px solid black; border-bottom: 0px; font-size: 12px; text-align:center">2j.</td>
                    <td style="font-size: 12px; text-align: center; border: 1px solid black; border-bottom: 0px"><input type="text" class="form-control" style="width: 100%; height: 40px; border: 0px; text-align:right; font-size:14px" placeholder="0" disabled></td>
                </tr>
                <tr>
                    <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px"></td>
                    <td style="border-bottom: 0px"><span style="margin-left: 5px;  font-size: 12px">k. PENYESUAIAN FISIKAL POSITIF LAINNYA</span></td>
                    <td style="border-left: 1px dotted black; border-top: 1px solid black; border-bottom: 0px; font-size: 12px; text-align:center">2k.</td>
                    <td style="font-size: 12px; text-align: center; border: 1px solid black; border-bottom: 0px"><input type="text" class="form-control" style="width: 100%; height: 40px; border: 0px; text-align:right; font-size:14px" placeholder="0" disabled></td>
                </tr>
                <tr>
                    <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px"></td>
                    <td style="border-bottom: 0px"><span style="margin-left: 5px;  font-size: 12px">l. JUMLAH (2a s.d 2k)</span></td>
                    <td style="border-left: 1px dotted black; border-top: 1px solid black; border-bottom: 0px; font-size: 12px; text-align:center">2l.</td>
                    <td style="font-size: 12px; text-align: center; border: 1px solid black; border-bottom: 0px; background-color: #F0E68C"><input type="text" disabled="true" readonly="readonly" style="width: 100%; height: 30px; border: 0px;background-color: #F0E68C; text-align:right; font-size:14px"></td>
                </tr>
            </table>
            <table style="width: 100%;">
                <tr>
                    <th style="width: 3%; border-bottom: 0px"></th>

                    <th style="width: 72%; font-size: 12px; border-bottom: 0px; border-right: 0px;">PENGHASILAN FISIKAL NEGATIF</th>
                    <th style="width: 5%; border-bottom: 0px; border-left: 0px; border-right: 0px;"></th>
                    <th style="width: 20%; font-size: 12px; text-align: center; border-bottom: 0px; border-left: 0px "></th>
                </tr>
                <tr>
                    <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px"></td>
                    <td style="border-bottom: 0px"> <span style="margin-left: 5px;  font-size: 12px">a. PENGHASILAN YANG DIKENAKAN PPh FINAL DAN PENGHASILAN YANG TIDAK TERMASUK OBJEK PAJAK TETAPI TERMASUK DALAM PEREDARAN USAHA</span></td>
                    <td style="border-left: 1px dotted black; border-top: 1px dotted black; border-bottom: 0px; font-size: 12px; text-align:center">3a.</td>
                    <td style="font-size: 12px; text-align: center; border: 1px solid black; border-bottom: 0px"><input type="text" class="form-control" style="width: 100%; height: 40px; border: 0px; text-align:right; font-size:14px" placeholder="0" disabled></td>
                </tr>
                <tr>
                    <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px; font-size: 12px; text-align: center">3</td>
                    <td style="border-bottom: 0px"><span style="margin-left: 5px;  font-size: 12px">b. SELISIH PENYUSUTAN / AMORTISASI KOMERSIAL DI BAWAH PENYUSUTAN AMORTISASI FISIKAL</span></td>
                    <td style="border-left: 1px dotted black; border-top: 1px solid black; border-bottom: 0px; font-size: 12px; text-align:center">3b.</td>
                    <td style="font-size: 12px; text-align: center; border: 1px solid black; border-bottom: 0px"><input type="text" class="form-control" style="width: 100%; height: 30px; border: 0px; text-align:right; font-size:14px" placeholder="0" disabled></td>
                </tr>
                <tr>
                    <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px"></td>
                    <td style="border-bottom: 0px"><span style="margin-left: 5px;  font-size: 12px">c. PENYUSUTAN FISIKAL NEGATIF LAINNYA</span></td>
                    <td style="border-left: 1px dotted black; border-top: 1px solid black; border-bottom: 0px; font-size: 12px; text-align:center">3c.</td>
                    <td style="font-size: 12px; text-align: center; border: 1px solid black; border-bottom: 0px"><input type="text" class="form-control" style="width: 100%; height: 30px; border: 0px; text-align:right; font-size:14px" placeholder="0" disabled></td>
                </tr>
                <tr>
                    <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px"></td>
                    <td style="border-bottom: 0px"><span style="margin-left: 5px;  font-size: 12px">d. JUMLAH (3a s.d 3c)</span></td>
                    <td style="border-left: 1px dotted black; border-top: 1px solid black; border-bottom: 0px; font-size: 12px; text-align:center">3d.</td>
                    <td style="font-size: 12px; text-align: center; border: 1px solid black; border-bottom: 0px; background-color: #F0E68C"><input type="text" disabled="true" readonly="readonly" style="width: 100%; height: 30px; border: 0px;background-color: #F0E68C; text-align:right; font-size:14px"></td>
                </tr>
                <tr>
                    <th style="width: 3%; font-size: 12px; text-align: center">4</th>
                    <th style="width: 72%; font-size: 12px; border-right: 0px">JUMLAH BAGIAN A (1e + 2l -3d)</th>
                    <th style="border-left: 1px solid black; border-top: 1px solid black; font-size: 12px; text-align:center">4.</th>
                    <th style="font-size: 12px; text-align: center; border: 1px solid black; background-color: #F0E68C"><input type="text" disabled="true" readonly="readonly" style="width: 100%; height: 30px; border: 0px;background-color: #F0E68C; text-align:right; font-size:14px"></th>
                </tr>

            </table>


        </div>
        <button type="button" onclick="BagianA(this)">Simpan</button>
        <button type="button" onclick="BagianADelete()">Hapus</button>

        <script>
            function BagianA() {
                peredaran_usaha = document.querySelector('#peredaran_usaha').value
                harga_pokok_penjualan = document.querySelector('#harga_pokok_penjualan').value
                biaya_usaha = document.querySelector('#biaya_usaha ').value
                biaya_dibebankan_dikeluarkan = document.querySelector('#biaya_dibebankan_dikeluarkan').value
                premi_asuransi = document.querySelector('#premi_asuransi').value
                penggantian_imbalan = document.querySelector('#penggantian_imbalan').value
                jumlahmelebihi_kewajaran = document.querySelector('#jumlahmelebihi_kewajaran').value
                harta = document.querySelector('#harta').value
                pajak_penghasilan = document.querySelector('#pajak_penghasilan').value
                gaji_yangdibayarkan = document.querySelector('#gaji_yangdibayarkan').value
                sanksi_administrasi = document.querySelector('#sanksi_administrasi').value
                selisih = document.querySelector('#selisih').value
                biaya_yangmendapatkan = document.querySelector('#biaya_yangmendapatkan').value
                penyesuaian_fisikal_positif = document.querySelector('#penyesuaian_fisikal_positif').value
                penghasilan_dikenakanPPhfinal = document.querySelector('#penghasilan_dikenakanPPhfinal').value
                selisih1 = document.querySelector('#selisih1').value
                penyesuaian_fisikal_negatif = document.querySelector('#penyesuaian_fisikal_negatif').value
               
                var data = {
                    penghasilan: [peredaran_usaha, harga_pokok_penjualan, biaya_usaha, biaya_dibebankan_dikeluarkan,
                        premi_asuransi, penggantian_imbalan, jumlahmelebihi_kewajaran, harta, pajak_penghasilan, gaji_yangdibayarkan,
                        sanksi_administrasi, selisih, biaya_yangmendapatkan, penyesuaian_fisikal_positif, penghasilan_dikenakanPPhfinal,
                        selisih1, penyesuaian_fisikal_negatif
                    ]
                }
                console.log(data);
                $.ajax({
                    headers:{
                        'X-CSRF-TOKEN' : $('meta[name="csrf-token"]').attr('content')
                    },
                    type: "POST",
                    url: 'http://localhost:8000/FormulirI_Point/Store',
                    data: data,
                    success: function(res) {
                        console.log(res)
                    }
                });
            }

            function BagianADelete(){
                $.ajax({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    type: "POST",
                    url: 'http://localhost:8000/FormulirI_Point/delete',
                    success: function(res) {
                        location.reload()
                    }
                });
            }
        </script>
        <script>
            function Pencatatan(src) {
                const myElement = document.getElementById("tampil");
                myElement.style.display = "none";

                document.getElementById("disabled").style.display = "block";
            }

            function Pembukuan(src) {
                const myElement = document.getElementById("disabled");
                document.getElementById("tampil").style.display = "block";

                myElement.style.display = "none";
            }
        </script>




        <!-- Option 1: Bootstrap Bundle with Popper -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
        </script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js" integrity="sha512-aVKKRRi/Q/YV+4mjoKBsE4x3H+BkegoM/em46NNlCqNTmUYADjBbeNefNxYV7giUp0VxICtqdrbqU7iVaeZNXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
        </script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
        </script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/numeral.js/2.0.6/numeral.min.js"></script>

        <script>
            var input = document.getElementById("npwp_kantor_Kpajak");
            input.addEventListener("keypress", function(event) {
                if (event.key === "Enter") {
                    console.log('enter')
                    event.preventDefault();
                    saveAudit();
                }
            });

            function saveAudit() {
                const opini_akuntan = document.getElementById("opini_akuntan").value;
                const nama_AKpublik = document.getElementById("nama_AKpublik").value;
                const npwp_AKpublik = document.getElementById("npwp_AKpublik").value;
                const nama_kantor_AKpublik = document.getElementById("nama_kantor_AKpublik").value;
                const npwp_kantor_AKpublik = document.getElementById("npwp_kantor_AKpublik").value;
                const nama_Kpajak = document.getElementById("nama_Kpajak").value;
                const npwp_Kpajak = document.getElementById("npwp_Kpajak").value;
                const nama_kantor_Kpajak = document.getElementById("nama_kantor_Kpajak").value;
                const npwp_kantor_Kpajak = document.getElementById("npwp_kantor_Kpajak").value;
                data = {
                    opini_akuntan: opini_akuntan,
                    nama_AKpublik: nama_AKpublik,
                    npwp_AKpublik: npwp_AKpublik,
                    nama_kantor_AKpublik: nama_kantor_AKpublik,
                    npwp_kantor_AKpublik: npwp_kantor_AKpublik,
                    nama_Kpajak: nama_Kpajak,
                    npwp_Kpajak: npwp_Kpajak,
                    nama_kantor_Kpajak: nama_kantor_Kpajak,
                    npwp_kantor_Kpajak: npwp_kantor_Kpajak,
                }
                $.ajax({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    type: "post",
                    data: data,
                    url: 'http://localhost:8000/Audit/Store',
                    success: function(res) {
                        alert(res);
                    }
                });
            }
        </script>
        <script>
            $(document).ready(function() {
                formatNpwp2();
                formatPengNetoDlmNegeri();
            });

            function handleChange(src) {
                const myElement = document.getElementById("eformspt");
                const myElement2 = document.getElementById("eformspt2");
                myElement.style.display = "block";
                myElement2.style.display = "none";
            }

            function handleChange2(src) {
                const myElement = document.getElementById("eformspt");
                const myElement2 = document.getElementById("eformspt2");
                myElement.style.display = "none";
                myElement2.style.display = "block";
            }
        </script>
        <script>
            function formatPengNetoDlmNegeri() {
                valuePeredaranUsaha = numeral(peredaran_usaha.value);
                document.getElementById('peredaran_usaha').value = valuePeredaranUsaha.format();

                valueHargaPokokPenjualan = numeral(harga_pokok_penjualan.value);
                document.getElementById('harga_pokok_penjualan').value = valueHargaPokokPenjualan.format();

                valueBiayaUsaha = numeral(biaya_usaha.value);
                document.getElementById('biaya_usaha').value = valueBiayaUsaha.format();

                valueBiayaDibebankanDikeluarkan = numeral(biaya_dibebankan_dikeluarkan.value);
                document.getElementById('biaya_dibebankan_dikeluarkan').value = valueBiayaDibebankanDikeluarkan.format();

                valuePremiAsuransi = numeral(premi_asuransi.value);
                document.getElementById('premi_asuransi').value = valuePremiAsuransi.format();

                valuePenggantianImbalan = numeral(penggantian_imbalan.value);
                document.getElementById('penggantian_imbalan').value = valuePenggantianImbalan.format();

                valueJumlahMelebihiKewajaran = numeral(jumlahmelebihi_kewajaran.value);
                document.getElementById('jumlahmelebihi_kewajaran').value = valueJumlahMelebihiKewajaran.format();
                valueHarta = numeral(harta.value);
                document.getElementById('harta').value = valueHarta.format();
                valuePajakPenghasilan = numeral(pajak_penghasilan.value);
                document.getElementById('pajak_penghasilan').value = valuePajakPenghasilan.format();
                valueGajiYangDibayarkan = numeral(gaji_yangdibayarkan.value);
                document.getElementById('gaji_yangdibayarkan').value = valueGajiYangDibayarkan.format();
                valueSanksiAdministrasi = numeral(sanksi_administrasi.value);
                document.getElementById('sanksi_administrasi').value = valueSanksiAdministrasi.format();
                valueSelisih = numeral(selisih.value);
                document.getElementById('selisih').value = valueSelisih.format();
                valueBiayaYangMendapatkan = numeral(biaya_yangmendapatkan.value);
                document.getElementById('biaya_yangmendapatkan').value = valueBiayaYangMendapatkan.format();
                valuePenyesuaianFisikalPositif = numeral(penyesuaian_fisikal_positif.value);
                document.getElementById('penyesuaian_fisikal_positif').value = valuePenyesuaianFisikalPositif.format();

                valuePenghasilanDikenakanPPhFinal = numeral(penghasilan_dikenakanPPhfinal.value);
                document.getElementById('penghasilan_dikenakanPPhfinal').value = valuePenghasilanDikenakanPPhFinal.format();
                valueSelisih1 = numeral(selisih1.value);
                document.getElementById('selisih1').value = valueSelisih1.format();
                valuePenyesuaianFisikalNegatif = numeral(penyesuaian_fisikal_negatif.value);
                document.getElementById('penyesuaian_fisikal_negatif').value = valuePenyesuaianFisikalNegatif.format();

                var resultLabaRugi = ((valuePeredaranUsaha.value()) - (valueHargaPokokPenjualan.value()));
                if (!isNaN(resultLabaRugi)) {
                    document.getElementById('hasil1c').value = numeral(resultLabaRugi).format()

                }

                var result2 = resultLabaRugi - (valueBiayaUsaha.value());
                if (!isNaN(result2)) {
                    document.getElementById('hasil1').value = numeral(result2).format()

                }
                var result3 = ((valueBiayaDibebankanDikeluarkan.value()) + (valuePremiAsuransi.value()) + (valuePenggantianImbalan.value()) + (valueJumlahMelebihiKewajaran.value()) + (valueHarta.value()) + (valuePajakPenghasilan.value()) +
                    (valueGajiYangDibayarkan.value()) + (valueSanksiAdministrasi.value()) + (valueSelisih.value()) + (valueBiayaYangMendapatkan.value()) + (valuePenyesuaianFisikalPositif.value()));
                if (!isNaN(result3)) {
                    document.getElementById('jumlah(2a-2k)').value = numeral(result3).format()

                }
                var result4 = ((valuePenghasilanDikenakanPPhFinal.value()) + (valueSelisih1.value()) + (valuePenyesuaianFisikalNegatif.value()));
                if (!isNaN(result4)) {
                    document.getElementById('jumlah(3a-3c)').value = numeral(result4).format()

                }

                var result5 = result2 + result3 - result4;
                if (!isNaN(result5)) {
                    document.getElementById('jumlah(1e+2l-3d)').value = numeral(result5).format()

                }
            }

            function formatNpwp2() {
                formatnpwp = document.getElementById('formatnpwpfix').value
                formatnpwp2 = document.getElementById('formatnpwpfix')
                if (typeof formatnpwp === 'string') {

                }
                formatnpwp2.value = formatnpwp.replace(/(\d{2})(\d{3})(\d{3})(\d{1})(\d{3})(\d{3})/, '$1.$2.$3.$4-$5.$6');
            }
        </script>
</body>

</html>