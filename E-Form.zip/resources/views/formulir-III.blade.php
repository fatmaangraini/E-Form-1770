<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}" />

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js" integrity="sha512-aVKKRRi/Q/YV+4mjoKBsE4x3H+BkegoM/em46NNlCqNTmUYADjBbeNefNxYV7giUp0VxICtqdrbqU7iVaeZNXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <title>Formulir 1770-III</title>
    <style>
        .bg-grey {
            font-family: arial;
            background-color: #ccc;
        }

        .vericaltext {
            writing-mode: vertical-lr;
            text-orientation: use-glyph-orientation;
        }

        .year {
            border: 1px solid black;
            width: 20px;
            font-size: 25px;
        }

        table tr th {
            border: 1px solid black;
            font-size: 25px;
        }
    </style>
</head>

<body class="bg-grey" style="padding: 1% 10% 1% 10%">
    <div class="container" style="width : 90%; background-color: #fff;">
        <div class="row" style="border-bottom: 2px solid black;">
            <div class="col-2" style="padding: 50px 0px 10px 10px">
                <h1 style="font-size: 20px; font-weight: bold; text-align: center; margin-top: -10px">FORMULIR</h1>
                <h1 style="font-size: 40px; font-weight: bold; text-align: center; margin-top: 30px">1770-III</h1>
                <p style="font-size: 10px; font-weight: bold; text-align: center; margin-top: 30px">KEMENTERIAN KEUANGAN RI DIREKTORAT JENDERAL PAJAK
                </p>
            </div>
            <div class="col-6" style="border-left: 2px solid black; border-right:2px solid black;">
                <div class="row">
                    <b style="font-size: 18px; text-align: center;">LAMPIRAN-III</b>
                    <p style=" font-size: 18px; font-weight: bold;  text-align: center; border-bottom: 2px solid black">
                        SPT TAHUNAN PPh WAJIB PAJAK ORANG PRIBADI</p>
                </div>
                <div class="row" style="font-size: 11px;">
                    <b>* PENGHASILAN YANG DIKENAKAN PAJAK FINAL DAN/ATAU BERSIFAT FINAL</b>
                    <b>* PENGHASILAN YANG TIDAK TERMASUK OBJEK PAJAK</b>
                    <b>* PENGHASILAN ISTERI/SUAMI YNG DIKENAKAN PAJAK SECARA TERPISAH</b>
                </div>
            </div>


            <div class="col-4" style="padding: 10px 10px 10px 10px">
                <!-- <b class="vericaltext fs-7">
                    TAHUN PAJAK
                </b> -->
                <form>
                    @csrf
                    <a href="/formulir-IV" class="btn btn-secondary" style="font-size: 12px; width: 120px; height: 30px; margin-left: 10px">Sebelumnya</a>
                    <a href="/formulir-II" id="selanjutnya" class="btn btn-secondary" style="font-size: 12px; width: 120px; height: 30px; margin-left: 10px">Selanjutnya</a>
                    <a href="/PP46atau23" id="pph46" class="btn btn-secondary" style="font-size: 12px; width: 120px; height: 30px; margin-left: 10px; display: none">PP 46/23</a>

                    <div class="row" style="padding: 4% 10%;">
                        <div class="col">
                            <table>
                                <tr>
                                    <th style="text-align: center" width="60px">{{ mb_substr($spt['tahun'], 0, 1); }}</th>
                                    <th style="text-align: center" width="60px">{{ mb_substr($spt['tahun'], 1, 1); }}</th>
                                    <th style="text-align: center" width="60px">{{ mb_substr($spt['tahun'], 2, 1); }}</th>
                                    <th style="text-align: center" width="60px">{{ mb_substr($spt['tahun'], 3, 1); }}</th>
                                </tr>
                            </table>
                        </div>
                    </div>
                    <div class="row" style="padding: 1% 10%;">
                        <div class="col-4">
                            <table>
                                <tr>
                                    <th>0</th>
                                    <th>1</th>
                                    <th>{{ mb_substr($spt['tahun'], 2, 1); }}</th>
                                    <th>{{ mb_substr($spt['tahun'], 3, 1); }}</th>
                                </tr>
                            </table>
                        </div>
                        <div class="col-2">
                            <p style="margin: 15px;">sd</p>
                        </div>
                        <div class="col-4">
                            <table>
                                <tr>
                                    <th>1</th>
                                    <th>2</th>
                                    <th>{{ mb_substr($spt['tahun'], 2, 1); }}</th>
                                    <th>{{ mb_substr($spt['tahun'], 3, 1); }}</th>
                                </tr>
                            </table>
                        </div>
                    </div>

                    <div class="form-check" style="display:inline-block; margin-left: 10px">
                        <input style="display:inline;" class="form-check-input" type="radio" name="flexRadioDisabled" id="flexRadioDisabled">
                        <label class="form-check-label" for="flexRadioDisabled" style="font-size: 14px;">
                            Pembukuan
                        </label>
                    </div>
                    <div class="form-check" style="display:inline-block; margin-left: 10px">
                        <input class="form-check-input" type="radio" name="flexRadioDisabled" id="flexRadioCheckedDisabled" checked>
                        <label class="form-check-label" for="flexRadioCheckedDisabled" style="font-size: 14px;">
                            Pencatatan
                        </label>
                    </div>
                    <div class="col-sm-12" style="background-color: #F0E68C ; padding: 4px 10px 10px 10px ; height: 30PX">
                        <div class="input-group mb-6">
                            <div class="input-group-prepend">
                                <div style="margin-left: -11px">
                                    <input type="checkbox" aria-label="Checkbox for following text input" style="width: 20px;">
                                </div>
                            </div>
                            <label class="col-sm-9" style="font-size: 11px; text-align: center">SPT Pembetulan Ke</label>
                            <input style="width:20px; height: 20px; border: 1px solid;">
                        </div>
                    </div>
            </div>
        </div>
        <b style="font-size: 10px;">PERHATIAN *SEBELUM MENGISI BACALAH PETUNJUK PENGISIAN *ISI DENGAN HURU CETAK/DIKETIK DENGAN TINTA HITAM *BERI TANDA X DALAM KOTAK SESUAI PILIHAN</b>
        <div class="col-sm-11.5" style=" border: 1px solid black; background-color: #F0E68C ; padding: 4px 20px 10px 10px ; height: 80PX; border: 2px solid; margin-left: 10px">
            <div class="row">
                <label class="col-sm-4 col-form-label" style="font-size: 12px;">NPWP</label>
                <div class="col-sm-8">
                    <input class="form-control" type="text" style="border: 1px solid black; height: 30px; border-radius: 1px; " value="{{ $npwp }}" disabled="disabled" id="formatnpwpfix">
                </div>
            </div>
            <div class="row">
                <label class="col-sm-4 col-form-label" style="font-size: 12px;">NAMA WAJIB PAJAK</label>
                <div class="col-sm-8">
                    <input class="form-control" type="text" style="border: 1px solid black; height: 30px; border-radius: 1px;" value="{{ $nama }}" disabled="disabled">
                </div>
            </div>
        </div>
        <p style="font-size: 11px; padding: 10px 0px 0px 0px"> BAGIAN A. PENGHASILAN YANG DIKENAKAN PAJAK FINAL DAN/ATAU BERSIFAT FINAL</p>
        <table id="#mytable" class="display" style="width:100%">

            <tr>
                <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 4%;  height: 30px">NO.</th>
                <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 35%">JENIS PENGHASILAN</th>
                <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 30%">DASAR PENGENAAN PAJAK/PENGHASILAN BRUTO</th>
                <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 30%">PPh TERUTANG (Rupiah)</th>
            </tr>
            <tr>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 10px; height: 20px">(1)</td>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 10px; height: 20px">(2)</td>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 10px; height: 20px">(3)</td>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 10px; height: 20px">(4)</td>
            </tr>
            <tr>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center">1.</td>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold">BUNGA DEPOSITO, TABUNGAN, DISKONTO SBI, SURAT BERHARGA NEGARA</td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" value="{{ $formulir_iiia[0]->rupiah_dsrPengenaan_PajakA ?? '' }}" style="text-align: right; border: 1px solid white" oninput="formatPajakFinal()" name="pengenaan_pajak1" id="pengenaan_pajak1" placeholder="0"></td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" value="{{ $formulir_iiia[0]->rupiah_PPh_terutang ?? '' }}" style="text-align: right; border: 1px solid white" oninput="formatJnsPenghasilan1()" name="pph_terutang1" id="pph_terutang1" placeholder="0"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center">2.</td>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold">BUNGA/DISKONTO OBLIGASI</td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" value="{{ $formulir_iiia[1]->rupiah_dsrPengenaan_PajakA ?? '' }}" style="text-align: right; border: 1px solid white" oninput="formatPajakFinal(this.value)" name="pengenaan_pajak2" id="pengenaan_pajak2" placeholder="0"></td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" value="{{ $formulir_iiia[1]->rupiah_PPh_terutang ?? '' }}" style="text-align: right; border: 1px solid white" oninput="formatJnsPenghasilan2()" name="pph_terutang2" id="pph_terutang2" placeholder="0"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center">3.</td>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold">PENJUALAN SAHAM DI BURSA EFEK</td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" value="{{ $formulir_iiia[2]->rupiah_dsrPengenaan_PajakA ?? '' }}" style="text-align: right; border: 1px solid white" oninput="formatPajakFinal(this.value)" name="pengenaan_pajak3" id="pengenaan_pajak3" placeholder="0"></td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" value="{{ $formulir_iiia[2]->rupiah_PPh_terutang ?? '' }}" style="text-align: right; border: 1px solid white" oninput="formatJnsPenghasilan3(this.value)" name="pph_terutang3" id="pph_terutang3" placeholder="0"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center">4.</td>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold">HADIAH UNDIAN</td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" value="{{ $formulir_iiia[3]->rupiah_dsrPengenaan_PajakA ?? '' }}" style="text-align: right; border: 1px solid white" oninput="formatPajakFinal(this.value)" name="pengenaan_pajak4" id="pengenaan_pajak4" placeholder="0"></td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" value="{{ $formulir_iiia[3]->rupiah_PPh_terutang ?? '' }}" style="text-align: right; border: 1px solid white" oninput="formatJnsPenghasilan4(this.value)" name="pph_terutang4" id="pph_terutang4" placeholder="0"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center">5.</td>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold">PESANGON, TUNJANGAN HARI TUA DAN TEBUSAN PENSIUN YANG DIBAYAR SEKALIGUS</td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" value="{{ $formulir_iiia[4]->rupiah_dsrPengenaan_PajakA ?? '' }}" style="text-align: right; border: 1px solid white" oninput="formatPajakFinal(this.value)" name="pengenaan_pajak5" id="pengenaan_pajak5" placeholder="0"></td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" value="{{ $formulir_iiia[4]->rupiah_PPh_terutang ?? '' }}" style="text-align: right; border: 1px solid white" oninput="formatJnsPenghasilan5(this.value)" name="pph_terutang5" id="pph_terutang5" placeholder="0"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center">6.</td>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold">HONORARIUM ATAS BEBAN APBN / APBD</td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" value="{{ $formulir_iiia[5]->rupiah_dsrPengenaan_PajakA ?? '' }}" style="text-align: right; border: 1px solid white" oninput="formatPajakFinal(this.value)" name="pengenaan_pajak6" id="pengenaan_pajak6" placeholder="0"></td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" value="{{ $formulir_iiia[5]->rupiah_PPh_terutang ?? '' }}" style="text-align: right; border: 1px solid white" oninput="formatJnsPenghasilan6(this.value)" name="pph_terutang6" id="pph_terutang6" placeholder="0"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center">7.</td>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold">PENGALIHAN HAK ATAS TANAH DAN/ATAU BANGUNAN</td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" value="{{ $formulir_iiia[6]->rupiah_dsrPengenaan_PajakA ?? '' }}" style="text-align: right; border: 1px solid white" oninput="formatPajakFinal(this.value)" name="pengenaan_pajak7" id="pengenaan_pajak7" placeholder="0"></td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" value="{{ $formulir_iiia[6]->rupiah_PPh_terutang ?? '' }}" style="text-align: right; border: 1px solid white" oninput="formatJnsPenghasilan7(this.value)" name="pph_terutang7" id="pph_terutang7" placeholder="0"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center">8.</td>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold">BANGUNAN YANG DITERIMA DALAM RANGKA BANGUNAN GUNA SERAH</td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" value="{{ $formulir_iiia[7]->rupiah_dsrPengenaan_PajakA ?? '' }}" style="text-align: right; border: 1px solid white" oninput="formatPajakFinal(this.value)" name="pengenaan_pajak8" id="pengenaan_pajak8" placeholder="0"></td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" value="{{ $formulir_iiia[7]->rupiah_PPh_terutang ?? '' }}" style="text-align: right; border: 1px solid white" oninput="formatJnsPenghasilan8(this.value)" name="pph_terutang8" id="pph_terutang8" placeholder="0"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center">9.</td>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold">SEWA ATAS TANAH DAN/ATAU BANGUNAN</td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" value="{{ $formulir_iiia[8]->rupiah_dsrPengenaan_PajakA ?? '' }}" style="text-align: right; border: 1px solid white" oninput="formatPajakFinal(this.value)" name="pengenaan_pajak9" id="pengenaan_pajak9" placeholder="0"></td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" value="{{ $formulir_iiia[8]->rupiah_PPh_terutang ?? '' }}" style="text-align: right; border: 1px solid white" oninput="formatJnsPenghasilan9(this.value)" name="pph_terutang9" id="pph_terutang9" placeholder="0"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center">10.</td>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold">USAHA JASA KONSTRUKSI</td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" value="{{ $formulir_iiia[9]->rupiah_dsrPengenaan_PajakA ?? '' }}" style="text-align: right; border: 1px solid white" oninput="formatPajakFinal(this.value)" name="pengenaan_pajak10" id="pengenaan_pajak10" placeholder="0"></td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" value="{{ $formulir_iiia[9]->rupiah_PPh_terutang ?? '' }}" style="text-align: right; border: 1px solid white" oninput="formatJnsPenghasilan10(this.value)" name="pph_terutang10" id="pph_terutang10" placeholder="0"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center">11.</td>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold">PENYALUR/DEALER/AGEN PRODUK BBM</td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" value="{{ $formulir_iiia[10]->rupiah_dsrPengenaan_PajakA ?? '' }}" style="text-align: right; border: 1px solid white" oninput="formatPajakFinal(this.value)" name="pengenaan_pajak11" id="pengenaan_pajak11" placeholder="0"></td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" value="{{ $formulir_iiia[10]->rupiah_PPh_terutang ?? '' }}" style="text-align: right; border: 1px solid white" oninput="formatJnsPenghasilan11(this.value)" name="pph_terutang11" id="pph_terutang11" placeholder="0"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center">12.</td>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold">BUNGA SIMPANAN YANG DIBAYARKAN OLEH KOPERASI KEPADA ANGGOTA KOPERASI</td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" value="{{ $formulir_iiia[11]->rupiah_dsrPengenaan_PajakA ?? '' }}" style="text-align: right; border: 1px solid white" oninput="formatPajakFinal(this.value)" name="pengenaan_pajak12" id="pengenaan_pajak12" placeholder="0"></td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" value="{{ $formulir_iiia[11]->rupiah_PPh_terutang ?? '' }}" style="text-align: right; border: 1px solid white" oninput="formatJnsPenghasilan12(this.value)" name="pph_terutang12" id="pph_terutang12" placeholder="0"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center">13.</td>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold">PENGHASILAN DARI TRANSAKSI DERIVATIF</td>
                <td style="border: 1px solid black; background-color: #C0C0C0; height: 40px"></td>
                <td style="border: 1px solid black; background-color: #C0C0C0; height: 40px"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center">14.</td>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold">DIVIDEN</td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" value="{{ $formulir_iiia[12]->rupiah_dsrPengenaan_PajakA ?? '' }}" style="text-align: right; border: 1px solid white" oninput="formatPajakFinal(this.value)" name="pengenaan_pajak14" id="pengenaan_pajak14" placeholder="0"></td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" value="{{ $formulir_iiia[12]->rupiah_PPh_terutang ?? '' }}" style="text-align: right; border: 1px solid white" oninput="formatJnsPenghasilan14(this.value)" name="pph_terutang14" id="pph_terutang14" placeholder="0"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center">15.</td>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold">PENGHASILAN ISTERI DARU SATU PEMBERI KERJA</td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" value="{{ $formulir_iiia[13]->rupiah_dsrPengenaan_PajakA ?? '' }}" style="text-align: right; border: 1px solid white" oninput="formatPajakFinal(this.value)" name="pengenaan_pajak15" id="pengenaan_pajak15" placeholder="0"></td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" value="{{ $formulir_iiia[13]->rupiah_PPh_terutang ?? '' }}" style="text-align: right; border: 1px solid white" oninput="formatJnsPenghasilan15(this.value)" name="pph_terutang15" id="pph_terutang15" placeholder="0"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center">16.</td>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold">PENGHASILAN LAIN YANG DIKENAKAN PAJAK FINAL DAN/ATAU BERSIFAT FINAL
                    <input type="checkbox" id="pembetulan2" aria-label="Checkbox for following text input" style="width: 20px;">
                    <label for="exampleFormControlInput1" class="form-label">PP46/23</label>
                </td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" value="{{ $formulir_iiia[14]->rupiah_dsrPengenaan_PajakA ?? '' }}" style="text-align: right; border: 1px solid white" oninput="formatPajakFinal(this.value)" name="pengenaan_pajak16" id="pengenaan_pajak16" placeholder="0"></td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" value="{{ $formulir_iiia[14]->rupiah_PPh_terutang ?? '' }}" style="text-align: right; border: 1px solid white" oninput="formatJnsPenghasilan16(this.value)" name="pph_terutang16" id="pph_terutang16" placeholder="0"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 10px; height: 30px; margin-left: -1px; margin-top: -2px">17.</td>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold; width: 10px; height: 30px; margin-left: -1px; margin-top: -2px">JUMLAH (1 s.d. 16)</td>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold; width: 10px; height: 30px; margin-left: -1px; margin-top: -2px; background-color: #C0C0C0;"></td>
                <td style="border: 1px solid black; background-color: #F0E68C;"><input type="text" class="form-control" readonly="readonly" style="background-color: #F0E68C; text-align: right" name="hasil" id="hasil"></td>
            </tr>
        </table>
        <script>
            function BagianA() {
                pengenaan_pajak1 = document.querySelector('#pengenaan_pajak1').value
                pengenaan_pajak2 = document.querySelector('#pengenaan_pajak2').value
                pengenaan_pajak3 = document.querySelector('#pengenaan_pajak3').value
                pengenaan_pajak4 = document.querySelector('#pengenaan_pajak4').value
                pengenaan_pajak5 = document.querySelector('#pengenaan_pajak5').value
                pengenaan_pajak6 = document.querySelector('#pengenaan_pajak6').value
                pengenaan_pajak7 = document.querySelector('#pengenaan_pajak7').value
                pengenaan_pajak8 = document.querySelector('#pengenaan_pajak8').value
                pengenaan_pajak9 = document.querySelector('#pengenaan_pajak9').value
                pengenaan_pajak10 = document.querySelector('#pengenaan_pajak10').value
                pengenaan_pajak11 = document.querySelector('#pengenaan_pajak11').value
                pengenaan_pajak12 = document.querySelector('#pengenaan_pajak12').value
                pengenaan_pajak14 = document.querySelector('#pengenaan_pajak14').value
                pengenaan_pajak15 = document.querySelector('#pengenaan_pajak15').value
                pengenaan_pajak16 = document.querySelector('#pengenaan_pajak16').value
                pph_terutang1 = document.querySelector('#pph_terutang1').value
                pph_terutang2 = document.querySelector('#pph_terutang2').value
                pph_terutang3 = document.querySelector('#pph_terutang3').value
                pph_terutang4 = document.querySelector('#pph_terutang4').value
                pph_terutang5 = document.querySelector('#pph_terutang5').value
                pph_terutang6 = document.querySelector('#pph_terutang6').value
                pph_terutang7 = document.querySelector('#pph_terutang7').value
                pph_terutang8 = document.querySelector('#pph_terutang8').value
                pph_terutang9 = document.querySelector('#pph_terutang9').value
                pph_terutang10 = document.querySelector('#pph_terutang10').value
                pph_terutang11 = document.querySelector('#pph_terutang11').value
                pph_terutang12 = document.querySelector('#pph_terutang12').value
                pph_terutang14 = document.querySelector('#pph_terutang14').value
                pph_terutang15 = document.querySelector('#pph_terutang15').value
                pph_terutang16 = document.querySelector('#pph_terutang16').value

                var data = {
                    pengenaan: [pengenaan_pajak1, pengenaan_pajak2, pengenaan_pajak3, pengenaan_pajak4, pengenaan_pajak5, pengenaan_pajak6,
                        pengenaan_pajak7, pengenaan_pajak8, pengenaan_pajak9, pengenaan_pajak10, pengenaan_pajak11, pengenaan_pajak12,
                        pengenaan_pajak14, pengenaan_pajak15, pengenaan_pajak16
                    ],
                    pphterutang: [pph_terutang1, pph_terutang2, pph_terutang3, pph_terutang4, pph_terutang5, pph_terutang6, pph_terutang7,
                        pph_terutang8, pph_terutang9, pph_terutang10, pph_terutang11, pph_terutang12, pph_terutang14, pph_terutang15, pph_terutang16
                    ]
                }
                console.log(data);
                $.ajax({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    type: "POST",
                    url: 'http://localhost:8000/FormulirIIIA_Point/Store',
                    data: data,
                    success: function(res) {
                        console.log(res)
                    }
                });

            }

            function BagianADelete(nama) {


                $.ajax({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    type: "POST",
                    url: 'http://localhost:8000/FormulirIIIA_Point/delete',
                    success: function(res) {
                        location.reload()
                    }
                });

            }
        </script>
        <button type="button" onclick="BagianA(this)">Simpan</button>
        <button type="button" onclick="BagianADelete('A_TblHarta')">Hapus</button>

        <p style=" font-size: 11px; padding: 10px 0px 0px 0px">BAGIAN B. PENGHASILAN YANG TIDAK TERMASUK OBJEK PAJAK</p>
        <table id="#mytable" class="display" style="width:100%">
            <tr>
                <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 4%;  height: 30px">NO.</th>
                <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 50%">JENIS PENGHASILAN</th>
                <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 50%">DASAR PENGENAAN PAJAK/PENGHASILAN BRUTO</th>
            </tr>
            <tr>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 4%; height: 20px">(1)</td>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 50%; height: 20px">(2)</td>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 50%; height: 20px">(3)</td>
            </tr>
            <tr>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 4%;  height: 30px">1.</td>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold; width: 50%">BANTUAN / SUMBANGAN / HIBAH</td>
                <td style="border: 1px solid black;"><input value="{{ $formulir_iiib[0]->rupiah_dsrPengenaan_PajakB ?? '' }}" type="text" class="form-control" style="text-align: right; width: 100%; border: 1px solid white" oninput="format1(this.value)" name="bantuansumbanganhibah" id="bantuansumbanganhibah" placeholder="0"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 4%;  height: 30px">2.</td>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold; width: 50%">WARISAN</td>
                <td style="border: 1px solid black;"><input value="{{ $formulir_iiib[1]->rupiah_dsrPengenaan_PajakB ?? '' }}" type="text" class="form-control" style="text-align: right; width: 100%; border: 1px solid white" oninput="format1(this.value)" name="warisan" id="warisan" placeholder="0"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 4%;  height: 30px">3.</td>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold; width: 50%">BAGIAN LABA ANGGOTA PERSEOROAN KOMANDITER TIDAK ATAS SAHAM, PERSEKUTUAN,
                    PERKUMPULAN, FIRMA, KONGSI</td>
                <td style="border: 1px solid black;"><input value="{{ $formulir_iiib[2]->rupiah_dsrPengenaan_PajakB ?? '' }}" type="text" class="form-control" style="text-align: right; width: 100%; border: 1px solid white" oninput="format1(this.value)" name="bagianlaba" id="bagianlaba" placeholder="0"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 4%;  height: 30px">4.</td>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold; width: 50%">KLAIM ASURANSI KESEHATAN, KECELAKAAN, JIWA, DWIGUNA, BEASISWA</td>
                <td style="border: 1px solid black;"><input value="{{ $formulir_iiib[3]->rupiah_dsrPengenaan_PajakB ?? '' }}" type="text" class="form-control" style="text-align: right; width: 100%; border: 1px solid white" oninput="format1(this.value)" name="klaimasuransi" id="klaimasuransi" placeholder="0"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 4%;  height: 30px">5.</td>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold; width: 50%">BEASISWA</td>
                <td style="border: 1px solid black;"><input value="{{ $formulir_iiib[4]->rupiah_dsrPengenaan_PajakB ?? '' }}" type="text" class="form-control" style="text-align: right; width: 100%; border: 1px solid white" oninput="format1(this.value)" name="beasiswa" id="beasiswa" placeholder="0"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 4%;  height: 30px">6.</td>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold; width: 50%">PENGHASILAN LAIN YANG TIDAK TERMASUK OBJEK PAJAK</td>
                <td style="border: 1px solid black;"><input value="{{ $formulir_iiib[5]->rupiah_dsrPengenaan_PajakB ?? '' }}" type="text" class="form-control" style="text-align: right; width: 100%; border: 1px solid white" oninput="format1(this.value)" name="penghasilanlain" id="penghasilanlain" placeholder="0"></td>

            </tr>
            <tr>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 20px;  height: 30px"></td>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold; width: 250px">JUMLAH BAGIAN B</td>
                <td style="border: 1px solid black; background-color: #F0E68C;"><input type="text" class="form-control" disabled="true" readonly="readonly" style="background-color: #F0E68C; text-align: right" name="hasil1" id="hasil1"></td>

            </tr>
        </table>

        <script>
            function BagianB() {
                bantuansumbanganhibah = document.querySelector('#bantuansumbanganhibah').value
                warisan = document.querySelector('#warisan').value
                bagianlaba = document.querySelector('#bagianlaba').value
                klaimasuransi = document.querySelector('#klaimasuransi').value
                beasiswa = document.querySelector('#beasiswa').value
                penghasilanlain = document.querySelector('#penghasilanlain').value

                var data = {
                    bantuansumbanganhibah: [bantuansumbanganhibah, warisan, bagianlaba, klaimasuransi, beasiswa, penghasilanlain],
                }

                console.log(data);
                $.ajax({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    type: "POST",
                    url: 'http://localhost:8000/FormulirIIIB_Point/Store',
                    data: data,
                    success: function(res) {
                        console.log(res)
                    }
                });

            }

            function BagianBDelete(nama) {
                $.ajax({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    type: "POST",
                    url: 'http://localhost:8000/FormulirIIIB_Point/delete',
                    success: function(res) {
                        location.reload()
                    }
                });

            }
        </script>
        <button type="button" onclick="BagianB(this)">Simpan</button>
        <button type="button" onclick="BagianBDelete('A_TblHarta')">Hapus</button>

        <p style="font-size: 11px; padding: 10px 0px 0px 0px">BAGIAN C. PENGHASILAN ISTERI/SUAMI YANG DIKENAKAN PAJAK SECARA TERPISAH</p>
        <table id="#mytable" class="display" style="width:100%">
            <tr>
                <td style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 54%; height: 30px">PENGHASILAN NETO ISTERI/SUAMI YANG DIKENAKAN PAJAK SECARA TERPISAH</td>
                <td style="border: 1px solid black;"><input value="{{ $formulir_iiic[0]->rupiah_dsrPengenaan_PajakC ?? '' }}" class="text" style="text-align: right; width: 100%; border: 1px solid white" placeholder="0" oninput="format2(this.value)" name="pajak_terpisah" id="pajak_terpisah">
                </td>
            </tr>
        </table>
        <button type="button" onclick="BagianC(this)">Simpan</button>
        <button type="button" onclick="BagianCDelete('A_TblHarta')">Hapus</button>
        </form>

        <script>
            
            function BagianC() {
                pajak_terpisah = document.querySelector('#pajak_terpisah').value

                var data = {
                    pajak_terpisah: pajak_terpisah,
                }

                console.log(data);
                $.ajax({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    type: "POST",
                    url: 'http://localhost:8000/FormulirIIIC_Point/Store',
                    data: data,
                    success: function(res) {
                        console.log(res)
                    }
                });
            }
            function BagianCDelete(nama) {
                $.ajax({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    type: "POST",
                    url: 'http://localhost:8000/FormulirIIIC_Point/delete',
                    success: function(res) {
                        location.reload()
                    }
                });

            }
        </script>


    </div>
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>

    <script src="//cdnjs.cloudflare.com/ajax/libs/numeral.js/2.0.6/numeral.min.js"></script>


    <script>
        $(document).ready(function() {
            formatNpwp2();
            formatPajakFinal();
            format1();
        });

        function myFunction($this) {
            var $tableBody = $('#harta'),
                $trLast = $tableBody.find("tr:last"),
                $trNew = $trLast.clone();
            $trLast.after($trNew);
        }

        const checkbox = document.getElementById('pembetulan2')
        const button1 = document.getElementById('selanjutnya')
        const button2 = document.getElementById('pph46')

        checkbox.addEventListener('change', (event) => {
            if (event.currentTarget.checked) {
                button2.style.display = 'inline-block';
                button1.style.display = 'none';

            } else {
                button1.style.display = 'inline-block';
                button2.style.display = 'none';
            }
        })

        function myFunction2(event) {
            console.log(event)
            // Get the checkbox
            var checkBox = document.getElementById("pembetulan");
            // Get the output text
            var text = document.getElementById("text");

            // If the checkbox is checked, display the output text
            if (checkBox.checked == true) {
                alert('test1')
                // text.style.display = "block";
            } else {
                alert('test2')

                // text.style.display = "none";
            }
        }
    </script>
    <script>
        function formatJnsPenghasilan1() {
            valuePengenaanPajak1 = numeral(pengenaan_pajak1.value);
            pengenaan_pajak1 = document.getElementById('pengenaan_pajak1');
            pengenaan_pajak1.value = valuePengenaanPajak1.format();
            console.log(numeral(document.getElementById('pph_terutang1').value)._value, numeral(pengenaan_pajak1.value)._value)
            if (numeral(document.getElementById('pph_terutang1').value)._value < numeral(pengenaan_pajak1.value)._value) {
                formatPajakFinal()
            } else {
                document.getElementById('pph_terutang1').value = 0;
                alert('Nilai PPh Terutang Harus Lebih Kecil dari Dasar Pengenaannya');
            }
        }

        function formatJnsPenghasilan2() {
            valuePengenaanPajak2 = numeral(pengenaan_pajak2.value);
            pengenaan_pajak2 = document.getElementById('pengenaan_pajak2');
            pengenaan_pajak2.value = valuePengenaanPajak2.format();
            console.log(numeral(document.getElementById('pph_terutang2').value)._value < numeral(pengenaan_pajak2.value)._value)
            if (numeral(document.getElementById('pph_terutang2').value)._value < numeral(pengenaan_pajak2.value)._value) {
                formatPajakFinal()
            } else {
                document.getElementById('pph_terutang2').value = 0;
                alert('Nilai PPh Terutang Harus Lebih Kecil dari Dasar Pengenaannya');
            }
        }

        function formatJnsPenghasilan3() {
            valuePengenaanPajak3 = numeral(pengenaan_pajak3.value);
            pengenaan_pajak3 = document.getElementById('pengenaan_pajak3');
            pengenaan_pajak3.value = valuePengenaanPajak3.format();
            console.log(numeral(document.getElementById('pph_terutang3').value)._value < numeral(pengenaan_pajak3.value)._value)
            if (numeral(document.getElementById('pph_terutang3').value)._value < numeral(pengenaan_pajak3.value)._value) {
                formatPajakFinal()
            } else {
                document.getElementById('pph_terutang3').value = 0;
                alert('Nilai PPh Terutang Harus Lebih Kecil dari Dasar Pengenaannya');
            }
        }

        function formatJnsPenghasilan4() {
            valuePengenaanPajak4 = numeral(pengenaan_pajak4.value);
            pengenaan_pajak4 = document.getElementById('pengenaan_pajak4');
            pengenaan_pajak4.value = valuePengenaanPajak4.format();
            console.log(numeral(document.getElementById('pph_terutang4').value)._value < numeral(pengenaan_pajak4.value)._value)
            if (numeral(document.getElementById('pph_terutang4').value)._value < numeral(pengenaan_pajak4.value)._value) {
                formatPajakFinal()
            } else {
                document.getElementById('pph_terutang4').value = 0;
                alert('Nilai PPh Terutang Harus Lebih Kecil dari Dasar Pengenaannya');
            }
        }

        function formatJnsPenghasilan5() {
            valuePengenaanPajak5 = numeral(pengenaan_pajak5.value);
            pengenaan_pajak5 = document.getElementById('pengenaan_pajak5');
            pengenaan_pajak5.value = valuePengenaanPajak5.format();
            console.log(numeral(document.getElementById('pph_terutang5').value)._value < numeral(pengenaan_pajak5.value)._value)
            if (numeral(document.getElementById('pph_terutang5').value)._value < numeral(pengenaan_pajak5.value)._value) {
                formatPajakFinal()
            } else {
                document.getElementById('pph_terutang5').value = 0;
                alert('Nilai PPh Terutang Harus Lebih Kecil dari Dasar Pengenaannya');
            }
        }

        function formatJnsPenghasilan6() {
            valuePengenaanPajak6 = numeral(pengenaan_pajak6.value);
            pengenaan_pajak6 = document.getElementById('pengenaan_pajak6');
            pengenaan_pajak6.value = valuePengenaanPajak6.format();
            console.log(numeral(document.getElementById('pph_terutang6').value)._value < numeral(pengenaan_pajak6.value)._value)
            if (numeral(document.getElementById('pph_terutang6').value)._value < numeral(pengenaan_pajak6.value)._value) {
                formatPajakFinal()
            } else {
                document.getElementById('pph_terutang6').value = 0;
                alert('Nilai PPh Terutang Harus Lebih Kecil dari Dasar Pengenaannya');
            }
        }

        function formatJnsPenghasilan7() {
            valuePengenaanPajak7 = numeral(pengenaan_pajak7.value);
            pengenaan_pajak7 = document.getElementById('pengenaan_pajak7');
            pengenaan_pajak7.value = valuePengenaanPajak7.format();
            console.log(numeral(document.getElementById('pph_terutang7').value)._value < numeral(pengenaan_pajak7.value)._value)
            if (numeral(document.getElementById('pph_terutang6').value)._value < numeral(pengenaan_pajak7.value)._value) {
                formatPajakFinal()
            } else {
                document.getElementById('pph_terutang7').value = 0;
                alert('Nilai PPh Terutang Harus Lebih Kecil dari Dasar Pengenaannya');
            }
        }

        function formatJnsPenghasilan8() {
            valuePengenaanPajak8 = numeral(pengenaan_pajak8.value);
            pengenaan_pajak8 = document.getElementById('pengenaan_pajak8');
            pengenaan_pajak8.value = valuePengenaanPajak8.format();
            console.log(numeral(document.getElementById('pph_terutang8').value)._value < numeral(pengenaan_pajak8.value)._value)
            if (numeral(document.getElementById('pph_terutang8').value)._value < numeral(pengenaan_pajak8.value)._value) {
                formatPajakFinal()
            } else {
                document.getElementById('pph_terutang8').value = 0;
                alert('Nilai PPh Terutang Harus Lebih Kecil dari Dasar Pengenaannya');
            }
        }

        function formatJnsPenghasilan9() {
            valuePengenaanPajak9 = numeral(pengenaan_pajak9.value);
            pengenaan_pajak9 = document.getElementById('pengenaan_pajak9');
            pengenaan_pajak9.value = valuePengenaanPajak9.format();
            console.log(numeral(document.getElementById('pph_terutang9').value)._value < numeral(pengenaan_pajak9.value)._value)
            if (numeral(document.getElementById('pph_terutang9').value)._value < numeral(pengenaan_pajak9.value)._value) {
                formatPajakFinal()
            } else {
                document.getElementById('pph_terutang9').value = 0;
                alert('Nilai PPh Terutang Harus Lebih Kecil dari Dasar Pengenaannya');
            }
        }

        function formatJnsPenghasilan10() {
            valuePengenaanPajak10 = numeral(pengenaan_pajak10.value);
            pengenaan_pajak10 = document.getElementById('pengenaan_pajak10');
            pengenaan_pajak10.value = valuePengenaanPajak10.format();
            console.log(numeral(document.getElementById('pph_terutang10').value)._value < numeral(pengenaan_pajak10.value)._value)
            if (numeral(document.getElementById('pph_terutang10').value)._value < numeral(pengenaan_pajak10.value)._value) {
                formatPajakFinal()
            } else {
                document.getElementById('pph_terutang10').value = 0;
                alert('Nilai PPh Terutang Harus Lebih Kecil dari Dasar Pengenaannya');
            }
        }

        function formatJnsPenghasilan11() {
            valuePengenaanPajak11 = numeral(pengenaan_pajak11.value);
            pengenaan_pajak11 = document.getElementById('pengenaan_pajak11');
            pengenaan_pajak11.value = valuePengenaanPajak11.format();
            console.log(numeral(document.getElementById('pph_terutang11').value)._value < numeral(pengenaan_pajak11.value)._value)
            if (numeral(document.getElementById('pph_terutang11').value)._value < numeral(pengenaan_pajak11.value)._value) {
                formatPajakFinal()
            } else {
                document.getElementById('pph_terutang11').value = 0;
                alert('Nilai PPh Terutang Harus Lebih Kecil dari Dasar Pengenaannya');
            }
        }

        function formatJnsPenghasilan12() {
            valuePengenaanPajak12 = numeral(pengenaan_pajak12.value);
            pengenaan_pajak12 = document.getElementById('pengenaan_pajak12');
            pengenaan_pajak12.value = valuePengenaanPajak12.format();
            console.log(numeral(document.getElementById('pph_terutang12').value)._value < numeral(pengenaan_pajak12.value)._value)
            if (numeral(document.getElementById('pph_terutang12').value)._value < numeral(pengenaan_pajak12.value)._value) {
                formatPajakFinal()
            } else {
                document.getElementById('pph_terutang12').value = 0;
                alert('Nilai PPh Terutang Harus Lebih Kecil dari Dasar Pengenaannya');
            }
        }

        function formatJnsPenghasilan14() {
            valuePengenaanPajak14 = numeral(pengenaan_pajak14.value);
            pengenaan_pajak14 = document.getElementById('pengenaan_pajak14');
            pengenaan_pajak14.value = valuePengenaanPajak14.format();
            console.log(numeral(document.getElementById('pph_terutang14').value)._value < numeral(pengenaan_pajak14.value)._value)
            if (numeral(document.getElementById('pph_terutang14').value)._value < numeral(pengenaan_pajak14.value)._value) {
                formatPajakFinal()
            } else {
                document.getElementById('pph_terutang14').value = 0;
                alert('Nilai PPh Terutang Harus Lebih Kecil dari Dasar Pengenaannya');
            }
        }

        function formatJnsPenghasilan15() {
            valuePengenaanPajak15 = numeral(pengenaan_pajak15.value);
            pengenaan_pajak15 = document.getElementById('pengenaan_pajak15');
            pengenaan_pajak15.value = valuePengenaanPajak15.format();
            console.log(numeral(document.getElementById('pph_terutang15').value)._value < numeral(pengenaan_pajak15.value)._value)
            if (numeral(document.getElementById('pph_terutang15').value)._value < numeral(pengenaan_pajak15.value)._value) {
                formatPajakFinal()
            } else {
                document.getElementById('pph_terutang15').value = 0;
                alert('Nilai PPh Terutang Harus Lebih Kecil dari Dasar Pengenaannya');
            }
        }

        function formatJnsPenghasilan16() {
            valuePengenaanPajak16 = numeral(pengenaan_pajak16.value);
            pengenaan_pajak16 = document.getElementById('pengenaan_pajak16');
            pengenaan_pajak16.value = valuePengenaanPajak16.format();
            console.log(numeral(document.getElementById('pph_terutang16').value)._value < numeral(pengenaan_pajak16.value)._value)
            if (numeral(document.getElementById('pph_terutang16').value)._value < numeral(pengenaan_pajak16.value)._value) {
                formatPajakFinal()
            } else {
                document.getElementById('pph_terutang16').value = 0;
                alert('Nilai PPh Terutang Harus Lebih Kecil dari Dasar Pengenaannya');
            }
        }

        function formatPajakFinal() {
            valuePengenaanPajak1 = numeral(pengenaan_pajak1.value);
            document.getElementById('pengenaan_pajak1').value = valuePengenaanPajak1.format();
            valuePPhTerutang1 = numeral(pph_terutang1.value);
            document.getElementById('pph_terutang1').value = valuePPhTerutang1.format();

            valuePengenaanPajak2 = numeral(pengenaan_pajak2.value);
            document.getElementById('pengenaan_pajak2').value = valuePengenaanPajak2.format();
            valuePPhTerutang2 = numeral(pph_terutang2.value);
            document.getElementById('pph_terutang2').value = valuePPhTerutang2.format();

            valuePengenaanPajak3 = numeral(pengenaan_pajak3.value);
            document.getElementById('pengenaan_pajak3').value = valuePengenaanPajak3.format();
            valuePPhTerutang3 = numeral(pph_terutang3.value);
            document.getElementById('pph_terutang3').value = valuePPhTerutang3.format();

            valuePengenaanPajak4 = numeral(pengenaan_pajak4.value);
            document.getElementById('pengenaan_pajak4').value = valuePengenaanPajak4.format();
            valuePPhTerutang4 = numeral(pph_terutang4.value);
            document.getElementById('pph_terutang4').value = valuePPhTerutang4.format();

            valuePengenaanPajak5 = numeral(pengenaan_pajak5.value);
            document.getElementById('pengenaan_pajak5').value = valuePengenaanPajak5.format();
            valuePPhTerutang5 = numeral(pph_terutang5.value);
            document.getElementById('pph_terutang5').value = valuePPhTerutang5.format();

            valuePengenaanPajak6 = numeral(pengenaan_pajak6.value);
            document.getElementById('pengenaan_pajak6').value = valuePengenaanPajak6.format();
            valuePPhTerutang6 = numeral(pph_terutang6.value);
            document.getElementById('pph_terutang6').value = valuePPhTerutang6.format();

            valuePengenaanPajak7 = numeral(pengenaan_pajak7.value);
            document.getElementById('pengenaan_pajak7').value = valuePengenaanPajak7.format();
            valuePPhTerutang7 = numeral(pph_terutang7.value);
            document.getElementById('pph_terutang7').value = valuePPhTerutang7.format();

            valuePengenanPajak8 = numeral(pengenaan_pajak8.value);
            document.getElementById('pengenaan_pajak8').value = valuePengenanPajak8.format();
            valuePPhTerutang8 = numeral(pph_terutang8.value);
            document.getElementById('pph_terutang8').value = valuePPhTerutang8.format();

            valuePengenaanPajak9 = numeral(pengenaan_pajak9.value);
            document.getElementById('pengenaan_pajak9').value = valuePengenaanPajak9.format();
            valuePPhTerutang9 = numeral(pph_terutang9.value);
            document.getElementById('pph_terutang9').value = valuePPhTerutang9.format();

            valuePengenaanPajak10 = numeral(pengenaan_pajak10.value);
            document.getElementById('pengenaan_pajak10').value = valuePengenaanPajak10.format();
            valuePPhTerutang10 = numeral(pph_terutang10.value);
            document.getElementById('pph_terutang10').value = valuePPhTerutang10.format();

            valuePengenaanPajak11 = numeral(pengenaan_pajak11.value);
            document.getElementById('pengenaan_pajak11').value = valuePengenaanPajak11.format();
            valuePPhTerutang11 = numeral(pph_terutang11.value);
            document.getElementById('pph_terutang11').value = valuePPhTerutang11.format();

            valuePengenaanPajak12 = numeral(pengenaan_pajak12.value);
            document.getElementById('pengenaan_pajak12').value = valuePengenaanPajak12.format();
            valuePPhTerutang12 = numeral(pph_terutang12.value);
            document.getElementById('pph_terutang12').value = valuePPhTerutang12.format();

            valuePengenaanPajak14 = numeral(pengenaan_pajak14.value);
            document.getElementById('pengenaan_pajak14').value = valuePengenaanPajak14.format();
            valuePPhTerutang14 = numeral(pph_terutang14.value);
            document.getElementById('pph_terutang14').value = valuePPhTerutang14.format();

            valuePengenaanPajak15 = numeral(pengenaan_pajak15.value);
            document.getElementById('pengenaan_pajak15').value = valuePengenaanPajak15.format();
            valuePPhTerutang15 = numeral(pph_terutang15.value);
            document.getElementById('pph_terutang15').value = valuePPhTerutang15.format();

            valuePengenaanPajak16 = numeral(pengenaan_pajak16.value);
            document.getElementById('pengenaan_pajak16').value = valuePengenaanPajak16.format();
            valuePPhTerutang16 = numeral(pph_terutang16.value);
            document.getElementById('pph_terutang16').value = valuePPhTerutang16.format();

            var resultPajakFinal = ((valuePPhTerutang1.value()) + (valuePPhTerutang2.value()) +
                (valuePPhTerutang3.value()) + (valuePPhTerutang4.value()) + (valuePPhTerutang5.value()) +
                (valuePPhTerutang6.value()) + (valuePPhTerutang7.value()) + (valuePPhTerutang8.value()) +
                (valuePPhTerutang9.value()) + (valuePPhTerutang10.value()) + (valuePPhTerutang11.value()) +
                (valuePPhTerutang12.value()) + (valuePPhTerutang14.value()) + (valuePPhTerutang15.value()) +
                (valuePPhTerutang16.value()));
            if (!isNaN(resultPajakFinal)) {
                document.getElementById('hasil').value = numeral(resultPajakFinal).format();
            }

        }

        function format1() {
            valueBantuanSumbanganHibah = numeral(bantuansumbanganhibah.value);
            document.getElementById('bantuansumbanganhibah').value = valueBantuanSumbanganHibah.format();

            valueWarisan = numeral(warisan.value);
            document.getElementById('warisan').value = valueWarisan.format();

            valueBagianLaba = numeral(bagianlaba.value);
            document.getElementById('bagianlaba').value = valueBagianLaba.format();

            valueKlaimAsuransi = numeral(klaimasuransi.value);
            document.getElementById('klaimasuransi').value = valueKlaimAsuransi.format();

            valueBeasiswa = numeral(beasiswa.value);
            document.getElementById('beasiswa').value = valueBeasiswa.format();

            valuePenghasilanLain = numeral(penghasilanlain.value);
            document.getElementById('penghasilanlain').value = valuePenghasilanLain.format();

            var result = ((valueBantuanSumbanganHibah.value()) + (valueWarisan.value()) + (valueBagianLaba.value()) + (valueKlaimAsuransi.value()) +
                (valueBeasiswa.value()) + (valuePenghasilanLain.value()));
            if (!isNaN(result)) {
                document.getElementById('hasil1').value = numeral(result).format();
            }

        }

        function format2() {
            valuePajakTerpisah = numeral(pajak_terpisah.value);
            document.getElementById('pajak_terpisah').value = valuePajakTerpisah.format();
        }

        function formatNpwp2() {
            formatnpwp = document.getElementById('formatnpwpfix').value
            formatnpwp2 = document.getElementById('formatnpwpfix')
            if (typeof formatnpwp === 'string') {

            }
            formatnpwp2.value = formatnpwp.replace(/(\d{2})(\d{3})(\d{3})(\d{1})(\d{3})(\d{3})/, '$1.$2.$3.$4-$5.$6');
        }
    </script>


    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"
        integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"
        integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous">
    </script>
    -->

</body>

</html>