<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js" integrity="sha512-aVKKRRi/Q/YV+4mjoKBsE4x3H+BkegoM/em46NNlCqNTmUYADjBbeNefNxYV7giUp0VxICtqdrbqU7iVaeZNXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <title>Formulir 1770</title>
    <style>
        .bg-grey {
            font-family: arial;
            background-color: #ccc;
            padding: 1% 10% 1% 10%;
        }

        .container {
            width: 90%;
            background-color: #fff;
        }

        .item1 .row .col-2 {
            padding: 50px 0px -10px 10px
        }

        .container h1 {
            font-size: 20px;
            font-weight: bold;
            text-align: center;
            margin-top: 30px;
        }

        .container h2 {
            font-size: 40px;
            font-weight: bold;
            text-align: center;
            margin-top: 30px;

        }

        .container p {
            font-size: 10px;
            font-weight: bold;
            text-align: center;
            margin-top: 30px;
        }

        .item1 .row .col-6 {
            border-left: 2px solid black;
            border-right: 2px solid black;
        }

        .item1 .row .col-6 .row {
            font-size: 18px;
            font-weight: bold;
            padding: 10px 10px 10px 40px;
            border-bottom: 2px solid black;
        }

        .judul {
            font-size: 12px;
            font-weight: bold;
        }

        .vericaltext {
            writing-mode: vertical-lr;
            text-orientation: use-glyph-orientation;
        }

        .item1 .row .col-4 {
            padding: 5px 10px 5px 10px;
        }

        .type button {
            font-size: 12px;
            width: 120px;
            height: 30px;
            margin-left: 10px
        }

        .type a {
            font-size: 12px;
            width: 120px;
            height: 30px;
            margin-left: 10px
        }

        .tahunpajak table tr th {
            text-align: center;
            width: 60px;
        }

        a {
            font-size: 12px;
            width: auto;
            height: auto;
            margin-left: 30px;
        }

        .year {
            border: 1px solid black;
            width: 20px;
            font-size: 25px;
        }

        table tr th {
            border: 1px solid black;
            font-size: 25px;
            text-align: center;
            width: 60px;

        }

        .form-check {
            display: inline-block;
            margin: 0px 10px 0px 0px;

        }

        .form-check-label {
            font-size: 14px;
            margin: 0px 10px 0px 0px;
        }

        .item1 .row .col-4 .col-sm-12 {
            background-color: #F0E68C;
            padding: 4px 10px 10px 10px;
            height: 30px
        }

        .item1 .row .col-4 .col-sm-12 label {
            font-size: 12px;
            text-align: center
        }

        b {
            font-size: 10px;
            margin-left: 10px;
        }

        .item2 .row label {
            font-size: 12px;
        }

        .item2 .row .form-control {
            border: 1px solid black;
            height: 30px;
            border-radius: 1px;
        }

        .item3 label {
            font-weight: bold;
            text-align: center
        }
    </style>
</head>

<body class="bg-grey">
    <div class="container">
        <div class="item1">
            <div class="row" style="border-bottom: 2px solid black;">
                <div class="col-2">
                    <h1>FORMULIR</h1>
                    <h2>1770</h2>
                    <p>KEMENTERIAN KEUANGAN
                        RI DIREKTORAT JENDERAL PAJAK
                    </p>
                </div>
                <div class="col-6">
                    <div class="row">
                        SPT TAHUNAN PPh WAJIB PAJAK ORANG PRIBADI
                    </div>
                    <div class="judul">
                        </br>BAGI WAJIB PAJAK YANG MEMPUNYAI PENGHASILAN :</br>
                        </br>*DARI USAHA/PEKERJAAN BEBAS</br>
                        *DARI SATU ATAU LEBIH PEMBERI KERJA</br>
                        *YANG DIKENAKAN PPh FINAL DAN/ATAU BERSIFAT FINAL; DAN/ATAU;</br>
                        *DALAM NEGERI LAINNYA ATAU LUAR NEGERI</br>
                    </div>
                </div>
                <div class="col-4 type" style="padding-top: 10px;">
                    <form action="/PH-MT">
                        <input type="hidden" name="penghasilanneto_total" value="{{ request()->all()['penghasilanneto_total'] ?? 0 }}">
                        <input type="hidden" name="hasil1" value="{{ request()->all()['hasil1'] ?? 0 }}">
                        <input type="hidden" name="hasil" value="{{ request()->all()['hasil'] ?? 0 }}" oninput="jumlah()" id="hasil">
                        <input type="hidden" name="hasilPPhDipotongDipungut" value="{{ request()->all()['hasilPPhDipotongDipungut'] ?? 0 }}" oninput="jumlah()" id="hasilPPhDipotongDipungut">
                        <a href="/formulir-I hal 2" class="btn btn-secondary">Sebelumnya</a>
                        <button type="submit" class="btn btn-secondary" id="SUBMIT">Submit</button>
                        <button class="btn btn-secondary" id="PH-MT" style="display: none">PH-MT</button>

                        <div class="row tahunpajak" style="padding: 4% 10%;">
                            <div class="col">
                                <table>
                                    <tr>
                                        <th>{{ mb_substr($spt['tahun'], 0, 1); }}</th>
                                        <th>{{ mb_substr($spt['tahun'], 1, 1); }}</th>
                                        <th>{{ mb_substr($spt['tahun'], 2, 1); }}</th>
                                        <th>{{ mb_substr($spt['tahun'], 3, 1); }}</th>
                                    </tr>
                                </table>
                            </div>
                        </div>
                        <div class="row" style="padding: 1% 10%;">
                            <div class="col-4">
                                <table>
                                    <tr>
                                        <th>0</th>
                                        <th>1</th>
                                        <th>{{ mb_substr($spt['tahun'], 2, 1); }}</th>
                                        <th>{{ mb_substr($spt['tahun'], 3, 1); }}</th>
                                    </tr>
                                </table>
                            </div>
                            <div class="col-2">
                                <p style="margin: 15px;">sd</p>
                            </div>
                            <div class="col-4">
                                <table>
                                    <tr>
                                        <th>1</th>
                                        <th>2</th>
                                        <th>{{ mb_substr($spt['tahun'], 2, 1); }}</th>
                                        <th>{{ mb_substr($spt['tahun'], 3, 1); }}</th>
                                    </tr>
                                </table>
                            </div>
                        </div>

                        <div class="form-check" style="display:inline-block">
                            <input style="display:inline;" class="form-check-input" type="radio" name="jenis" id="flexRadioDisabled" checked>
                            <label class="form-check-label" for="flexRadioDisabled" style="font-size: 14px;">
                                Pembukuan
                            </label>
                        </div>
                        <div class="form-check" style="display:inline-block">
                            <input class="form-check-input" type="radio" name="jenis" id="flexRadioCheckedDisabled">
                            <label class="form-check-label" for="flexRadioCheckedDisabled" style="font-size: 14px;">
                                Pencatatan
                            </label>
                        </div>
                        <div class="col-sm-12">
                            <div class="input-group mb-6">
                                <div class="input-group-prepend">
                                    <div style="margin-left: -11px">
                                        <input type="checkbox" aria-label="Checkbox for following text input" style="width: 20px;">
                                    </div>
                                </div>
                                <label class="col-sm-9">SPT Pembetulan Ke</label>
                                <input style="width:20px; height: 20px; border: 1px solid;">
                            </div>
                        </div>
                </div>
            </div>
        </div>

        <b>PERHATIAN *SEBELUM MENGISI BACALAH PETUNJUK PENGISIAN *ISI DENGAN HURU CETAK/DIKETIK
            DENGAN TINTA HITAM *BERI TANDA X DALAM KOTAK SESUAI PILIHAN</b>
        <div class="item2">
            <div class="col-sm-11.5" style="padding: 4px 20px 10px 10px ; height: auto; border: 4px solid; margin-left: 10px">
                <div class="row">
                    <label class="col-sm-4 col-form-label">NPWP</label>
                    <div class="col-sm-8">
                        <input class="form-control" type="text" placeholder="Masukkan NPWP" maxlength="20" oninput="npwpWajibPajak(this)" id="npwpWP">
                    </div>
                </div>
                <script>
                    function npwpWajibPajak() {
                        npwpWP = document.getElementById('npwpWP').value
                        npwpWP2 = document.getElementById('npwpWP')
                        if (!npwpWP.match(/^[0-9./-]+$/i) && npwpWP2.value.length != 0) {
                            alert('Angka saja')
                            npwpWP2.value = npwpWP.slice(0, -1);
                            return;
                        }
                        npwpWP2.value = npwpWP.replace(/(\d{2})(\d{3})(\d{3})(\d{1})(\d{3})(\d{3})/, '$1.$2.$3.$4-$5.$6');
                    }
                </script>
                <div class="row">
                    <label class="col-sm-4 col-form-label">NAMA WAJIB PAJAK</label>
                    <div class="col-sm-8">
                        <input class="form-control" type="text" placeholder="Masukkan Nama">
                    </div>
                </div>
                <div class="row">
                    <label class="col-sm-4 col-form-label">JENIS USAHA/PEKERJAAN BEBAS</label>
                    <div class="col-sm-5">
                        <input class="form-control" type="text" placeholder="Masukkan Jenis Usaha/Pekerjaan Bebas">
                    </div>
                    <label class="col-sm-1 col-form-label">KLU</label>
                    <div class="col-sm-2">
                        <input class="form-control" type="text" placeholder="KLU">
                    </div>
                </div>
                <div class="row">
                    <label class="col-sm-4 col-form-label">NO.TELEPON/FAKSIMILI</label>
                    <div class="col-sm-5">
                        <input class="form-control" type="text" placeholder="Masukkan No.Telepon/Faksimili">
                    </div>

                    <label class="col-sm-1 col-form-label">FAX</label>
                    <div class="col-sm-2">
                        <input class="form-control" type="text" placeholder="Masukkan Fax">
                    </div>
                </div>
                <div class="row">
                    <label class="col-sm-4 col-form-label">STATUS KEWAJIBAN PERPAJAKAN SUAMI-ISTERI</label>
                    <div class="col-sm-4" style="border: 1px solid black; height: 30px; background-color:#fff; margin-left:12px">
                        <div class="form-check" style="display:inline-block">
                            <input style="display:inline;" id="SUBMIT1" class="form-check-input" type="radio" name="status" id="flexRadioDisabled" checked>
                            <label class="form-check-label" for="flexRadioDisabled" style="font-size: 14px;">
                                KK
                            </label>
                        </div>
                        <div class="form-check" style="display:inline-block">
                            <input class="form-check-input" id="SUBMIT2" type="radio" name="status" id="flexRadioCheckedDisabled">
                            <label class="form-check-label" for="flexRadioCheckedDisabled" style="font-size: 14px;">
                                HB
                            </label>
                        </div>
                        <div class="form-check" style="display:inline-block">
                            <input class="form-check-input" id="PH" type="radio" name="status" id="flexRadioCheckedDisabled">
                            <label class="form-check-label" for="flexRadioCheckedDisabled" style="font-size: 14px;">
                                PH
                            </label>
                        </div>
                        <div class="form-check" style="display:inline-block">
                            <input class="form-check-input" id="PH1" type="radio" name="status" id="flexRadioCheckedDisabled">
                            <label class="form-check-label" for="flexRadioCheckedDisabled" style="font-size: 14px;">
                                MT
                            </label>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <label class="col-sm-4 col-form-label">NPWP SUAMI/ISTERI</label>
                    <div class="col-sm-8">
                        <input class="form-control" type="text" disabled="disabled">
                    </div>
                </div>
                <div class="item3">
                    <label>Permohonan perubahan data dapat disampaikan terpisah dari pelaporan SPT Tahunan Orang Pribadi ini, dengan menggunakan
                        Formulir Perubahan Data Wajib Pajak dan dilengkapi dokumen yang diisyaratkan
                    </label>
                </div>
            </div>
        </div>
        <div style="padding: 10px"></div>
        <!-- Table -->
        <table style="width: 99%; margin-left: 10px">
            <tr>
                <th style="border: 1px solid black; width: 75.2%; height: 20px; font-size: 11px; text-align: left">*)Pengisian kolom-kolom yang berisi nilai rupiah harus tanpa nilai desimal (contoh penulisan lihat petunjuk pengisian halaman 3)</th>
                <th style="border: 1px solid black; width: 25%; font-size: 11px; text-align: center">Rupiah</th>
            </tr>
        </table>
        <!-- Table A -->
        <table style="width: 99%; margin-left: 10px">
            <tr>
                <td style="border: 1px solid black; border-bottom: 0px; border-top: 0px; width: 7%; text-align: center;font-size: 11px ">A</td>
                <td style="border: 1px solid black; border-bottom: 0px; border-top: 0px; width: 55%;  font-size: 12px;">1. <span style="margin-left: 5px">PENGHASILAN NETO DALAM NEGERI DARI USAHA DAN/ATAU PEKERJAAN BEBAS</span> </br>
                    <u style="font-size: 11px; margin-left: 20px">[Diisi dari Formulir 1770-I Halaman 1 Jumlah Bagian A atau Formulir 1770-I Halaman 2 Jumlah Bagaian B Kolom 5]</u>
                </td>
                <td style="border: 1px solid black; border-top: 0px; width: 3%;  text-align: center; font-size:12px">1</td>
                <td style="border: 1px solid black; border-top: 0px; width: 18%; background-color: #F0E68C"><input type="text" style="width: 100%; border: 0px solid black; background-color: #F0E68C; text-align:right" id="penghasilanneto1" value="{{ request()->all()['hasil1'] ?? 0 }}" placeholder="0" oninput="formulir1770()"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; border-bottom: 0px; border-top: 0px; width: 5%; font-size:11px; text-align:center">PENGHASILAN</br>NETO</td>
                <td style="border: 1px solid black; border-bottom: 0px; border-top: 0px; width: 55%;  font-size: 12px">2. <span style="margin-left: 5px"> PENGHASILAN NETO DALAM NEGERI SEHUBUNGAN DENGAN PEKERJAAN</span></br>
                    <u style="font-size: 11px; margin-left: 20px">[Diisi dri Formulir 1770-I Halaman 2 Jumlah Bagian C Kolom 5]</u>
                </td>
                <td style="border: 1px solid black; border-top: 0px; width: 3%;  text-align: center; font-size:12px">2</td>
                <td style="border: 1px solid black; border-top: 0px; width: 17%; background-color: #F0E68C"><input type="text" style="width: 100%; border: 0px solid black; background-color: #F0E68C; text-align:right" placeholder="0" id="penghasilanneto2" value="{{ request()->all()['penghasilanneto_C'] ?? 0 }}" placeholder="0" oninput="formulir1770()"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; border-bottom: 0px; border-top: 0px; width: 5%; "></td>
                <td style="border: 1px solid black; border-bottom: 0px; border-top: 0px; width: 55%; ; font-size: 12px">3. <span style="margin-left: 5px">PENGHASILAN NETO DALAM NEGERI LAINNYA</span> </br>
                    <u style="font-size: 11px; margin-left: 20px">[Diisi dri Formulir 1770-I Halaman 2 Jumlah Bagian D Kolom 3]</u>
                </td>
                <td style="border: 1px solid black; border-top: 0px; width: 3%;  text-align: center;  font-size:12px">3</td>
                <td style="border: 1px solid black; border-top: 0px; width: 17%; background-color: #F0E68C"><input type="text" style="width: 100%; border: 0px solid black; background-color: #F0E68C; text-align: right" placeholder="0" id="penghasilanneto3" value="{{ request()->all()['hasilnetolain'] ?? 0 }}" oninput="formulir1770()"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; border-bottom: 0px; border-top: 0px; width: 5%; "></td>
                <td style="border: 1px solid black; border-bottom: 0px; border-top: 0px; width: 55%; ; font-size: 12px">4. <span style="margin-left: 5px">PENGHASILAN NETO LUAR NEGERI</span> </br>
                    <u style="font-size: 11px; margin-left: 20px">[Apabila memiliki penghasilan dari luar negeri agar diisi dari Lampiran Tersendiri, lihat petunjuk pengisian]</u>
                </td>
                <td style="border: 1px solid black; border-top: 0px; width: 3%;  text-align: center;  font-size:12px">4</td>
                <td style="border: 1px solid black; border-top: 0px; width: 17%; "><input type="text" style="width: 100%; border: 0px solid black; text-align:right" placeholder="0" id="penghasilanneto4" oninput="formulir1770()"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; border-bottom: 0px; border-top: 0px; width: 5%; "></td>
                <td style="border: 1px solid black; border-bottom: 0px; border-top: 0px; width: 55%; ; font-size: 12px">5. <span style="margin-left: 5px">JUMLAH PENGHASILAN NETO (1+2+3+4)</span></br></br></td>
                <td style="border: 1px solid black; border-top: 0px; width: 3%;  text-align: center;  font-size:12px">5</td>
                <td style="border: 1px solid black; border-top: 0px; width: 17%; background-color: #F0E68C"><input type="text" style="width: 100%; border: 0px solid black; background-color: #F0E68C; text-align:right" placeholder="0" id="penghasilanneto5" oninput="formulir1770()"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; border-bottom: 0px; border-top: 0px; width: 5%; "></td>
                <td style="border: 1px solid black; border-bottom: 0px; border-top: 0px; width: 55%; ; font-size: 12px">6. <span style="margin-left: 5px">ZAKAT / SUMBANGAN KEAGAMAAN YANG BERSIFAT WAJIB</span></br></br></td>
                <td style="border: 1px solid black; border-top: 0px; width: 3%;  text-align: center;  font-size:12px">6</td>
                <td style="border: 1px solid black; border-top: 0px; width: 17%; "><input type="text" style="width: 100%; border: 0px solid black; text-align:right" placeholder="0" id="penghasilanneto6" oninput="formulir1770()"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; border-top: 0px; width: 5%; "></td>
                <td style="border: 1px solid black; border-top: 0px; width: 55%; ; font-size: 12px">7. <span style="margin-left: 5px">JUMLAH PENGHASILAN NETO SETELAH PENGURANGAN ZAKAT/SUMBANGAN</span></br> <span style="margin-left: 20px">KEAGAMAAN YANG SIFATNYA WAJIB (5-6)</span></td>
                <td style="border: 1px solid black; border-top: 0px; width: 3%;  text-align: center;  font-size:12px">7</td>
                <td style="border: 1px solid black; border-top: 0px; width: 17%; background-color: #F0E68C"><input type="text" style="width: 100%; border: 0px solid black; background-color: #F0E68C; text-align:right" placeholder="0" id="penghasilanneto7" oninput="formulir1770()"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; border-bottom: 0px; border-top: 0px; width: 5%; font-size: 11px; text-align:center">B</td>
                <td style="border: 1px solid black; border-bottom: 0px; border-top: 0px; width: 55%; ; font-size: 12px">8. <span style="margin-left: 5px">KOMPENSASI KERUGIAN</span></br></br></td>
                <td style="border: 1px solid black; border-top: 0px; width: 3%;  text-align: center;  font-size:12px">8</td>
                <td style="border: 1px solid black; border-top: 0px; width: 17%"><input type="text" style="width: 100%; border: 0px solid black; text-align:right" placeholder="0" id="penghasilankenapajak8" oninput="formulir1770()"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; border-bottom: 0px; border-top: 0px; width: 5%; font-size: 11px; text-align:center">PENGHASILAN</br>KENA PAJAK</td>
                <td style="border: 1px solid black; border-bottom: 0px; border-top: 0px; width: 55%; ; font-size: 12px">9. <span style="margin-left: 5px">JUMLAH PENGHASILAN NETO SETELAH KOMPENSASI KERUGIAN (7-8)</span></br></br></td>
                <td style="border: 1px solid black; border-top: 0px; width: 3%;  text-align: center;  font-size:12px">9</td>
                <td style="border: 1px solid black; border-top: 0px; width: 17%; background-color: #F0E68C"><input type="text" style="width: 100%; border: 0px solid black; background-color: #F0E68C; text-align:right" placeholder="0" id="penghasilankenapajak9" oninput="formulir1770()"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; border-bottom: 0px; border-top: 0px; width: 5%;"></td>
                <td style="border: 1px solid black; border-bottom: 0px; border-top: 0px; width: 55%; ; font-size: 12px">10. <span style="margin-left: 5px">PENGHASILAN TIDAK KENA PAJAK &emsp; &emsp; &emsp;</span>
                    <div class="form-check" style="display:inline-block">
                        <input style="display:inline;" class="form-check-input" type="radio" name="ptkp">
                        <label class="form-check-label" for="flexRadioDisabled" style="font-size: 12px;">
                            TK
                        </label>
                    </div>
                    <div class="form-check" style="display:inline-block">
                        <input class="form-check-input" type="radio" name="ptkp" checked>
                        <label class="form-check-label" for="flexRadioCheckedDisabled" style="font-size: 12px;">
                            K
                        </label>
                    </div>
                    <div class="form-check" style="display:inline-block">
                        <input class="form-check-input" type="radio" name="ptkp">
                        <label class="form-check-label" for="flexRadioCheckedDisabled" style="font-size: 12px;">
                            K/I
                        </label>
                    </div>
                    <select class="col-sm-1" style="height: 20px; width: 50px; border: 1px solid black" oninput="formulir1770()" id="pilihanPTKP">
                        <option value="0">Pilih</option>
                        <option value="54000000">TK/0</option>
                        <option value="58500000">TK/1</option>
                        <option value="63000000">TK/2</option>
                        <option value="67500000">TK/3</option>
                        <option value="58500000">K/0</option>
                        <option value="63000000">K/1</option>
                        <option value="67500000">K/2</option>
                        <option value="72000000">K/3</option>
                        <option value="112500000">K/I/0</option>
                        <option value="117000000">K/I/1</option>
                        <option value="121500000">K/I/2</option>
                        <option value="126000000">K/I/3</option>
                    </select>
                    <!-- <script>
                        function pilihanTK() {
                            var data = document.getElementById("TK").value;
                            console.log(data);
                            document.getElementById("tpkp").value = numeral(data).format();

                        }
                    </script> -->
                    <!-- <select class="col-sm-1" id="K" onchange="pilihanK()" style="height: 20px; width: 50px; border: 1px solid black; display:none ">
                        <option value="0">Pilih</option>
                        
                    </select> -->
                    <!-- <script>
                        function pilihanK() {
                            var data = document.getElementById("K").value;
                            console.log(data);
                            document.getElementById("tpkp").value = numeral(data).format();
                        }
                    </script> -->
                    <!-- <select class="col-sm-1" id="K/I" onchange="pilihanKI()" style="height: 20px; width: 50px; border: 1px solid black; display:none">
                        <option value="0">Pilih</option>
                       
                    </select> -->
                    <!-- <script>
                        function pilihanKI() {
                            var data = document.getElementById("K/I").value;
                            console.log(data);
                            document.getElementById("tpkp").value = numeral(data).format();
                        }
                    </script>
                    <script>
                        function ChangePTKP(src) {
                            const myElement = document.getElementById("TK");
                            const myElement2 = document.getElementById("K");
                            const myElement3 = document.getElementById("K/I");
                            myElement.style.display = "block";
                            myElement2.style.display = "none";
                            myElement3.style.display = "none";
                        }

                        function ChangePTKP2(src) {
                            const myElement = document.getElementById("TK");
                            const myElement2 = document.getElementById("K");
                            const myElement3 = document.getElementById("K/I");
                            myElement.style.display = "none";
                            myElement2.style.display = "block";
                            myElement3.style.display = "none";
                        }

                        function ChangePTKP3(src) {
                            const myElement = document.getElementById("TK");
                            const myElement2 = document.getElementById("K");
                            const myElement3 = document.getElementById("K/I");
                            myElement.style.display = "none";
                            myElement2.style.display = "none";
                            myElement3.style.display = "block";

                        } -->
                    </script>
                </td>
                <td style="border: 1px solid black; border-top: 0px; width: 3%;  text-align: center;  font-size:12px">10</td>
                <td style="border: 1px solid black; border-top: 0px; width: 17%; background-color: #F0E68C "><input type="text" style="width: 100%; border: 0px solid black; background-color: #F0E68C; text-align:right" placeholder="0" oninput="formulir1770()" id="inputPTKP"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; border-top: 0px; width: 5%; "></td>
                <td style="border: 1px solid black; border-top: 0px; width: 55%; ; font-size: 12px">11. <span style="margin-left: 5px">PENGHASILAN KENA PAJAK (9-10) &emsp; &emsp; &emsp;</span>
                </td>

                <td style="border: 1px solid black; border-top: 0px; width: 3%;  text-align: center;  font-size:12px">11</td>
                <td style="border: 1px solid black; border-top: 0px; width: 17%; background-color: #F0E68C"><input type="text" style="width: 100%; border: 0px solid black; background-color: #F0E68C; text-align:right" placeholder="0" id="penghasilankenapajak11" oninput="formulir1770()"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; border-bottom: 0px; border-top: 0px; width: 5%; font-size: 11px; text-align:center">C</td>
                <td style="border: 1px solid black; border-bottom: 0px; border-top: 0px; width: 55%; ; font-size: 12px">12. <span style="margin-left: 5px">PPh TERUTANG (TARIF PASAL 17 UU PPh X ANGKA 11) &emsp; &emsp; &emsp; </span>
                    <input type="checkbox" aria-label="Checkbox for following text input" style="margin-left: -15px;" name="check" id="PerhitunganSendiri" onclick="formulir1770(this)">
                    <label for="exampleFormControlInput1" class="form-label" style="font-size: 12px;">Menggunakan Perhitungan Sendiri</label>
                </td>
                <td style="border: 1px solid black; border-top: 0px; width: 3%;  text-align: center;  font-size:12px">12</td>
                <td style="border: 1px solid black; border-top: 0px; width: 17%; background-color: #F0E68C"><input type="text" style="width: 100%; border: 0px solid black; background-color: #F0E68C; text-align:right" placeholder="0" id="pphterutang12" disabled oninput="formulir1770()"></td>
            </tr>
            <script>
                function jumlah2() {
                    valueinputperhitungan = numeral(InputPerhitungan.value);
                    document.getElementById('InputPerhitungan').value = valueinputperhitungan.format();

                    valuePengembalian = numeral(pengembalian.value);
                    document.getElementById('pengembalian').value = valuePengembalian.format();

                    var resultnetoLain6 = ((valueinputperhitungan.value()) + (valuePengembalian.value()))
                    document.getElementById('pengembalian1').value = resultnetoLain6;
                }
            </script>
            <tr>
                <td style="border: 1px solid black; border-bottom: 0px; border-top: 0px; width: 5%; font-size: 11px; text-align:center">PPh</br>TERUTANG</td>
                <td style="border: 1px solid black; border-bottom: 0px; border-top: 0px; width: 55%; ; font-size: 12px">13. <span style="margin-left: 5px">PENGEMBALIAN/PENGURANGAN PPh PASAL 24 YANG TELAH DIKREDITKAN</br></span> </td>
                <td style="border: 1px solid black; border-top: 0px; width: 3%;  text-align: center;  font-size:12px">13</td>
                <td style="border: 1px solid black; border-top: 0px; width: 17%; "><input type="text" style="width: 100%; border: 0px solid black; text-align:right" placeholder="0" oninput="formulir1770()" id="pphterutang13"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; border-top: 0px; width: 5%; font-size: 11px; text-align:center"></td>
                <td style="border: 1px solid black; border-top: 0px; width: 55%; ; font-size: 12px">14. <span style="margin-left: 5px">JUMLAH PPh TERUTANG (12 + 13)</br></span> </td>
                <td style="border: 1px solid black; border-top: 0px; width: 3%;  text-align: center;  font-size:12px">14</td>
                <td style="border: 1px solid black; border-top: 0px; width: 17%; background-color: #F0E68C"><input type="text" style="width: 100%; border: 0px solid black;background-color: #F0E68C; text-align:right" placeholder="0" oninput="formulir1770()" id="pphterutang14"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; border-bottom: 0px; border-top: 0px; width: 5%; font-size: 11px; text-align:center">D</td>
                <td style="border: 1px solid black; border-bottom: 0px; border-top: 0px; width: 55%; ; font-size: 12px">15. <span style="margin-left: 5px">PPh YANG DIPOTONG/DIPUNGUT OLEH PIHAK LAIN, PPh YANG DIBAYAR/DIPOTONG DI LUAR</br></span>
                    <span style="margin-left: 25px;">NEGERI DAN PPh DITANGGUNG PEMERINTAH [Diisi dari formulir 1770-II Jumlah Bagian A Kolom 7]</span>
                </td>
                <td style="border: 1px solid black; border-top: 0px; width: 3%;  text-align: center;  font-size:12px">15</td>
                <td style="border: 1px solid black; border-top: 0px; width: 17%; background-color: #F0E68C"><input type="text" style="width: 100%; border: 0px solid black; background-color: #F0E68C; text-align:right" placeholder="0" oninput="formulir1770()" id="kreditpajak15" value="{{ request()->all()['hasilPPhDipotongDipungut'] ?? 0 }}" id="kreditpajak15"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; border-bottom: 0px; border-top: 0px; width: 5%; font-size: 11px; text-align:center">KREDIT</br>PAJAK</td>
                <td style="border: 1px solid black; border-bottom: 0px; border-top: 0px; width: 55%; ; font-size: 12px">16.
                    <div class="form-check" style="display:inline-block; border-bottom: 1px solid black">
                        <input style="display:inline;" class="form-check-input" type="radio" name="Nomor16" id="pphBayarSendiri" checked>
                        <label class="form-check-label" for="flexRadioDisabled" style="font-size: 11px;">
                            a. PPh YANG HARUS DIBAYAR SENDIRI
                        </label>
                    </div>
                    <br>
                    <div class="form-check" style="display:inline-block; margin-left: 20px">
                        <input style="display:inline;" class="form-check-input" type="radio" name="Nomor16" id="pphPotongPungut">
                        <label class="form-check-label" for="flexRadioDisabled" style="font-size: 11px;">
                            b. PPh YANG LEBIH DIPOTONG/DIPUNGUT
                        </label>
                    </div>(14-15)
                </td>
                <td style="border: 1px solid black; border-top: 0px; width: 3%;  text-align: center;  font-size:12px">16</td>
                <td style="border: 1px solid black; border-top: 0px; width: 17%; background-color: #F0E68C"><input type="text" style="width: 100%; border: 0px solid black; background-color: #F0E68C; text-align:right" placeholder="0" oninput="formulir1770()" id="kreditpajak16"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; border-bottom: 0px; border-top: 0px; width: 5%; font-size: 11px; text-align:center"></td>
                <td style="border: 1px solid black; border-bottom: 0px; border-top: 0px; width: 55%; ; font-size: 12px">17. <span style="margin-left: 5px">PPh YANG DIBAYAR SENDIRI &emsp; a. PPh PASAL 25 BULANAN</br></span></td>
                <td style="border: 1px solid black; border-top: 0px; width: 3%;  text-align: center;  font-size:12px">17a</td>
                <td style="border: 1px solid black; border-top: 0px; width: 17%; "><input type="text" style="width: 100%; border: 0px solid black; text-align:right" placeholder="0" oninput="formulir1770()" id="kreditpajak17a"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; border-bottom: 0px; border-top: 0px; width: 5%; font-size: 11px; text-align:center"></td>
                <td style="border: 1px solid black; border-bottom: 0px; border-top: 0px; width: 55%; ; font-size: 12px"><span style="margin-left: 210px">b. STP PPh PASAL 25 (HANYA POKOK PAJAK)</br></span></td>
                <td style="border: 1px solid black; border-top: 0px; width: 3%;  text-align: center;  font-size:12px">17b</td>
                <td style="border: 1px solid black; border-top: 0px; width: 17%; "><input type="text" style="width: 100%; border: 0px solid black; text-align:right" placeholder="0" oninput="formulir1770()" id="kreditpajak17b"></td>
            </tr>

            <tr>
                <td style="border: 1px solid black; border-top: 0px; width: 5%; font-size: 11px; text-align:center"></td>
                <td style="border: 1px solid black; border-top: 0px; width: 55%; ; font-size: 12px">18. <span style="margin-left: 5px">JUMLAH KREDIT PAJAK (17a + 17b)</br></span></td>
                <td style="border: 1px solid black; border-top: 0px; width: 3%;  text-align: center;  font-size:12px">18</td>
                <td style="border: 1px solid black; border-top: 0px; width: 17%; background-color: #F0E68C "><input type="text" style="width: 100%; border: 0px solid black; background-color: #F0E68C; text-align:right" placeholder="0" oninput="formulir1770()" id="kreditpajak18"></td>
            </tr>
        </table>
        <!-- Table B -->
        <table style="width: 99%; margin-left: 10px">
            <tr>
                <td style="border: 1px solid black; border-bottom: 0px; border-top: 0px; width: 8.4%; font-size: 11px; text-align:center">E</td>
                <td style="border: 1px solid black; border-bottom: 0px; border-top: 0px; width: 35%; ; font-size: 12px">19.
                    <div class="form-check" style="display:inline-block; border-bottom: 1px solid black">
                        <input style="display:inline;" class="form-check-input" type="radio" name="Nomor19" id="KurangBayar" checked>
                        <label class="form-check-label" for="flexRadioDisabled" style="font-size: 11px;">
                            a. PPh YANG KURANG DIBAYAR (PPh PASAL 29)
                        </label>
                    </div>
                    <br>
                    <div class="form-check" style="display:inline-block; margin-left: 20px">
                        <input style="display:inline;" class="form-check-input" type="radio" name="Nomor19" id="LebihBayar">
                        <label class="form-check-label" for="flexRadioDisabled" style="font-size: 11px;">
                            b. PPh YANG LEBIH DIBAYAR (PPh PASAL 28 A)
                        </label>
                    </div>(16-18)
                </td>
                <td style="border: 1px solid black; border-top: 0px; font-size: 12px; text-align:center; width: 6%">Tgl Lunas</td>
                <td style="border: 1px solid black; border-top: 0px; width: 14%"><input type="date" style="width: 100%; border: 0px; font-size: 12px"></td>
                <td style="border: 1px solid black; border-top: 0px; width: 3%;  text-align: center;  font-size:12px">19</td>
                <td style="border: 1px solid black; border-top: 0px; width: 18%; background-color: #F0E68C"><input type="text" style="width: 100%; border: 0px solid black; background-color: #F0E68C; text-align:right" placeholder="0" oninput="formulir1770()" id="KurangLebihBayar19"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; border-top: 0px; width: 8.4%; font-size: 11px; text-align:center">PPh KURANG/</br>LEBIH BAYAR</td>
                <td style="border: 1px solid black; border-top: 0px; border-right: 0px; width: 35%; ; font-size: 12px">20. <span style="margin-left: 5px">PERMOHONAN : PPh Lebih Bayar Pada 19.b mohon</br></span>
                </td>
                <td style="width: 6%; border-bottom: 1px solid black"></td>
                <td style="width: 14%; border-bottom: 1px solid black">
                    <input type="checkbox" id="pembetulan2" aria-label="Checkbox for following text input">
                    <label for="exampleFormControlInput1" class="form-label" style="font-size: 9px;">a. DIRESTITUSIKAN</label></br>
                    <input type="checkbox" id="pembetulan2" aria-label="Checkbox for following text input">
                    <label for="exampleFormControlInput1" class="form-label" style="font-size: 9px;">b. DIPERHITUNGKAN</br> DENGAN UTANG PAJAK</label>
                </td>
                <td style="width: 3%; border-bottom: 1px solid black"></td>
                <td style="width: 18%; border-bottom: 1px solid black; border-right: 1px solid black">
                    <input type="checkbox" id="pembetulan2" aria-label="Checkbox for following text input">
                    <label for="exampleFormControlInput1" class="form-label" style="font-size: 9px;">c. DIKEMBALIKAN DENGAN SKPPKP 17C</br>
                        (WP dengan Kriteria Tertentu)</label></br>
                    <input type="checkbox" id="pembetulan2" aria-label="Checkbox for following text input">
                    <label for="exampleFormControlInput1" class="form-label" style="font-size: 9px;">d. DIKEMBALIKAN DENGAN SKPPKP 17D</br>
                        (WP yang Memenuhi Persyaratan Tertentu )</label>
            </tr>
        </table>
        <!-- Table C -->
        <table style="width: 99%; margin-left: 10px">
            <tr>
                <td style="border: 1px solid black; border-bottom: 0px; border-top: 0px; width: 8.7%; text-align: center;font-size: 11px ">F</td>
                <td style="border: 1px solid black; border-bottom: 0px; border-top: 0px; width: 58%;  font-size: 12px;">21. <span style="margin-left: 5px; font-size: 11px">ANGSURAN PPh PASAL 25 TAHUN PAJAK BERIKUTNYA DIHITUNG SEBESAR. DIHITUNG BERDASARKAN :</span> </br>
                </td>
                <td style="border: 1px solid black; border-top: 0px; width: 3%;  text-align: center; font-size:12px">21</td>
                <td style="border: 1px solid black; border-top: 0px; width: 18%; "><input type="text" style="width: 100%; border: 0px solid black; text-align:right" placeholder="0" oninput="formulir1770()" id="pasal25"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; border-top: 0px; width: 8.7%; text-align: center;font-size: 11px ">ANGSURAN PPh</br>PASAL 25 TAHUN</br>PAJAK BERIKUTNYA</td>
                <td style="border: 1px solid black; border-top: 0px;  border-right: 0px; width: 58%;  font-size: 12px;">
                    <input type="checkbox" id="pembetulan2" aria-label="Checkbox for following text input" style="margin-left: 20px">
                    <label for="exampleFormControlInput1" class="form-label" style="font-size: 10px;">a. 1/2 X JUMLAH PADA ANGKA 16</label>

                    <input type="checkbox" id="pembetulan2" aria-label="Checkbox for following text input" style="margin-left: 20px">
                    <label for="exampleFormControlInput1" class="form-label" style="font-size: 10px">b. PERHITUNGAN WAJIB PAJAK ORANG PRIBADI PENGUSAHA TERTENTU</label>
                </td>
                <td style="border-bottom: 1px solid black; width: 3%"></td>
                <td style="border-bottom: 1px solid black; border-right: 1px solid black; width: 18%">
                    <input type="checkbox" id="pembetulan2" aria-label="Checkbox for following text input">
                    <label for="exampleFormControlInput1" class="form-label" style="font-size: 10px">c. PERHITUNGAN DALAM</br>LAMPIRAN TERSENDIRI</label>
                </td>
            </tr>
        </table>

        <table style="width: 99%; margin-left: 10px">
            <tr>
                <td style="border: 1px solid black; border-bottom: 0px; border-top: 0px; width: 8.1%; text-align: center;font-size: 11px ">G</td>
                <td style="border: 1px solid black; border-right: 0px; border-bottom: 0px; border-top: 0px; width: 37%;  font-size: 11px;">SEKAIN FORMULIR 1770-I SAMPAI DENGAN 1770-IV (BAIK YANG DIISI MAUPUN</td>
                <td style="border: 1px solid black; border-left: 0px; border-top: 0px; border-bottom: 0px; width: 36%; font-size: 11px; ">YANG TIDAK DIISI) HARUS DILAMPIRKAN PULA :</td>
            </tr>
            <tr>
                <td style="border: 1px solid black; border-bottom: 0px; border-top: 0px; width: 8.1%; text-align: center;font-size: 11px ">LAMPIRAN</td>
                <td style="border: 1px solid black; border-right: 0px; border-bottom: 0px; border-top: 0px; width: 37%;  font-size: 11px;">
                    <input type="checkbox" id="pembetulan2" aria-label="Checkbox for following text input" style="margin-top: 5px; margin-left: 10px">
                    <label for="exampleFormControlInput1" class="form-label" style="font-size: 11px;">SURAT KUASA KHUSUS (BILA DIKUASAKAN)</label>
                </td>
                <td style="border: 1px solid black; border-left: 0px; border-top: 0px; border-bottom: 0px; width: 36%; font-size: 11px; ">
                    <input type="checkbox" id="pembetulan2" aria-label="Checkbox for following text input" style="margin-top: 5px">
                    <label for="exampleFormControlInput1" class="form-label" style="font-size: 11px;">PERHITUNGAN ANGSURAN PPh PASAL 25 TAHUN PAJAK BERIKUTNYA</label>
                </td>
            </tr>
            <tr>
                <td style="border: 1px solid black; border-bottom: 0px; border-top: 0px; width: 8.1%; text-align: center;font-size: 11px "></td>
                <td style="border: 1px solid black; border-right: 0px; border-bottom: 0px; border-top: 0px; width: 37%;  font-size: 11px;">
                    <input type="checkbox" id="pembetulan2" aria-label="Checkbox for following text input" style="margin-top: 5px; margin-left: 10px">
                    <label for="exampleFormControlInput1" class="form-label" style="font-size: 11px;">SPP LEMBAR KE-3 PPh PASAL 29</label>
                </td>
                <td style="border: 1px solid black; border-left: 0px; border-top: 0px; border-bottom: 0px; width: 36%; font-size: 11px; ">
                    <input type="checkbox" id="pembetulan2" aria-label="Checkbox for following text input" style="margin-top: 5px">
                    <input type="text" style="width: 90%; height: 30px; border: 1px solid black; margin-left: 5px">
                </td>
            </tr>
            <tr>
                <td style="border: 1px solid black; border-bottom: 0px; border-top: 0px; width: 8.1%; text-align: center;font-size: 11px "></td>
                <td style="border: 1px solid black; border-right: 0px; border-bottom: 0px; border-top: 0px; width: 37%;  font-size: 11px;">
                    <input type="checkbox" id="pembetulan2" aria-label="Checkbox for following text input" style="margin-top: 5px; margin-left: 10px">
                    <label for="exampleFormControlInput1" class="form-label" style="font-size: 11px;">NERACA DAN LAP.LABA RUGI/REKAPITULASI BULANAN</br>PEREDARAN BRUTO DAN/ATAU PENGHASILAN LAIN DAN BIAYA</label>
                </td>
                <td style="border: 1px solid black; border-left: 0px; border-top: 0px; border-bottom: 0px; width: 36%; font-size: 11px; ">
                    <input type="checkbox" id="pembetulan2" aria-label="Checkbox for following text input" style="margin-top: 5px">
                    <label for="exampleFormControlInput1" class="form-label" style="font-size: 11px;">PERHITUNGAN PPh TERUTANG BAGI WAJIB PAJAK</br>DENGAN STATUS PERPAJAKAN PH ATAU MT</label>
                </td>
            </tr>
            <tr>
                <td style="border: 1px solid black; border-bottom: 0px; border-top: 0px; width: 8.1%; text-align: center;font-size: 11px "></td>
                <td style="border: 1px solid black; border-right: 0px; border-bottom: 0px; border-top: 0px; width: 37%;  font-size: 11px;">
                    <input type="checkbox" id="pembetulan2" aria-label="Checkbox for following text input" style="margin-top: 5px; margin-left: 10px">
                    <label for="exampleFormControlInput1" class="form-label" style="font-size: 11px;">PERHITUNGAN KOMPENSASI KERUGIAN FISIKAL</label>
                </td>
                <td style="border: 1px solid black; border-left: 0px; border-top: 0px; border-bottom: 0px; width: 36%; font-size: 11px; ">
                    <input type="checkbox" id="pembetulan2" aria-label="Checkbox for following text input" style="margin-top: 5px">
                    <label for="exampleFormControlInput1" class="form-label" style="font-size: 11px;">DAFTAR JUMLAH PENGHASILAN DAN PEMBAYARAN PPh PASAL 25</br>(KHUSUS UNTUK ORANG PRIBADI PENGUSAHA TERTENTU)</label>
                </td>
            </tr>
            <tr>
                <td style="border: 1px solid black; border-bottom: 0px; border-top: 0px; width: 8.1%; text-align: center;font-size: 11px "></td>
                <td style="border: 1px solid black; border-right: 0px; border-bottom: 0px; border-top: 0px; width: 37%;  font-size: 11px;">
                    <input type="checkbox" id="pembetulan2" aria-label="Checkbox for following text input" style="margin-top: 5px; margin-left: 10px">
                    <label for="exampleFormControlInput1" class="form-label" style="font-size: 11px;">BUKTI PEMOTONGAN/PEMUNGUTAN OLEH PIHAK LAIN/DITANGGUNG</br>PEMERINTAH DAN YANG DIBAYAR/DIPOTONG DI LUAR NEGERI</label>
                </td>
                <td style="border: 1px solid black; border-left: 0px; border-top: 0px; border-bottom: 0px; width: 36%">
                    <input type="checkbox" id="pembetulan2" aria-label="Checkbox for following text input" style="margin-top: 5px">
                    <label for="exampleFormControlInput1" class="form-label" style="font-size: 10px;">DAFTAR JUMLAH PEREDARAN BRUTO DAN PEMBAYARAN PPh FINAL</br>BERDASARKAN PP 46 TAHUN 2013 PER MASA PAJAK DAN PER TEMPAT USAHA</label>
                </td>
            </tr>
            <tr>
                <td style="border: 1px solid black; border-top: 0px; border-bottom: 0px; width: 8.1%; text-align: center;font-size: 11px "></td>
                <td style="border: 1px solid black; border-right: 0px; border-top: 0px; border-bottom: 0px; width: 37%;  font-size: 11px;">
                    <input type="checkbox" id="pembetulan2" aria-label="Checkbox for following text input" style="margin-top: 5px; margin-left: 10px">
                    <label for="exampleFormControlInput1" class="form-label" style="font-size: 11px;">FOTOKOPI FORMULIR 1721-A1 DAN/ATAU 1721-A2 &emsp; &emsp; LEMBAR</label>
                </td>
                <td style="border: 1px solid black; border-left: 0px; border-top: 0px; border-bottom: 0px; width: 36%; font-size: 11px; ">
                    <input type="checkbox" id="pembetulan2" aria-label="Checkbox for following text input" style="margin-top: 5px">
                    <input type="text" style="width: 90%; height: 30px; border: 1px solid black; margin-left: 5px">
                </td>
            </tr>
        </table>
        <table style="width: 99%; margin-left: 10px">
            <tr>
                <th style="font-size: 12px; background-color: #80808080">PERNYATAAN</th>
            </tr>
            <tr>
                <td style="border: 1px solid black; border-bottom: 0px; font-size: 12px; font-weight: bold; text-align: center">Dengan menyadari sepenuhnya akan segala akibatnya termasuk sanksi-sanksi sesuai dengan ketentuan perundang-undangan
                    yang berlaku, saya menyatakan bahwa apa yang telah saya beritahukan di atas beserta lampiran-lampirannya adalah benar, lengkap dan jelas.</td>
            </tr>
        </table>
        <table style="width: 99%; margin-left: 10px">
            <tr>
                <th style="border-top: 0px; border-right: 0px; border-bottom: 0px; width: 30%">
                    <div class="form-check" style="display:inline-block;">
                        <input style="display:inline;" class="form-check-input" type="radio" name="flexRadioDisabled" id="flexRadioDisabled">
                        <label class="form-check-label" for="flexRadioDisabled" style="font-size: 11px;">
                            WAJIB PAJAK
                        </label>
                    </div>
                    <div class="form-check" style="display:inline-block;">
                        <input style="display:inline;" class="form-check-input" type="radio" name="flexRadioDisabled" id="flexRadioDisabled">
                        <label class="form-check-label" for="flexRadioDisabled" style="font-size: 11px;">
                            KUASA
                        </label>
                    </div>
                </th>
                <th style="border-top: 0px; border-right: 0px; border-left: 0px; border-bottom: 0px; width: 20%"></th>
                <th style="border-top: 0px; border-right: 0px; border-left: 0px; border-bottom: 0px; width: 5%; font-size: 11px;">TANGGAL</th>
                <th style="border-top: 0px; border-right: 0px; border-left: 0px; border-bottom: 0px; width: 20%"><input type="date" style="width: 90%; font-size: 12px; height: 40px"></th>
                <th style="border: 1px solid black; width: 23%; font-size: 11px">TANDA TANGAN</th>
                <th style="border-top: 0px; border-left: 0px; border-bottom: 0px; width: 2%;">

                </th>

            </tr>
        </table>
        <table style="width: 99%; margin-left: 10px">
            <tr>
                <th style="border-top: 0px; border-right: 0px; border-bottom: 0px; width: 15%; font-size: 12px; background-color: #F0E68C">NAMA WAJIB PAJAK</th>
                <th style="border-top: 0px; border-right: 0px; border-left: 0px; border-bottom: 0px; width: 55%; background-color: #F0E68C"><input type="text" style="height: 30px; width: 100%; border: 1px solid black; font-size: 14px" placeholder="{{ $nama }}" disabled="disabled"></th>
                <th style="border: 0px; width: 5.2%"></th>
                <th style="border: 1px solid black; border-top: 0px; border-bottom: 0px; width: 22.7%;">
                    <div class="mb-3">
                        <input class="form-control form-control-sm" type="file" id="formFile" accept=".png, .jpg, .pdf">
                    </div>
                </th>
                <th style="border: 0px; border-right: 1px solid black; width:2%"></th>
            </tr>
            <tr>
                <th style="border-top: 0px; border-right: 0px; width: 15%; font-size: 12px; background-color: #F0E68C">NPWP</th>
                <th style="border-top: 0px; border-right: 0px; border-left: 0px; width: 55%; background-color: #F0E68C"><input type="text" style="height: 30px; width: 100%; border: 1px solid black; font-size: 14px" value="{{ $npwp }}" disabled="disabled" id="formatnpwpfix"></th>
                <th style="border: 0px; border-bottom: 1px solid black; width: 5.2%"></th>
                <th style="border: 1px solid black; border-top: 0px; width: 22.7%;"></th>
                <th style="border: 0px; border-right: 1px solid black; border-bottom: 1px solid black; width:2%"></th>
            </tr>
        </table>
        </form>


        <!-- Option 1: Bootstrap Bundle with Popper -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
        </script>
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous">
        </script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
        </script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
        </script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/numeral.js/2.0.6/numeral.min.js"></script>

        <script>
            $(document).ready(function() {
                jumlah();
                formatNpwp2();
            });

            const checkbox = document.getElementById('PH')
            const checkbox2 = document.getElementById('PH1')
            const checkbox3 = document.getElementById('SUBMIT1')
            const checkbox4 = document.getElementById('SUBMIT2')
            const button1 = document.getElementById('SUBMIT')
            const button2 = document.getElementById('PH-MT')


            checkbox.addEventListener('change', (event) => {
                if (event.currentTarget.checked) {
                    button2.style.display = 'inline-block';
                    button1.style.display = 'none';

                }
            })
            checkbox2.addEventListener('change', (event) => {
                if (event.currentTarget.checked) {
                    button2.style.display = 'inline-block';
                    button1.style.display = 'none';

                }
            })
            checkbox3.addEventListener('change', (event) => {
                if (event.currentTarget.checked) {
                    button1.style.display = 'inline-block';
                    button2.style.display = 'none';

                }
            })
            checkbox4.addEventListener('change', (event) => {
                if (event.currentTarget.checked) {
                    button1.style.display = 'inline-block';
                    button2.style.display = 'none';

                }
            })

            function jumlah() {



                valueNomorDelapan = numeral(nomordelapan.value);
                document.getElementById('nomordelapan').value = valueNomorDelapan.format();


                var resultnetoLain2 = resultnetoLain1 - (valueNomorDelapan.value())
                document.getElementById('nomorsembilan').value = resultnetoLain2;

                valueNomorSembilan = numeral(nomorsembilan.value);
                document.getElementById('nomorsembilan').value = valueNomorSembilan.format();
                valueHasil = numeral(hasil.value);
                document.getElementById('hasil').value = valueHasil.format();
                valueHasilPPhDiPotongDiPungut = numeral(hasilPPhDipotongDipungut.value);
                document.getElementById('hasilPPhDipotongDipungut').value = valueHasilPPhDiPotongDiPungut.format();

                var resultnetoLain3 = ((valueHasil.value()) + (valueHasilPPhDiPotongDiPungut.value()))
                document.getElementById('nomorsepuluh').value = resultnetoLain3;
                valueNomorSepuluh = numeral(nomorsepuluh.value);
                document.getElementById('nomorsepuluh').value = valueNomorSepuluh.format();

                var resultnetoLain4 = resultnetoLain2 - resultnetoLain3
                document.getElementById('nomorsebelas').value = resultnetoLain4;


                valueNomorDelapanBelas = numeral(nomordelapanbelas.value);
                document.getElementById('nomordelapanbelas').value = valueNomorDelapanBelas.format();

                valueK1 = numeral(k1.value);
                document.getElementById('k1').value = valueK1;

                var resultpkp = resultnetoLain2 - valueNomorDelapanBelas
                document.getElementById('nomorsebelas').value = resultpkp;
            }

            function formatNpwp2() {
                formatnpwp = document.getElementById('formatnpwpfix').value
                formatnpwp2 = document.getElementById('formatnpwpfix')
                if (typeof formatnpwp === 'string') {

                }
                formatnpwp2.value = formatnpwp.replace(/(\d{2})(\d{3})(\d{3})(\d{1})(\d{3})(\d{3})/, '$1.$2.$3.$4-$5.$6');
            }

            function formulir1770() {
                // PENGHASILAN NETO
                valuePenghasilanNeto1 = numeral(penghasilanneto1.value);
                document.getElementById('penghasilanneto1').value = valuePenghasilanNeto1.format();

                valuePenghasilanNeto2 = numeral(penghasilanneto2.value);
                document.getElementById('penghasilanneto2').value = valuePenghasilanNeto2.format();

                valuePenghasilanNeto3 = numeral(penghasilanneto3.value);
                document.getElementById('penghasilanneto3').value = valuePenghasilanNeto3.format();

                valuePenghasilanNeto4 = numeral(penghasilanneto4.value);
                document.getElementById('penghasilanneto4').value = valuePenghasilanNeto4.format();
                // HASIL 1+2+3+4
                var penghasilanneto1234 = ((valuePenghasilanNeto1.value()) + (valuePenghasilanNeto2.value()) +
                    (valuePenghasilanNeto3.value()) + (valuePenghasilanNeto4.value()));
                document.getElementById('penghasilanneto5').value = numeral(penghasilanneto1234).format();

                valuePenghasilanNeto6 = numeral(penghasilanneto6.value);
                document.getElementById('penghasilanneto6').value = valuePenghasilanNeto6.format();

                // HASIL 5-6
                var penghasilanneto56 = penghasilanneto1234 - ((valuePenghasilanNeto6.value()));
                document.getElementById('penghasilanneto7').value = numeral(penghasilanneto56).format();

                // PENGHASILAN KENA PAJAK
                valuePenghasilanKenaPajak8 = numeral(penghasilankenapajak8.value);
                document.getElementById('penghasilankenapajak8').value = valuePenghasilanKenaPajak8.format();

                // HASIL 7-8
                var penghasilankenapajak78 = penghasilanneto56 - ((valuePenghasilanKenaPajak8.value()));
                document.getElementById('penghasilankenapajak9').value = numeral(penghasilankenapajak78).format();

                // PTKP
                var data = document.getElementById("pilihanPTKP").value;
                console.log(data);
                document.getElementById("inputPTKP").value = numeral(data).format();

                // HASIL 9-10
                var penghasilankenapajak910 = penghasilankenapajak78 - data;
                document.getElementById('penghasilankenapajak11').value = numeral(penghasilankenapajak910).format();

                var data2 = document.getElementById("penghasilankenapajak11").value;
                console.log(data);
                document.getElementById("pphterutang12").value = numeral(data2).format();

                // PERHITUNGAN SENDIRI
                var PPhTerutang = document.getElementById("pphterutang12");
                PPhTerutang.disabled = PerhitunganSendiri.checked ? false : true;
                if (!PPhTerutang.disabled) {
                    PPhTerutang.focus()
                }

                valuePPhTerutang12 = numeral(pphterutang12.value);
                document.getElementById('pphterutang12').value = valuePPhTerutang12.format();

                valuePPhTerutang13 = numeral(pphterutang13.value);
                document.getElementById('pphterutang13').value = valuePPhTerutang13.format();

                // HASIL 12+13
                var hasilpphterutang = ((valuePPhTerutang12.value()) + (valuePPhTerutang13.value()));
                document.getElementById('pphterutang14').value = numeral(hasilpphterutang).format();

                valueKreditPajak15 = numeral(kreditpajak15.value);
                document.getElementById('kreditpajak15').value = valueKreditPajak15.format();

                // KREDIT PAJAK 14-15
                var hasilkreditpajak = hasilpphterutang - (valueKreditPajak15.value());
                document.getElementById('kreditpajak16').value = numeral(hasilkreditpajak).format();

                valueKreditPajak17a = numeral(kreditpajak17a.value);
                document.getElementById('kreditpajak17a').value = valueKreditPajak17a.format();

                valueKreditPajak17b = numeral(kreditpajak17b.value);
                document.getElementById('kreditpajak17b').value = valueKreditPajak17b.format();

                // HASIL 17a+17b
                var hasilkreditpajak18 = ((valueKreditPajak17a.value()) + (valueKreditPajak17b.value()));
                document.getElementById('kreditpajak18').value = numeral(hasilkreditpajak18).format();

                // PPh KURANG/LEBIH BAYAR
                var pphkuranglebih19 = hasilkreditpajak - hasilkreditpajak18;
                document.getElementById('KurangLebihBayar19').value = numeral(pphkuranglebih19).format();

                // PASAL 25
                valuePasal25 = numeral(pasal25.value);
                document.getElementById('pasal25').value = valuePasal25.format();
            }
        </script>
</body>

</html>