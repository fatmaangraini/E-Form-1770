<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js" integrity="sha512-aVKKRRi/Q/YV+4mjoKBsE4x3H+BkegoM/em46NNlCqNTmUYADjBbeNefNxYV7giUp0VxICtqdrbqU7iVaeZNXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <title>PH-MT</title>
    <style>
        .bg-grey {
            font-family: arial;
            background-color: #ccc;
        }

        .vericaltext {
            writing-mode: vertical-lr;
            text-orientation: use-glyph-orientation;
        }

        .year {
            border: 1px solid black;
            width: 20px;
            font-size: 25px;
        }

        table tr th {
            border: 1px solid black;
            font-size: 25px;
        }
    </style>
</head>

<body class="bg-grey" style="padding: 1% 10% 1% 10%">
    <div class="container" style="width : 90%; background-color: #fff">
        <div style="padding: 10px"></div>
        <div class="row" style="font-size: 12px; font-weight: bold; text-align:center">
            <div class="col-sm-2"><a href="/formulir1770" class="btn btn-secondary" style="font-size: 11px; width: auto; height: 30px">KEMBALI KE INDUK</a></div>
            <b style="padding: 10px;">LEMBAR PERHITUNGAN PAJAK PENGHASLAN TERUTANG</br>
                BAGI WAJIB PAJAK YANG KAWIN DENGAN STATUS PERPAJAKAN SUAMI-ISTERI PISAH HARTA DAN PENGHASILAN (PH) ATAU</br>
                ISTERI YANG MENGHENDAKI UNTUK MENJALANKAN HAK DAN KEWAJIBAN PERPAJAKANNYA SENDIRI (MT)</b>
        </div>

        <table id="mytable" class="display" style="width:100%">
            <tr>
                <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 5%;  height: 30px">
                    No.</th>
                <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 3%;"></th>
                <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 55%">
                    Uraian</th>
                <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 20%">
                    Penghasilan Neto <select style="width: 35%; height: 28px; border: 2px solid black" onchange="changePenghasilanNeto2()" id="penghasilanneto1">
                        <option>Pilih...</option>
                        <option value="Isteri">Suami</option>
                        <option value="Suami">Isteri</option>
                    </select></th>
                <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 20%">
                    Penghasilan Neto <input type="text" style="width: 35%; height: 28px; border: 2px solid black" id="penghasilanneto2"></th>
            </tr>
            <tr>
                <td style="border: 1px solid black; height: 8px; font-size: 11px; text-align:center">(1)</td>
                <td style="border: 1px solid black;"></td>
                <td style="border: 1px solid black; height: 8px; font-size: 11px; text-align:center">(2)</td>
                <td style="border: 1px solid black; height: 8px; font-size: 11px; text-align:center">(3)</td>
                <td style="border: 1px solid black; height: 8px; font-size: 11px; text-align:center">(4)</td>
            </tr>
            <tr>
                <td style="border: 1px solid black; border-bottom:0px solid black; text-align:center">A</td>
                <td></td>
                <td style="border: 1px solid black; font-size: 12px">PENGHASILAN NETO</td>
                <td style="border: 1px solid black; background-color: #808080"></td>
                <td style="border: 1px solid black; background-color: #808080"></td>
            </tr>
            <tr>
                <td style="border-left: 1px solid black"></td>
                <td style="border: 1px solid black; text-align:center">1</td>
                <td style="border: 1px solid black; font-size: 12px">PENGHASILAN NETO DALAM NEGERI DARI USAHA DAN/ATAU PEKERJAAN BEBAS</br>
                    <span style="font-size: 11px">[Diisi dari Formulir 1770 Bagian A angka 1]</span>
                </td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" style="border: 1px solid white; font-size: 12px; font-weight: bold; text-align: right; width: 100%; height: 30px;" placeholder="0" value="{{ request()->all()['hasil1'] ?? 0 }}" oninput="PenghasilanNeto()" id="suami1"></td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" style="border: 1px solid white; font-size: 12px; font-weight: bold; text-align: right; width: 100%; height: 30px;" placeholder="0" oninput="PenghasilanNeto()" id="isteri1"></td>
            </tr>
            <tr>
                <td style="border-left: 1px solid black"></td>
                <td style="border: 1px solid black; text-align:center">2</td>
                <td style="border: 1px solid black; font-size: 12px">PENGHASILAN NETO DALAM NEGERI SEHUBUNGAN DENGAN PEKERJAAN</br>
                    <span style="font-size: 11px">[Diisi dari Formulir 1770 Bagian A angka 2 atau Formulir 1770 S Bagian A angka 1]</span>
                </td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" style="border: 1px solid white; font-size: 12px; font-weight: bold; text-align: right; width: 100%; height: 30px;" placeholder="0" oninput="PenghasilanNeto()" id="suami2"></td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" style="border: 1px solid white; font-size: 12px; font-weight: bold; text-align: right; width: 100%; height: 30px;" placeholder="0" oninput="PenghasilanNeto()" id="isteri2"></td>
            </tr>
            <tr>
                <td style="border-left: 1px solid black"></td>
                <td style="border: 1px solid black; text-align:center">3</td>
                <td style="border: 1px solid black; font-size: 12px">PENGHASILAN NETO DALAM NEGERI LAINNYA</br>
                    <span style="font-size: 11px">[Diisi dari Formulir 1770 Bagian A angka 3 atau Formulir 1770 S Bagian A angka 2]</span>
                </td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" style="border: 1px solid white; font-size: 12px; font-weight: bold; text-align: right; width: 100%; height: 30px;" placeholder="0" value="{{ request()->all()['hasilnetolain'] ?? 0 }}" oninput="PenghasilanNeto()" id="suami3"></td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" style="border: 1px solid white; font-size: 12px; font-weight: bold; text-align: right; width: 100%; height: 30px;" placeholder="0" oninput="PenghasilanNeto()" id="isteri3"></td>
            </tr>
            <tr>
                <td style="border-left: 1px solid black"></td>
                <td style="border: 1px solid black; text-align:center">4</td>
                <td style="border: 1px solid black; font-size: 12px">PENGHASILAN NETO LUAR NEGERI</br>
                    <span style="font-size: 11px">[Diisi dari Formulir 1770 Bagian A angka 4 atau Formulir 1770 S Bagian A angka 3]</span>
                </td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" style="border: 1px solid white; font-size: 12px; font-weight: bold; text-align: right; width: 100%; height: 30px;" placeholder="0" oninput="PenghasilanNeto()" id="suami4"></td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" style="border: 1px solid white; font-size: 12px; font-weight: bold; text-align: right; width: 100%; height: 30px;" placeholder="0" oninput="PenghasilanNeto()" id="isteri4"></td>
            </tr>
            <tr>
                <td style="border-left: 1px solid black"></td>
                <td style="border: 1px solid black; text-align:center">5</td>
                <td style="border: 1px solid black; font-size: 12px">ZAKAT / SUMBANGAN KEAGAMAAN YANG BERSIFAT WAJIB</br>
                    <span style="font-size: 11px">[Diisi dari Formulir 1770 Bagian A angka 6 atau Formulir 1770 S Bagian A angka 5]</span>
                </td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" style="border: 1px solid white; font-size: 12px; font-weight: bold; text-align: right; width: 100%; height: 30px;" placeholder="0" oninput="PenghasilanNeto()" id="suami5"></td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" style="border: 1px solid white; font-size: 12px; font-weight: bold; text-align: right; width: 100%; height: 30px;" placeholder="0" oninput="PenghasilanNeto()" id="isteri5"></td>
            </tr>
            <tr>
                <td style="border-left: 1px solid black"></td>
                <td style="border: 1px solid black; text-align:center">6</td>
                <td style="border: 1px solid black; font-size: 12px">JUMLAH(1+2+3+4+5)</br>
                </td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" style="border: 1px solid white; font-size: 12px; font-weight: bold; text-align: right; width: 100%; height: 30px;" placeholder="0" oninput="PenghasilanNeto()" id="jumlahS"></td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" style="border: 1px solid white; font-size: 12px; font-weight: bold; text-align: right; width: 100%; height: 30px;" placeholder="0" oninput="PenghasilanNeto()" id="jumlahI"></td>
            </tr>
            <tr>
                <td style="border-left: 1px solid black"></td>
                <td style="border: 1px solid black; text-align:center">7</td>
                <td style="border: 1px solid black; font-size: 12px">KOMPENSASI KERUGIAN</br>
                    <span style="font-size: 10px">[Khusus Bagi WP OP yang menyelenggarakan pembukuan. Diisi dari Formulir 1770 Bagian A angka 8]</span>
                </td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" style="border: 1px solid white; font-size: 12px; font-weight: bold; text-align: right; width: 100%; height: 30px;" placeholder="0" oninput="PenghasilanNeto()" id="suamiKK"></td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" style="border: 1px solid white; font-size: 12px; font-weight: bold; text-align: right; width: 100%; height: 30px;" placeholder="0" oninput="PenghasilanNeto()" id="isteriKK"></td>
            </tr>
            <tr>
                <td style="border-left: 1px solid black; border-bottom: 1px solid black"></td>
                <td style="border: 1px solid black; text-align:center">8</td>
                <td style="border: 1px solid black; font-size: 12px">JUMLAH PENGHASILAN NETO (6-7)</br>
                </td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" style="border: 1px solid white; font-size: 12px; font-weight: bold; text-align: right; width: 100%; height: 30px;" placeholder="0" oninput="PenghasilanNeto()" id="jumlahS2"></td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" style="border: 1px solid white; font-size: 12px; font-weight: bold; text-align: right; width: 100%; height: 30px;" placeholder="0" oninput="PenghasilanNeto()" id="jumlahI2"></td>
            </tr>
            </br>
        </table>

        <table style="width:100%">
            <tr>
                <th style="border: 1px solid black; border-top: 0px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 5%;  height: 30px">
                    No.</th>
                <th style="border: 1px solid black; border-top: 0px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 70%">
                    Uraian</th>
                <th style="border: 1px solid black; border-top: 0px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 20%">
                    Nilai</th>
            </tr>
            <tr>
                <td style="border: 1px solid black; height: 8px; font-size: 11px; text-align:center">(1)</td>
                <td style="border: 1px solid black; height: 8px; font-size: 11px; text-align:center">(2)</td>
                <td style="border: 1px solid black; height: 8px; font-size: 11px; text-align:center">(3)</td>
            </tr>
            <tr>
                <td style="border: 1px solid black; text-align:center">B</td>
                <td style="border: 1px solid black; font-size: 12px"> JUMLAH PENGHASILAN NETO SUAMI DAN ISTERI
                    <span style="font-weight: bold;">[A.8.(3) + A.8(4)]</span>
                </td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" style="border: 1px solid white; font-size: 12px; font-weight: bold; text-align: right; width: 100%; height: 30px;" placeholder="0" oninput="PenghasilanNeto()" id="netosuamiisteri"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; text-align:center">C</td>
                <td style="border: 1px solid black; font-size: 12px"> PENGHASILAN TIDAK KENA PAJAK <span style="margin-left: 15px;font-weight: bold;">
                        <select style="width:15%; height: 28px; border: 2px solid black" onchange="PenghasilanNeto()" id="pilihanPTKP">
                            <option value="0">Pilih...</option>
                            <option value="0">0</option>
                            <option value="54000000">TK/0</option>
                            <option value="58500000">TK/1</option>
                            <option value="63000000">TK/2</option>
                            <option value="67500000">TK/3</option>
                            <option value="58500000">K/0</option>
                            <option value="63000000">K/1</option>
                            <option value="67500000">K/2</option>
                            <option value="72000000">K/3</option>
                            <option value="112500000">K/I/0</option>
                            <option value="117000000">K/I/1</option>
                            <option value="121500000">K/I/2</option>
                            <option value="126000000">K/I/3</option>
                        </select>


                        <!-- <span style="margin-left: 15px;font-weight: bold;">Isteri
                            <select style="width:15%; height: 28px; border: 2px solid black">
                                <option>Pilih...</option>
                                <option>0</option>
                                <option>TK/0</option>
                                <option>TK/1</option>
                                <option>TK/2</option>
                                <option>TK/3</option>
                                <option>K/0</option>
                                <option>K/1</option>
                                <option>K/2</option>
                                <option>K/3</option>
                            </select> -->
                </td>
                </span>
                <td style="border: 1px solid black;"><input type="text" class="form-control" style="border: 1px solid white; font-size: 12px; font-weight: bold; text-align: right; width: 100%; height: 30px;" placeholder="0" oninput="PenghasilanNeto()" id="inputPTKP"></td>
            </tr>
            <script>

            </script>
            <tr>
                <td style="border: 1px solid black; text-align:center">D</td>
                <td style="border: 1px solid black; font-size: 12px"> PENGHASILAN KENA PAJAK
                    <span style="font-weight: bold;">[B - C]</span>
                </td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" style="border: 1px solid white; font-size: 12px; font-weight: bold; text-align: right; width: 100%; height: 30px;" placeholder="0" oninput="PenghasilanNeto()" id="inputPKP"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; border-bottom: 0px solid black; height: 30px"></td>
                <td style="border: 1px solid black; font-size: 12px"> PAJAK PENGHASILAN TERUTANG (GABUNGAN)
                </td>
                <td style="border: 1px solid black; border-bottom: 0px solid black; background-color: #808080"></td>
            </tr>
        </table>
        <table style="width:100%">
            <tr>
                <th style=" border: 1px solid black; border-top: 0px solid black; border-bottom: 0px solid black; width: 5%; height: 30px">
                </th>
                <th style="border: 1px solid black; border-top: 0px solid black; font-size: 16px; font-weight: bold; width: 10%">
                    1. 5% x</th>
                <th style="border: 1px solid black; border-top: 0px solid black; width: 20%">
                    <input type="text" class="form-control" style="border: 1px solid white; font-size: 12px; font-weight: bold; text-align: right; width: 100%; height: 30px;" placeholder="0" oninput="PenghasilanNeto()" id="limapersen">
                </th>
                <th style="border: 1px solid black; border-top: 0px solid black; width: 20%">
                </th>
                <th style="border: 1px solid black; border-top: 0px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 20%">
                    <input type="text" class="form-control" style="border: 1px solid white; font-size: 12px; font-weight: bold; text-align: right; width: 100%; height: 30px;" placeholder="0" oninput="PenghasilanNeto()" id="hasillimapersen">
                </th>
                <th style="border: 1px solid black; border-top: 0px solid black; border-bottom: 0px solid black;width: 20%; background-color: #808080">
                </th>
            </tr>
            <tr>
                <td style="border: 1px solid black; border-top: 0px solid black; border-bottom: 0px solid black; height: 30px"></td>
                <td style="border: 1px solid black; border-top: 0px solid black; font-size: 16px; font-weight: bold;     height: 30px">2. 15% x</td>
                <td style="border: 1px solid black; border-top: 0px solid black">
                    <input type="text" class="form-control" style="border: 1px solid white; font-size: 12px; font-weight: bold; text-align: right; width: 100%; height: 30px;" placeholder="0" oninput="PenghasilanNeto()" id="limabelaspersen">
                </td>
                <td style="border: 1px solid black; border-top: 0px solid black"></td>
                <td style="border: 1px solid black; border-top: 0px solid black">
                    <input type="text" class="form-control" style="border: 1px solid white; font-size: 12px; font-weight: bold; text-align: right; width: 100%; height: 30px;" placeholder="0" oninput="PenghasilanNeto()" id="hasillimabelaspersen">
                </td>
                <td style="border: 1px solid black; border-top: 0px solid black; border-bottom: 0px solid black; background-color: #808080"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; border-top: 0px solid black; border-bottom: 0px solid black; text-align: center; height: 30px">E</td>
                <td style="border: 1px solid black; border-top: 0px solid black; font-size: 16px; font-weight: bold;     height: 30px">3. 25% x</td>
                <td style="border: 1px solid black; border-top: 0px solid black">
                    <input type="text" class="form-control" style="border: 1px solid white; font-size: 12px; font-weight: bold; text-align: right; width: 100%; height: 30px;" placeholder="0" oninput="PenghasilanNeto()" id="dualimapersen">
                </td>
                <td style="border: 1px solid black; border-top: 0px solid black"></td>
                <td style="border: 1px solid black; border-top: 0px solid black">
                    <input type="text" class="form-control" style="border: 1px solid white; font-size: 12px; font-weight: bold; text-align: right; width: 100%; height: 30px;" placeholder="0" oninput="PenghasilanNeto()" id="hasildualimapersen">
                </td>
                <td style="border: 1px solid black; border-top: 0px solid black; border-bottom: 0px solid black; background-color: #808080"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; border-top: 0px solid black; border-bottom: 0px solid black; height: 30px"></td>
                <td style="border: 1px solid black; border-top: 0px solid black; font-size: 16px; font-weight: bold;     height: 30px">4. 30% x</td>
                <td style="border: 1px solid black; border-top: 0px solid black">
                    <input type="text" class="form-control" style="border: 1px solid white; font-size: 12px; font-weight: bold; text-align: right; width: 100%; height: 30px;" placeholder="0" oninput="PenghasilanNeto()" id="tigapuluhpersen">
                </td>
                <td style="border: 1px solid black; border-top: 0px solid black"></td>
                <td style="border: 1px solid black; border-top: 0px solid black">
                    <input type="text" class="form-control" style="border: 1px solid white; font-size: 12px; font-weight: bold; text-align: right; width: 100%; height: 30px;" placeholder="0" oninput="PenghasilanNeto()" id="hasiltigapuluhpersen">
                </td>
                <td style="border: 1px solid black; border-top: 0px solid black; background-color: #808080"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; border-top: 0px solid black; border-bottom: 0px solid black; height: 30px"></td>
                <td style="border: 1px solid black; border-top: 0px solid black; font-size: 16px; font-weight: bold;     height: 30px">5. 35% x</td>
                <td style="border: 1px solid black; border-top: 0px solid black">
                    <input type="text" class="form-control" style="border: 1px solid white; font-size: 12px; font-weight: bold; text-align: right; width: 100%; height: 30px;" placeholder="0" oninput="PenghasilanNeto()" id="tigalimapersen">
                </td>
                <td style="border: 1px solid black; border-top: 0px solid black"></td>
                <td style="border: 1px solid black; border-top: 0px solid black">
                    <input type="text" class="form-control" style="border: 1px solid white; font-size: 12px; font-weight: bold; text-align: right; width: 100%; height: 30px;" placeholder="0" oninput="PenghasilanNeto()" id="hasiltigalimapersen">
                </td>
                <td style="border: 1px solid black; border-top: 0px solid black; background-color: #808080"></td>
            </tr>
        </table>
        <table style="width: 100%;">
            <tr>
                <th style="border: 1px solid black; border-top: 0px solid black; width: 5%; height: 30px"></th>
                <th style="border: 1px solid black; border-top: 0px solid black; width: 70%; height: 30px; font-size: 12px">JUMLAH PAJAK PENGHASILAN TERUTANG (GABUNGAN)</th>
                <th style="border: 1px solid black; border-top: 0px solid black; width: 20%">
                    <input type="text" class="form-control" style="border: 1px solid white; font-size: 12px; font-weight: bold; text-align: right; width: 100%; height: 30px;" placeholder="0" oninput="PenghasilanNeto()" id="hasilpphgabungan">
                </th>
            </tr>
            <tr>
                <td style="border: 1px solid black; text-align:center">F</td>
                <td style="border: 1px solid black; font-size: 12px">PPh TERUTANG YANG DITANGGUNG Suami <span style="font-weight: bold;">[(A.8(3) / B) x E]</span></br>
                    <span style="font-size: 11px">[Pindahkan nilai pada bagian ini ke SPT Suami bagian C angka 12 Formulir 1770 atau ke bagian C angka 9 Formulir 1770 S]</span>
                </td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" style="border: 1px solid white; font-size: 12px; font-weight: bold; text-align: right; width: 100%; height: 30px;" placeholder="0" oninput="PenghasilanNeto()" id="ditanggungsuami"></td>
            </tr>
            <tr>
                <td style="border: 1px solid black; text-align:center">G</td>
                <td style="border: 1px solid black; font-size: 12px">PPh TERUTANG YANG DITANGGUNG Isteri <span style="font-weight: bold;">[(A.8(4) / B) x E]</span></br>
                    <span style="font-size: 11px">[Pindahkan nilai pada bagian ini ke SPT Isteri bagian C angka 12 Formulir 1770 atau ke bagian C angka 9 Formulir 1770 S]</span>
                </td>
                <td style="border: 1px solid black;"><input type="text" class="form-control" style="border: 1px solid white; font-size: 12px; font-weight: bold; text-align: right; width: 100%; height: 30px;" placeholder="0" oninput="PenghasilanNeto()" id="ditanggungisteri"></td>
            </tr>
        </table>
        <div style="padding: 10px;"></div>
        <table style="width: 100%;">
            <tr>
                <th style="width:50%; border: 0px solid black"></th>
                <th style="width: 20%; border:1px solid black"><input type="text" style="width: 100%;border: 0px solid black"></th>
                <th style="width: 5%; border: 0px solid black"></th>
                <th style="width: 20%; border:1px solid black"><input type="date" style="width: 100%;border: 0px solid black; font-size: 12px"></th>
            </tr>
        </table>
        <div style="padding: 10px;"></div>

        <table style="width: 100%; height:30px">
            <tr style="background-color: #80808080">
                <th style="border: 0px solid black; width: 40%"></th>
                <th style="font-size:12px; text-align:center; width: 20%;"></th>
                <th style="border: 0px solid black; width: 40%;"></th>
            </tr>
        </table>

        <table style="width: 100%;">
            <tr style="height: 30px; background-color: #F0E68C; ">
                <th style="border: 0px solid black; font-size: 12px; width: 34%;">Nama</th>
                <th style="border: 1px solid black; font-size: 12px; width: 70%;"></th>
            </tr>
            <tr style="height: 30px; background-color: #F0E68C">
                <th style="border: 0px solid black; font-size: 12px; width: 34%;">NPWP</th>
                <th style="border: 1px solid black; font-size: 12px; width: 70%;"></th>
            </tr>
        </table>

        <table style="width: 100%;">
            <tr style="height: 60px;">
                <th style="border: 0px solid black; font-size: 12px; width: 34%;">Tanda Tangan</th>
                <th style="border: 1px solid black; font-size: 12px; width: 70%;">(tanda tangan)</th>
            </tr>
        </table>
        <div style="padding: 10px;"></div>

        <table style="width: 100%; height:30px">
            <tr style="background-color: #80808080">
                <th style="border: 0px solid black; width: 40%"></th>
                <th style="font-size:12px; text-align:center; width: 20%;"></th>
                <th style="border: 0px solid black; width: 40%;"></th>
            </tr>
        </table>
        <table style="width: 100%;">
            <tr style="height: 30px;">
                <th style="border: 0px solid black; font-size: 12px; width: 34%;">Nama</th>
                <th style="border: 1px solid black; font-size: 12px; width: 70%;"></th>
            </tr>
            <tr style="height: 30px;">
                <th style="border: 0px solid black; font-size: 12px; width: 34%;">NPWP</th>
                <th style="border: 1px solid black; font-size: 12px; width: 70%;"></th>
            </tr>
        </table>

        <table style="width: 100%;">
            <tr style="height: 60px;">
                <th style="border: 0px solid black; font-size: 12px; width: 34%;">Tanda Tangan</th>
                <th style="border: 1px solid black; font-size: 12px; width: 70%;">(tanda tangan)</th>
            </tr>
        </table>


    </div>
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
    </script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/numeral.js/2.0.6/numeral.min.js"></script>

    <script>
        function changePenghasilanNeto2() {
            var pn1 = document.getElementById('penghasilanneto1').value
            document.getElementById('penghasilanneto2').value = pn1
        }
    </script>

    <script>
        function PenghasilanNeto() {
            // SUAMI
            valueSuami1 = numeral(suami1.value);
            document.getElementById('suami1').value = valueSuami1.format();
            valueSuami2 = numeral(suami2.value);
            document.getElementById('suami2').value = valueSuami2.format();
            valueSuami3 = numeral(suami3.value);
            document.getElementById('suami3').value = valueSuami3.format();
            valueSuami4 = numeral(suami4.value);
            document.getElementById('suami4').value = valueSuami4.format();
            valueSuami5 = numeral(suami5.value);
            document.getElementById('suami5').value = valueSuami5.format();
            valueSuamiKK = numeral(suamiKK.value);
            document.getElementById('suamiKK').value = valueSuamiKK.format();

            var Suami = ((valueSuami1.value()) + (valueSuami2.value()) +
                (valueSuami3.value()) + (valueSuami4.value()) + (valueSuami5.value()));
            document.getElementById('jumlahS').value = numeral(Suami).format();;

            var Suami2 = Suami - ((valueSuamiKK.value()));
            document.getElementById('jumlahS2').value = numeral(Suami2).format();

            // ISTERI
            valueIsteri1 = numeral(isteri1.value);
            document.getElementById('isteri1').value = valueIsteri1.format();
            valueIsteri2 = numeral(isteri2.value);
            document.getElementById('isteri2').value = valueIsteri2.format();
            valueIsteri3 = numeral(isteri3.value);
            document.getElementById('isteri3').value = valueIsteri3.format();
            valueIsteri4 = numeral(isteri4.value);
            document.getElementById('isteri4').value = valueIsteri4.format();
            valueIsteri5 = numeral(isteri5.value);
            document.getElementById('isteri5').value = valueIsteri5.format();
            valueIsteriKK = numeral(isteriKK.value);
            document.getElementById('isteriKK').value = valueIsteriKK.format();

            var Isteri = ((valueIsteri1.value()) + (valueIsteri2.value()) +
                (valueIsteri3.value()) + (valueIsteri4.value()) + (valueIsteri5.value()));
            document.getElementById('jumlahI').value = numeral(Isteri).format();

            var Isteri2 = Isteri - ((valueIsteriKK.value()));
            document.getElementById('jumlahI2').value = numeral(Isteri2).format();

            var netoSuamiIsteri = Suami2 + Isteri2;
            document.getElementById('netosuamiisteri').value = numeral(netoSuamiIsteri).format();

            // PKP
            var data = document.getElementById("pilihanPTKP").value;
            console.log(data);
            document.getElementById("inputPTKP").value = numeral(data).format();

            valueInputPTKP = numeral(inputPTKP.value);
            document.getElementById('inputPTKP').value = valueInputPTKP.format();

            var hasilPKP = netoSuamiIsteri - ((valueInputPTKP.value()));
            document.getElementById('inputPKP').value = numeral(hasilPKP).format();

            // PPH GABUNGAN
            valueLimaPersen = numeral(limapersen.value);
            document.getElementById('limapersen').value = valueLimaPersen.format();

            valueLimaBelasPersen = numeral(limabelaspersen.value);
            document.getElementById('limabelaspersen').value = valueLimaBelasPersen.format();
            
            valueDuaLimaPersen = numeral(dualimapersen.value);
            document.getElementById('dualimapersen').value = valueDuaLimaPersen.format();

            valueTigaPuluhPersen = numeral(tigapuluhpersen.value);
            document.getElementById('tigapuluhpersen').value = valueTigaPuluhPersen.format();

            valueTigaLimaPersen = numeral(tigalimapersen.value);
            document.getElementById('tigalimapersen').value = valueTigaLimaPersen.format();

            // HASIL PPH GABUNGAN
            var HasilLimaPersen = ((valueLimaPersen.value()) * (5/100));
            document.getElementById('hasillimapersen').value = numeral(HasilLimaPersen).format();

            var HasilLimaBelasPersen = ((valueLimaBelasPersen.value()) * (15/100));
            document.getElementById('hasillimabelaspersen').value = numeral(HasilLimaBelasPersen).format();

            var HasilDuaLimaPersen = ((valueDuaLimaPersen.value()) * (25/100));
            document.getElementById('hasildualimapersen').value = numeral(HasilDuaLimaPersen).format();

            var HasilTigaPuluhPersen = ((valueTigaPuluhPersen.value()) * (30/100));
            document.getElementById('hasiltigapuluhpersen').value = numeral(HasilTigaPuluhPersen).format();

            var HasilTigaLimaPersen = ((valueTigaLimaPersen.value()) * (35/100));
            document.getElementById('hasiltigalimapersen').value = numeral(HasilTigaLimaPersen).format();

            // JUMLAH PPH GABUNGAN
            var HasilPPHGabungan = HasilLimaPersen + HasilLimaBelasPersen + HasilDuaLimaPersen 
            + HasilTigaPuluhPersen + HasilTigaLimaPersen;
            document.getElementById('hasilpphgabungan').value = numeral(HasilPPHGabungan).format();

            // PPH TERUTANG SUAMI
            var DitanggungSuami = Suami2 / netoSuamiIsteri * HasilPPHGabungan;
            document.getElementById('ditanggungsuami').value = numeral(DitanggungSuami).format();

            // PPH TERUTANG ISTERI
            var DitanggungIsteri = Isteri2 / netoSuamiIsteri * HasilPPHGabungan;
            document.getElementById('ditanggungisteri').value = numeral(DitanggungIsteri).format();

        }
    </script>
</body>

</html>