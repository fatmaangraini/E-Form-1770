<?php

use App\Http\Controllers\FormController;
use Illuminate\Support\Facades\Route;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\DataHartaImport;
use App\Exports\DataUtangImport;
use App\Exports\DataPotongPungutImport;
use App\Exports\DataDaftar4623Import;
use App\Http\Controllers\AuditController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DataHartaController;
use App\Http\Controllers\DataUtangController;
use App\Http\Controllers\DataKelController;
use App\Http\Controllers\DataPotongPungutController;
use App\Http\Controllers\FormulirI2Controller;
use App\Http\Controllers\FormulirIController;
use App\Http\Controllers\PP46danPP23Controller;
use App\Http\Controllers\SignaturePadController;
use App\Http\Controllers\FormulirIIIController;
use App\Http\Controllers\SaveDataHartaController;

use Sabberworm\CSS\Property\Import;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return redirect('login');
});
Route::get('/home', function () {
    return view('home');
});
Route::get('/form', [FormController::class,"index"]);

Route::get('/index', function () {
    return view('index');
});
Route::post('/add', [FormController::class,"addform"])->name('add');

Route::get('/datatable', function () {
    return view('datatable');
});

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/
Route::get('dashboard', [AuthController::class, 'dashboard']);
Route::get('login', [AuthController::class, 'index'])->name('login');
Route::post('custom-login', [AuthController::class, 'customLogin'])->name('login.custom');
Route::get('registration', [AuthController::class, 'registration'])->name('register-user');
Route::post('custom-registration', [AuthController::class, 'customRegistration'])->name('register.custom');
Route::get('signout', [AuthController::class, 'signOut'])->name('signout');

Route::get('/data', function () {
    return view('data');
});

Route::get('/form1', function () {
    return view('form1');
});

Route::get('/buatSPT', function () {
    return view('buatSPT');
});
Route::get('/arsipSPT', function () {
    return view('arsipSPT');
});
Route::get('/index1', function () {
    return view('index1');
});
Route::get('/formulir-IV',[FormController::class,'formulir4']);
Route::get('/formulir-III',[FormController::class,'formulir3']);
Route::get('/formulir-II',[FormController::class,'formulir2']);
Route::get('/formulir-I',[FormController::class,'formulir1']);
Route::get('/formulir-I hal 2',[FormController::class,'formulir1_2']);
Route::get('/PP46atau23',[FormController::class,'PP46']);
Route::get('/formulir1770',[FormController::class,'formulir']);

Route::get('/buatSPT', function () {
    return view('buatSPT');
});

Route::get('/coba', function () {
    return view('coba');
});

Route::get('/PH-MT', function () {
    return view('PH-MT');
});

Route::get('/tes', function () {
    return view('tes');
});
// Route::get('/formulir-IV', function () {
//     return view('formulir-IV');
// });

// Route::get('/formulir-III', function () {
//     return view('formulir-III');
// });


// Route::get('/formulir-II', function () {
//     return view('formulir-II');
// });


// Route::get('/formulir-I', function () {
//     return view('formulir-I');
// });

// Route::get('/PP46atau23', function () {
//     return view('PP46atau23');
// });


Route::get('/formulirprint', function () {
    return view('formulirprint');
});

Route::post('/prosestambahspt',[FormController::class,'prosestambahspt']);

// Route::post('import', function () {
//     Excel::import(new DataHartaImport, request()->file('file'));
//     return redirect()->back()->with('success','Data Imported Successfully');
// });

// Data Harta
Route::post('/DataHartaImport',[DataHartaController::class, 'importexcel'])->name('DataHartaImport');
Route::post('/DataHarta/Store',[DataHartaController::class, 'store']);
Route::post('/DataHarta/delete',[DataHartaController::class, 'delete']);
Route::post('/SaveDataHarta',[DataHartaController::class, 'save']);

// Data Utang
Route::post('/DataUtangImport',[DataUtangController::class, 'importexcel'])->name('DataUtangImport');
Route::post('/DataUtang/Store',[DataUtangController::class, 'store']);
Route::post('/DataUtang/delete',[DataUtangController::class, 'delete']);
Route::post('/SaveDataUtang',[DataUtangController::class, 'save']);


// Data Keluarga
Route::post('/DataKel/Store',[DataKelController::class, 'store']);
Route::post('/DataKel/delete',[DataKelController::class, 'delete']);
Route::post('/SaveDataKel',[DataKelController::class, 'save']);

// Data Potong Pungut
Route::post('/DataPotongPungutImport',[DataPotongPungutController::class, 'importexcel'])->name('DataPotongPungutImport');
Route::post('/DataPotongPungut/Store',[DataPotongPungutController::class, 'store']);
Route::post('/DataPotongPungut/delete',[DataPotongPungutController::class, 'delete']);
Route::post('/SaveDataPotongPungut',[DataPotongPungutController::class, 'save']);

// DataPP46/23
Route::post('/DataDaftar4623Import',[PP46danPP23Controller::class, 'importexcel'])->name('DataDaftar4623Import');
Route::post('/Datapp46danpp23/Store',[PP46danPP23Controller::class, 'store']);
Route::post('/Datapp46danpp23/delete',[PP46danPP23Controller::class, 'delete']);
Route::post('/SaveDataPP4623',[PP46danPP23Controller::class, 'save']);

// Formulir III A
Route::post('/FormulirIIIA_Point/Store',[FormulirIIIController::class, 'store']);
Route::post('/FormulirIIIA_Point/delete',[FormulirIIIController::class, 'delete']);

// Formulir III B
Route::post('/FormulirIIIB_Point/Store',[FormulirIIIController::class, 'store2']);
Route::post('/FormulirIIIB_Point/delete',[FormulirIIIController::class, 'delete2']);

// Formulir III C
Route::post('/FormulirIIIC_Point/Store',[FormulirIIIController::class, 'store3']);
Route::post('/FormulirIIIC_Point/delete',[FormulirIIIController::class, 'delete3']);

// Formulir I Audit
Route::post('Audit/Store', [AuditController::class, 'store']);
Route::post('SaveAudit', [AuditController::class, 'save']);

// Formulir I
Route::post('/FormulirI_Point/Store',[FormulirIController::class, 'store']);
Route::post('/FormulirI_Point/delete',[FormulirIController::class, 'delete']);

// Formulir I2 B
Route::post('/FormulirI2B_Point/Store',[FormulirI2Controller::class, 'store']);
Route::post('/FormulirI2B_Point/delete',[FormulirI2Controller::class, 'delete']);

Route::get('signaturepad', [SignaturePadController::class, 'index']);
Route::post('signaturepad', [SignaturePadController::class, 'upload'])->name('signaturepad.upload');


Route::get('/tes1', function () {
    return view('tes1');
});
