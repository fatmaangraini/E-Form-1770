<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

  <title>Arsip SPT</title>
  <style>
    * {
      box-sizing: border-box;
    }

    body {
      margin: 0;
      padding: 0;
      font-family: arial;
      font-size: 16px;
      line-height: 1.6;
      background-image: url("<?php echo e(asset('poltek4.jpeg')); ?>");
      background-repeat: no-repeat;
      background-size: cover;
    }

    .content {
      /* background-image: url("<?php echo e(asset('poltek4.jpeg')); ?>");
      background-repeat: no-repeat;
      background-size: cover; */
      height: 600px;
    }

    .navbar-expand-lg {
      background-color: #191970;
      font-variant: normal;
    }

    .nav-link {
      color: #FFFFFF;
    }

    .container {
      max-width: 1000px;
      margin: 20px auto;
    }

    .tab_container_wrap input {
      position: absolute;
      width: 0;
      height: 0;
      margin: 0;
      z-index: -100;
      top: -1000px;
    }

    .tab_container_wrap input:checked+.tab_content_box {
      display: block;
    }

    .tab_content_box {
      background: #F5F5F5;
      padding: 20px;
      display: none;
    }

    .tab_content_box:nth-child(1) {
      background: #f0f0f0;

    }

    .tab_content_box:nth-child(2) {
      background: #f0f0f0;
    }


    .tab_content_box h2 {
      margin: 0 0 20px;
    }


    .text {
      font-size: 11px;
      font-family: Arial;
      text-align: center;
    }

    .text1 {
      font-size: 14px;
      font-family: Arial;
      text-align: center;
    }
  </style>
</head>

<body>
  <div>
    <div class="shadow-sm  mb-3  " style="background-color: rgba(0,0,0,0.7);"><img src="<?php echo e(asset('taxcentre.png')); ?>" width="70px" style="margin-left: 10px" alt="" srcset="">
      <a style="margin-left: 1050px; color: #FFD700"></a>
      <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAABmJLR0QA/wD/AP+gvaeTAAABIklEQVRIie3VMUoDQRTG8W9SZBslKVIoWyt4gXgML5JYeA5RvIMewEuYhBQJFtppqV3ELCn9WzhCWKP7xryA4H4wzc7j/WYGZlaq8xcDZMAxMASKOIZAH8g2hebAlO8zAXJvNKtAl3G/ncfjtabnCY8S4IGlZzDCc0lbxnUWIYRtLxgj+tE0hMq+DWOvIsF9tRRZ4bsE2FRrhS8T4KuE2p8T7/HEeI+bbnDE8wrc/+VawptADxgA8zhu4jffndbxivXlakjqSjqSdCjpQFI7Ts8k3UsaSbqWNA4hvK21KmAXOAOeE34ST8ApsPMbsA1cAIsEsJwFcA60rOg+8LgGWM4DsGeBbx3Rz0zLzqq3umM6mrR86bkKPpH04ojOYs86/yzv5x2Nqq3T2YwAAAAASUVORK5CYII=">
    </div>
    <div class='content' style="padding-top :10px; padding-left:250px; padding-right:250px">
      <div class="" style="background-color: #f5f5f5 ; padding: 18px 20px 10px 20px ; height:auto;  ">
        <nav style="background-color: rgb(255, 157, 49); border-radius: 8px 8px 8px 8px; box-shadow: 2px 2px 2px 2px lightgrey; padding: 10px 10px 10px 10px">
          <div class="nav nav-tabs" id="nav-tab" role="tablist" style="height:40px ; border-bottom:0px">
          <a style="border-radius: 2px 30px 2px 30px; height:40px; padding: 8px 20px; text-align: center;"  href= "<?php echo e(url('/arsipSPT')); ?>" class="nav-link active"type="button">Arsip SPT</a>
          <a style="border-radius: 2px 30px 2px 30px; height:40px; padding: 8px 20px; text-align: center;" href= "<?php echo e(url('/buatSPT')); ?>" class="nav-link"type="button">Buat SPT</a>
          <img src="<?php echo e(asset('form.jpg')); ?>" style="height: 100%; margin-left: 670px; margin-top: -40px;">
          </div>
        </nav>
        <div style="background-color: #FFFFFF; border-radius: 8px 8px 0px 0px">
          <div class="tab-content" id="nav-tabContent" style="margin-top: 20px;">
            <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
              <div class="table" style="background-color: rgb(4, 153, 195); height: 40px; padding: 10px 0px 0px 10px; border-radius: 8px 8px 0px 0px">
                <span style="color: #FFFFFF; font-weight: bold;">
                  <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABcAAAAXCAYAAADgKtSgAAAABmJLR0QA/wD/AP+gvaeTAAABD0lEQVRIib3VMUvDQBjG8f+rCXUQFDengk6C0FGKq7tfQbr0q/gRRHBydHLXwSVbp3ZydHBx0E2qto9DFOS8nvcm1AeyvJf7vZccucASY2FB0hpwDGwk5s3M7MLdTdK5/s6rpANJuylrJVLbz1zHNnArqevBPekCd4saNMVL4Am4B2bAmaT18KbYhlZAP6PBzdf1nUczu0zOkFRlbGgsVWi1fefJFImxB+AjqG0Bm23xKXBKvVk/0wdO2uIdYMjvlQOMIkbPg78BVwvwmLHnwUvgyIGXHvyd+vFz8UMPXgA7DnzVg8+BZwc+9+AFMMiAk1nqF/rv+KShNQ4LsSO3Q/0PzT5DgBfg2symDRfmzydLjp+KLkhQbQAAAABJRU5ErkJggg==">
                  Daftar SPT
                </span>
              </div>
              <div style="padding: 0px 20px ;">
                <label class="mr-sm-2" for="inlineFormCustomSelect">Tampilkan</label>
                <input type="number" class="form-control" id="exampleFormControlInput1" placeholder="0" style="width: 15%; display: inline-block">
                <label class="mr-sm-2" for="inlineFormCustomSelect">entri</label>
                <table class="table w-100 table-bordered table-hover">
                  <div style="padding: 10px;"></div>
                  <thead>
                    <tr style="background-color: rgb(4, 153, 195)">
                      <th class="text" style="color: #FFFFFF;" scope="col">
                        N0 <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAPCAYAAAA71pVKAAAABmJLR0QA/wD/AP+gvaeTAAAA50lEQVQoka2ToU5DQRBFz5LX5AlEwbWO1GPoF7y/aIKqQCP6GQgEQfARGFIQODSqpnVIElKBwJ+KbtOXeSvahGs2c3fPzGR3FlpSe2qiIDWpvbZ30tocAgtgrtYFfgrcl7IO1ZV7vcUE6rk6KlV+AL6Ad+AJuABmoUYDXLeNKq83wC/wDHwD40LbC+CnA6eU1rk1cvxXgCfAFfAR2z5EnVc4Bu7o32EPhasQ37G97X0mPQ1xBfRTSutYuQEug3cLfAIDoAZe2M5C6FdH6lnw6jxxO63yKHfgR3Va8Gv1VV0WwXzoqF+1AasDiHn2ysIyAAAAAElFTkSuQmCC">
                      </th>
                      <th class="text" style="color: #FFFFFF;" scope="col">
                        JENIS SPT <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAPCAYAAAA71pVKAAAABmJLR0QA/wD/AP+gvaeTAAAA50lEQVQoka2ToU5DQRBFz5LX5AlEwbWO1GPoF7y/aIKqQCP6GQgEQfARGFIQODSqpnVIElKBwJ+KbtOXeSvahGs2c3fPzGR3FlpSe2qiIDWpvbZ30tocAgtgrtYFfgrcl7IO1ZV7vcUE6rk6KlV+AL6Ad+AJuABmoUYDXLeNKq83wC/wDHwD40LbC+CnA6eU1rk1cvxXgCfAFfAR2z5EnVc4Bu7o32EPhasQ37G97X0mPQ1xBfRTSutYuQEug3cLfAIDoAZe2M5C6FdH6lnw6jxxO63yKHfgR3Va8Gv1VV0WwXzoqF+1AasDiHn2ysIyAAAAAElFTkSuQmCC">
                      </th>
                      <th class="text" style="color: #FFFFFF;" scope="col">
                        TAHUN/MASA PAJAK <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAPCAYAAAA71pVKAAAABmJLR0QA/wD/AP+gvaeTAAAA50lEQVQoka2ToU5DQRBFz5LX5AlEwbWO1GPoF7y/aIKqQCP6GQgEQfARGFIQODSqpnVIElKBwJ+KbtOXeSvahGs2c3fPzGR3FlpSe2qiIDWpvbZ30tocAgtgrtYFfgrcl7IO1ZV7vcUE6rk6KlV+AL6Ad+AJuABmoUYDXLeNKq83wC/wDHwD40LbC+CnA6eU1rk1cvxXgCfAFfAR2z5EnVc4Bu7o32EPhasQ37G97X0mPQ1xBfRTSutYuQEug3cLfAIDoAZe2M5C6FdH6lnw6jxxO63yKHfgR3Va8Gv1VV0WwXzoqF+1AasDiHn2ysIyAAAAAElFTkSuQmCC">
                      </th>
                      <th class="text" style="color: #FFFFFF;" scope="col">
                        PEMBETULAN KE <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAPCAYAAAA71pVKAAAABmJLR0QA/wD/AP+gvaeTAAAA50lEQVQoka2ToU5DQRBFz5LX5AlEwbWO1GPoF7y/aIKqQCP6GQgEQfARGFIQODSqpnVIElKBwJ+KbtOXeSvahGs2c3fPzGR3FlpSe2qiIDWpvbZ30tocAgtgrtYFfgrcl7IO1ZV7vcUE6rk6KlV+AL6Ad+AJuABmoUYDXLeNKq83wC/wDHwD40LbC+CnA6eU1rk1cvxXgCfAFfAR2z5EnVc4Bu7o32EPhasQ37G97X0mPQ1xBfRTSutYuQEug3cLfAIDoAZe2M5C6FdH6lnw6jxxO63yKHfgR3Va8Gv1VV0WwXzoqF+1AasDiHn2ysIyAAAAAElFTkSuQmCC">
                      </th>
                      <th class="text" style="color: #FFFFFF;" scope="col">
                        STATUS <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAPCAYAAAA71pVKAAAABmJLR0QA/wD/AP+gvaeTAAAA50lEQVQoka2ToU5DQRBFz5LX5AlEwbWO1GPoF7y/aIKqQCP6GQgEQfARGFIQODSqpnVIElKBwJ+KbtOXeSvahGs2c3fPzGR3FlpSe2qiIDWpvbZ30tocAgtgrtYFfgrcl7IO1ZV7vcUE6rk6KlV+AL6Ad+AJuABmoUYDXLeNKq83wC/wDHwD40LbC+CnA6eU1rk1cvxXgCfAFfAR2z5EnVc4Bu7o32EPhasQ37G97X0mPQ1xBfRTSutYuQEug3cLfAIDoAZe2M5C6FdH6lnw6jxxO63yKHfgR3Va8Gv1VV0WwXzoqF+1AasDiHn2ysIyAAAAAElFTkSuQmCC">
                      </th>
                      <th class="text" style="color: #FFFFFF;" scope="col">
                        JUMLAH <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAPCAYAAAA71pVKAAAABmJLR0QA/wD/AP+gvaeTAAAA50lEQVQoka2ToU5DQRBFz5LX5AlEwbWO1GPoF7y/aIKqQCP6GQgEQfARGFIQODSqpnVIElKBwJ+KbtOXeSvahGs2c3fPzGR3FlpSe2qiIDWpvbZ30tocAgtgrtYFfgrcl7IO1ZV7vcUE6rk6KlV+AL6Ad+AJuABmoUYDXLeNKq83wC/wDHwD40LbC+CnA6eU1rk1cvxXgCfAFfAR2z5EnVc4Bu7o32EPhasQ37G97X0mPQ1xBfRTSutYuQEug3cLfAIDoAZe2M5C6FdH6lnw6jxxO63yKHfgR3Va8Gv1VV0WwXzoqF+1AasDiHn2ysIyAAAAAElFTkSuQmCC">
                      </th>
                      <th class="text" style="color: #FFFFFF;" scope="col">
                        SUMBER <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAPCAYAAAA71pVKAAAABmJLR0QA/wD/AP+gvaeTAAAA50lEQVQoka2ToU5DQRBFz5LX5AlEwbWO1GPoF7y/aIKqQCP6GQgEQfARGFIQODSqpnVIElKBwJ+KbtOXeSvahGs2c3fPzGR3FlpSe2qiIDWpvbZ30tocAgtgrtYFfgrcl7IO1ZV7vcUE6rk6KlV+AL6Ad+AJuABmoUYDXLeNKq83wC/wDHwD40LbC+CnA6eU1rk1cvxXgCfAFfAR2z5EnVc4Bu7o32EPhasQ37G97X0mPQ1xBfRTSutYuQEug3cLfAIDoAZe2M5C6FdH6lnw6jxxO63yKHfgR3Va8Gv1VV0WwXzoqF+1AasDiHn2ysIyAAAAAElFTkSuQmCC">
                      </th>
                      <th class="text" style="color: #FFFFFF;" scope="col">AKSI</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr class="text1" style="background-color: #FFFFFF;">
                      <th scope="row">1</th>
                      <td>SPT 1770</td>
                      <td>2021/01-12</td>
                      <td>0</td>
                      <td>Nihil</td>
                      <td>0</td>
                      <td>E-Form 1770</td>
                      <td><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAABmJLR0QA/wD/AP+gvaeTAAAAkklEQVRIiWNgGAVkAGUGBoZnDAwM/0nEz6B6CYLNZBgOw5sIGe4KVfiJgYFBkhjXQIEYAwPDe6heT3wKL0MVFZNgOAwUQ/VeRhZkRFP0nwyDsQG4uUxUMhAnYCHkAhIBRggMmA/QAa64IejTQeMDcuOE9j4YtWDwWfAYSpNbXCObgRV4MDAwPKLAgkdQM0YB8QAAz9dJogjSQNkAAAAASUVORK5CYII=">
                      </td>
                    </tr>
                    <tr class="text1" style="background-color: #FFFFFF;">
                      <th scope="row">2</th>
                      <td>SPT 1770</td>
                      <td>2020/01-12</td>
                      <td>0</td>
                      <td>Nihil</td>
                      <td>0</td>
                      <td>E-Form 1770</td>
                      <td><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAABmJLR0QA/wD/AP+gvaeTAAAAkklEQVRIiWNgGAVkAGUGBoZnDAwM/0nEz6B6CYLNZBgOw5sIGe4KVfiJgYFBkhjXQIEYAwPDe6heT3wKL0MVFZNgOAwUQ/VeRhZkRFP0nwyDsQG4uUxUMhAnYCHkAhIBRggMmA/QAa64IejTQeMDcuOE9j4YtWDwWfAYSpNbXCObgRV4MDAwPKLAgkdQM0YB8QAAz9dJogjSQNkAAAAASUVORK5CYII=">
                      </td>
                    </tr>
                    <tr class="text1" style="background-color: #FFFFFF;">
                      <th scope="row">3</th>
                      <td>SPT 1770</td>
                      <td>2019/01-12</td>
                      <td>0</td>
                      <td>Nihil</td>
                      <td>0</td>
                      <td>E-Form 1770</td>
                      <td><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAABmJLR0QA/wD/AP+gvaeTAAAAkklEQVRIiWNgGAVkAGUGBoZnDAwM/0nEz6B6CYLNZBgOw5sIGe4KVfiJgYFBkhjXQIEYAwPDe6heT3wKL0MVFZNgOAwUQ/VeRhZkRFP0nwyDsQG4uUxUMhAnYCHkAhIBRggMmA/QAa64IejTQeMDcuOE9j4YtWDwWfAYSpNbXCObgRV4MDAwPKLAgkdQM0YB8QAAz9dJogjSQNkAAAAASUVORK5CYII=">
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div style="display: flex; justify-content: space-between;">
                <div>
                  Menampilkan 1 sampai 2 dari 2 entri
                </div>
                <div>
                  <nav aria-label="Page navigation example">
                    <ul class="pagination justify-content-end">
                      <li class="page-item ">
                        <a class="page-link" style="background-color: rgb(255, 157, 49);" href="#" tabindex="-1" aria-disabled="true">
                          <span style="color: #FFFFFF;">Sebelumnya</span></a>
                      </li>
                      <li class="page-item"><a class="page-link" style="background-color: rgb(4, 153, 195);" href="#">
                          <span style="color: #FFFFFF;">1</span></a></li>
                      <li class="page-item"><a class="page-link" style="background-color: rgb(255, 157, 49);" href="#">
                          <span style="color: #FFFFFF;">2</span></a></li>
                      <li class="page-item">
                        <a class="page-link" style="background-color: rgb(4, 153, 195);" href="#" tabindex="-1" aria-disabled="true">
                          <span style="color: #FFFFFF;">Selanjutnya</span></a>
                      </li>
                    </ul>
                  </nav>
                </div>
              </div>
            </div>
           

          </div>
        </div>

      </div>
    </div>
  </div>
  <div class="shadow-sm " id="footer" style="background-color: rgba(0,0,0,0.7); height:40px">
  </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
  </script>

</body>
<script>
  function handleChange(src) {
    const myElement = document.getElementById("eformspt");
    myElement.style.display = "block";



  }

  function changeForm(src) {
    document.getElementById("form1").style.display = "none";
    document.getElementById("form2").style.display = "block";
    const myElement2 = document.getElementById("footer");
    myElement2.style.marginTop = "300px";

  }
</script>
<script>
  function nav() {
    document.getElementById("nav-home-tab").classList.toggle("active");;
  }
</script>

</html><?php /**PATH D:\fatma\E-Form\resources\views/arsipSPT.blade.php ENDPATH**/ ?>