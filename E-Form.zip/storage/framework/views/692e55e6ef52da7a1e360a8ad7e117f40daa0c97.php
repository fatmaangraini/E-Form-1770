<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js" integrity="sha512-aVKKRRi/Q/YV+4mjoKBsE4x3H+BkegoM/em46NNlCqNTmUYADjBbeNefNxYV7giUp0VxICtqdrbqU7iVaeZNXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <title>Formulir 1770-IV</title>
    <style>
        .bg-grey {
            font-family: arial;
            background-color: #ccc;
        }

        .vericaltext {
            writing-mode: vertical-lr;
            text-orientation: use-glyph-orientation;
        }

        .year {
            border: 1px solid black;
            width: 20px;
            font-size: 25px;
        }

        table tr th {
            border: 1px solid black;
            font-size: 25px;
        }
    </style>
</head>

<body class="bg-grey" style="padding: 1% 10% 1% 10%">
    <div class="container " style="width : 90%; background-color: #fff;">
        <div class="row" style="border-bottom: 2px solid black;">
            <div class="col-2" style="padding: 50px 0px 10px 10px">
                <h1 style="font-size: 20px; font-weight: bold; text-align: center; margin-top: -10px">FORMULIR</h1>
                <h1 style="font-size: 40px; font-weight: bold; text-align: center; margin-top: 30px">1770-IV</h1>
                <p style="font-size: 10px; font-weight: bold; text-align: center; margin-top: 30px">KEMENTERIAN KEUANGAN
                    RI DIREKTORAT JENDERAL PAJAK
                </p>
            </div>
            <div class="col-6" style="border-left: 2px solid black; border-right:2px solid black;">
                <div class="row">
                    <b style="font-size: 18px; text-align: center;">LAMPIRAN-IV </b>
                    <p style=" font-size: 18px; font-weight: bold;  text-align: center; border-bottom: 2px solid black">
                        SPT TAHUNAN PPh WAJIB PAJAK ORANG PRIBADI</p>
                </div>
                <div class="row">
                    <b style="font-size: 12px;">* HARTA PADA AKHIR TAHUN</b>
                    <b style="font-size: 12px;">* KEWAJIBAN/UTANG PADA AKHIR TAHUN</b>
                    <b style="font-size: 12px;">* DAFTAR SUSUNAN ANGGOTA KELUARGA</b>
                </div>
            </div>

            <div class="col-4" style="padding: 10px 10px 10px 10px">
                <!-- <b class="vericaltext fs-7">
                    TAHUN PAJAK
                </b> -->
                <a href="/formulir-III" class="btn btn-secondary" style="font-size: 12px; width: 120px; height: 30px; margin-left: 150px">Selanjutnya</a>
                <div class="row" style="padding: 4% 10%;">
                    <div class="col">
                        <table>
                            <tr>
                                <th style="text-align: center" width="60px"><?php echo e(mb_substr($spt['tahun'], 0, 1)); ?></th>
                                <th style="text-align: center" width="60px"><?php echo e(mb_substr($spt['tahun'], 1, 1)); ?></th>
                                <th style="text-align: center" width="60px"><?php echo e(mb_substr($spt['tahun'], 2, 1)); ?></th>
                                <th style="text-align: center" width="60px"><?php echo e(mb_substr($spt['tahun'], 3, 1)); ?></th>
                            </tr>
                        </table>
                    </div>
                </div>
                <div class="row" style="padding: 1% 20%;">
                    <div class="col-4">
                        <table>
                            <tr>
                                <th>0</th>
                                <th>1</th>
                                <th><?php echo e(mb_substr($spt['tahun'], 2, 1)); ?></th>
                                <th><?php echo e(mb_substr($spt['tahun'], 3, 1)); ?></th>

                            </tr>
                        </table>
                    </div>
                    <div class="col-3">
                        <p style="padding: 10px 10px ;">sd</p>
                    </div>
                    <div class="col-4">
                        <table>
                            <tr>
                                <th>1</th>
                                <th>2</th>
                                <th><?php echo e(mb_substr($spt['tahun'], 2, 1)); ?></th>
                                <th><?php echo e(mb_substr($spt['tahun'], 3, 1)); ?></th>
                            </tr>
                        </table>
                    </div>
                </div>

                <div class="form-check" style="display:inline-block; margin-left: 10px">
                    <input style="display:inline;" class="form-check-input" type="radio" name="flexRadioDisabled" id="flexRadioDisabled">
                    <label class="form-check-label" for="flexRadioDisabled" style="font-size: 14px;">
                        Pembukuan
                    </label>
                </div>
                <div class="form-check" style="display:inline-block; margin-left: 10px">
                    <input class="form-check-input" type="radio" name="flexRadioDisabled" id="flexRadioCheckedDisabled" checked>
                    <label class="form-check-label" for="flexRadioCheckedDisabled" style="font-size: 14px;">
                        Pencatatan
                    </label>
                </div>
                <div class="col-sm-12" style="background-color: #F0E68C ; padding: 4px 10px 10px 10px ; height: 30PX">
                    <div class="input-group mb-6">
                        <div class="input-group-prepend">
                            <div style="margin-left: -11px">
                                <input type="checkbox" aria-label="Checkbox for following text input" style="width: 20px;">
                            </div>
                        </div>
                        <label class="col-sm-9" style="font-size: 11px; text-align: center">SPT Pembetulan Ke</label>
                        <input style="width:20px; height: 20px; border: 1px solid;" value="<?php echo e($spt['pembetulan']); ?>">
                    </div>
                </div>
            </div>
        </div>
        <b style="font-size: 10px;">PERHATIAN *SEBELUM MENGISI BACALAH PETUNJUK PENGISIAN *ISI DENGAN HURU CETAK/DIKETIK
            DENGAN TINTA HITAM *BERI TANDA X DALAM KOTAK SESUAI PILIHAN</b>
        <div class="col-sm-11.5" style=" border: 1px solid black; background-color: #F0E68C ; padding: 4px 20px 10px 10px ; height: 80PX; border: 2px solid; margin-left: 10px">
            <div class="row">
                <label class="col-sm-4 col-form-label" style="font-size: 12px;">NPWP</label>
                <div class="col-sm-8">
                    <input class="form-control" type="text" style="border: 1px solid black; height: 30px; border-radius: 1px; " value="<?php echo e($npwp); ?>" disabled="disabled" id="formatnpwpfix">
                </div>
            </div>
            <div class="row">
                <label class="col-sm-4 col-form-label" style="font-size: 12px;">NAMA WAJIB PAJAK</label>
                <div class="col-sm-8">
                    <input class="form-control" type="text" style="border: 1px solid black; height: 30px; border-radius: 1px;" placeholder="<?php echo e($nama); ?>" disabled="disabled">
                </div>
            </div>
        </div>
        <p style="font-size: 11px; margin-left:10px">BAGIAN A. HARTA PADA AKHIR TAHUN</p>
        <button type="button" data-bs-toggle="modal" data-bs-target="#exampleModal" data-bs-whatever="@mdo">Import Data</button>
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Import Data</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="/DataHartaImport" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="input-group mb-3">
                                <input type="file" name="file" class="form-control">
                                <button class="btn btn-primary" type="submit">Submit</button>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>

        <!-- BAGIAN A. HARTA -->
        <table id="A_TblHarta" class="display">
            <thead>
                <tr>
                    <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width:25%; height: 30px">
                        KODE HARTA</th>
                    <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width:20%;">
                        NAMA HARTA</th>
                    <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width:20%;">
                        TAHUN PEROLEHAN</th>
                    <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width:20%;">
                        HARGA PEROLEHAN</th>
                    <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width:20%;">
                        KETERANGAN</th>
                </tr>

            </thead>
            <tbody>
                <?php $__currentLoopData = $data_harta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                <tr>
                    <td style="border: 1px solid black"><select name='harta' style="width:100%; height: 28px; border: 1px solid white">
                            <option value='pilih'>Pilih...</option>
                            <option value='011' <?php if($dh['kode_harta'] == "011"): ?> selected="selected" <?php endif; ?>>011 - Uang Tunai</option>
                            <option value='012' <?php if($dh['kode_harta'] == "012"): ?> selected="selected" <?php endif; ?>>012 - Tabungan</option>
                            <option value='pilih'>013 - Giro</option>
                            <option value='pilih'>014 - Deposito</option>
                            <option value='pilih'>019 - Setara Kas Lainnya</option>
                            <option value='pilih'>021 - Piutang</option>
                            <option value='pilih'>022 - Piutang Afiliasi (Piutang kepada pihak yang mempunyai hubungan
                                istimewa sebagaimana dimaksud)</option>
                            <option value='pilih'>029 - Piutang Lainnya</option>
                            <option value='pilih'>031 - Saham Yang Dibeli Untuk Dijual Kembali</option>
                            <option value='pilih'>032 - Saham</option>
                            <option value='pilih'>033 - Obligasi Perusahaan</option>
                            <option value='pilih'>034 - Obligasi Pemerintah Indonesia (Obligasi Ritel Indonesia atau ORI,
                                surat berharga syariah negara, dll)</option>
                            <option value='pilih'>035 - Surat Utang Lainnya</option>
                            <option value='pilih'>036 - Reksadana</option>
                            <option value='pilih'>037 - Instrumen Derivatif (Right, Warran, Kontrak Berjangka, Opsi, dll)
                            </option>
                            <option value='pilih'>038 - Penyertaan Modal Perusahaan Lain Yang Tidak Atas Saham Meliputi
                                Penyertaan Modal Pada CV, Firma, dan Sejenisnya</option>
                            <option value='pilih'>039 - Investasi Lainnya</option>
                            <option value='pilih'>041 - Sepeda</option>
                            <option value='pilih'>042 - Sepeda Motor</option>
                            <option value='pilih'>043 - Mobil </option>
                            <option value='pilih'>049 - Alat Transportasi Lainnya</option>
                            <option value='pilih'>051 - Logam Mulia (Emas Batangan, Emas Perhiasan, Platina Batangan,
                                Platina Perhiasan, Logam Mulia Lainnya)</option>
                            <option value='pilih'>052 - Batu Mulia (Intan, Berlian. Batu Mulia Lainnya)</option>
                            <option value='pilih'>053 - Barang Seni dan Antik (Barang-Barang Seni, Barang-Barang Antik)
                            </option>
                            <option value='pilih'>054 - Kapal Pesiar, Pesawat Terbang, Helikopter,Jetski dan Peralatan
                                Olahraga Khusus</option>
                            <option value='pilih'>055 - Peralatan Elektronik dan Furnitur</option>
                            <option value='pilih'>059 - Harta Bergerak Lainnya</option>
                            <option value='pilih'>061 - Tanah dan/atau Bangunan Untuk Tempat Tinggal</option>
                            <option value='pilih'>062 - Tanah dan/atau Bangunan Untuk Usaha (Toko, Pabrik, Gudang, dan
                                Sejenisnya)</option>
                            <option value='pilih'>063 - Tanah atau Lahan Untuk Usaha (Lahan Pertanian, Perkebunan,
                                Perikanan Darat, dan Sejenisnya)</option>
                            <option value='pilih'>069 - Harta Tidak Bergerak Lainnya</option>
                        </select></td>
                    <td style="border: 1px solid black;"><input class="text" value="<?php echo e($dh['nama_harta']); ?>" style="width: 100%; border: 1px solid white;text-align: center">
                    </td>
                    <td style="border: 1px solid black;"><input class="text" value="<?php echo e($dh['tahun_perolehan']); ?>" style="width: 100%; border: 1px solid white;text-align: center">
                    </td>
                    <td style="border: 1px solid black;"><input type="text" oninput="format(this.value)" value="<?php echo e($dh['harta_perolehan']); ?>" class="harga_perolehan" style="width: 100%; border: 1px solid white;text-align: center">
                    </td>
                    <td style="border: 1px solid black;"><input class="text" value="<?php echo e($dh['keterangan']); ?>" style="width: 100%; border: 1px solid white;text-align: center">
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div style="padding: 10px;"></div>
        <table>
            <tr>
                <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 670px;  height: 30px">
                    JUMLAH BAGIAN A</th>
                <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 400px; background-color: #F0E68C">
                    <input type="text" class="form-control" readonly="readonly" style="background-color: #F0E68C; text-align: right" name="hasil1" id="hasil1">
                </th>
            </tr>
        </table>
        <button type="button" onclick="addTableHarta(this)">Tambah</button>
        <button type="button" onclick="deleteTableHarta('A_TblHarta')">Hapus</button>

        <template id="rowTemplateHarta">
            <tr>
                <td style="border: 1px solid black"><select name='harta' style="width:100%; height: 28px; border: 1px solid white">
                        <option value='pilih'>Pilih...</option>
                        <option value='pilih'>011 - Uang Tunai</option>
                        <option value='pilih'>012 - Tabungan</option>
                        <option value='pilih'>013 - Giro</option>
                        <option value='pilih'>014 - Deposito</option>
                        <option value='pilih'>019 - Setara Kas Lainnya</option>
                        <option value='pilih'>021 - Piutang</option>
                        <option value='pilih'>022 - Piutang Afiliasi (Piutang kepada pihak yang mempunyai hubungan
                            istimewa sebagaimana dimaksud)</option>
                        <option value='pilih'>029 - Piutang Lainnya</option>
                        <option value='pilih'>031 - Saham Yang Dibeli Untuk Dijual Kembali</option>
                        <option value='pilih'>032 - Saham</option>
                        <option value='pilih'>033 - Obligasi Perusahaan</option>
                        <option value='pilih'>034 - Obligasi Pemerintah Indonesia (Obligasi Ritel Indonesia atau ORI,
                            surat berharga syariah negara, dll)</option>
                        <option value='pilih'>035 - Surat Utang Lainnya</option>
                        <option value='pilih'>036 - Reksadana</option>
                        <option value='pilih'>037 - Instrumen Derivatif (Right, Warran, Kontrak Berjangka, Opsi, dll)
                        </option>
                        <option value='pilih'>038 - Penyertaan Modal Perusahaan Lain Yang Tidak Atas Saham Meliputi
                            Penyertaan Modal Pada CV, Firma, dan Sejenisnya</option>
                        <option value='pilih'>039 - Investasi Lainnya</option>
                        <option value='pilih'>041 - Sepeda</option>
                        <option value='pilih'>042 - Sepeda Motor</option>
                        <option value='pilih'>043 - Mobil </option>
                        <option value='pilih'>049 - Alat Transportasi Lainnya</option>
                        <option value='pilih'>051 - Logam Mulia (Emas Batangan, Emas Perhiasan, Platina Batangan,
                            Platina Perhiasan, Logam Mulia Lainnya)</option>
                        <option value='pilih'>052 - Batu Mulia (Intan, Berlian. Batu Mulia Lainnya)</option>
                        <option value='pilih'>053 - Barang Seni dan Antik (Barang-Barang Seni, Barang-Barang Antik)
                        </option>
                        <option value='pilih'>054 - Kapal Pesiar, Pesawat Terbang, Helikopter,Jetski dan Peralatan
                            Olahraga Khusus</option>
                        <option value='pilih'>055 - Peralatan Elektronik dan Furnitur</option>
                        <option value='pilih'>059 - Harta Bergerak Lainnya</option>
                        <option value='pilih'>061 - Tanah dan/atau Bangunan Untuk Tempat Tinggal</option>
                        <option value='pilih'>062 - Tanah dan/atau Bangunan Untuk Usaha (Toko, Pabrik, Gudang, dan
                            Sejenisnya)</option>
                        <option value='pilih'>063 - Tanah atau Lahan Untuk Usaha (Lahan Pertanian, Perkebunan,
                            Perikanan Darat, dan Sejenisnya)</option>
                        <option value='pilih'>069 - Harta Tidak Bergerak Lainnya</option>
                    </select></td>
                <td style="border: 1px solid black;"><input class="text" style="width: 100%; border: 1px solid white;text-align: center">
                </td>
                <td style="border: 1px solid black;"><input class="text" style="width: 100%; border: 1px solid white;text-align: center">
                </td>
                <td style="border: 1px solid black;"><input type="text" oninput="format(this.value)" class="harga_perolehan" style="width: 100%; border: 1px solid white;text-align: center">
                </td>
                <td style="border: 1px solid black;"><input class="text" style="width: 100%; border: 1px solid white;text-align: center">
                </td>
            </tr>
        </template>
        <!-- PENUTUP BAGIAN A. HARTA -->

        <!-- BAGIAB B. KEWAJIBAN/UTANG -->
        <p style="font-size: 11px; padding: 10px 0px 0px 0px">BAGIAN B : KEWAJIBAN/UTANG PADA AKHIR TAHUN</p>
        <button type="button" data-bs-toggle="modal" data-bs-target="#exampleModal" data-bs-whatever="@mdo">Import Data</button>
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="import" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="input-group mb-3">
                                <input type="file" name="file" class="form-control">
                                <button class="btn btn-primary" type="submit">Submit</button>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>
        <table id="B_TblUtang" class="display" style="width:100%">
            <tr>
                <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width:25%; height: 30px;text-align: center">
                    KODE UTANG</th>
                <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width:20%;text-align: center">
                    NAMA PEMBERI PINJAMAN</th>
                <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width:20%;text-align: center">
                    ALAMAT PEMBERI PINJAMAN</th>
                <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width:20%;text-align: center">
                    TAHUN PEMINJAMAN</th>
                <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width:20%;text-align: center">
                    JUMLAH PINJAMAN</th>
            </tr>
            <tr>
                <td style="border: 1px solid black"><select name='harta' style="width: 100%; height: 28px; border: 1px solid white">
                        <option value='pilih'>Pilih...</option>
                        <option value='pilih'>101 - Utang Bank/Lembaga Keuangan Bukan Bank (KPR, Leasing Kendaraan
                            Bermotor, dan sejenisnya)</option>
                        <option value='pilih'>102 - Utang Kartu Kredit</option>
                        <option value='pilih'>103 - Utang Afiliasi (Pinjaman dari pihak yang memiliki hubungan
                            istimewasebagaimana dimaksud dalam Pasal 18 ayat (4) Undang-UndangPPh)</option>
                        <option value='pilih'>109 - Utang Lainnya</option>
                    </select></td>
                <td style="border: 1px solid black;"><input class="text" style="width: 100%; border: 1px solid white;text-align: center">
                </td>
                <td style="border: 1px solid black;"><input class="text" style="width: 100%; border: 1px solid white;text-align: center">
                </td>
                <td style="border: 1px solid black;"><input class="text" style="width: 100%; border: 1px solid white;text-align: center">
                </td>
                <td style="border: 1px solid black;"><input type="text" oninput="format2(this.value)" class="jumlah_pinjaman" style="width: 100%; border: 1px solid white;text-align: center">
                </td>
            </tr>
        </table>
        <div style="padding: 10px;"></div>
        <table>
            <tr>
                <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 670px;  height: 30px">
                    JUMLAH BAGIAN B</th>
                <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 400px; background-color: #F0E68C">
                    <input type="text" class="form-control" disabled="true" readonly="readonly" style="background-color: #F0E68C; text-align: right" name="hasil2" id="hasil2">
                </th>
            </tr>
        </table>
        <button type="button" onclick="addTableUtang(this)">Tambah</button>
        <button type="button" onclick="deleteTableUtang('B_TblUtang')">Hapus</button>
        <template id="rowTemplateUtang">
            <tr>
                <td style="border: 1px solid black"><select name='harta' style="width: 100%; height: 28px; border: 1px solid white">
                        <option value='pilih'>Pilih...</option>
                        <option value='pilih'>101 - Utang Bank/Lembaga Keuangan Bukan Bank (KPR, Leasing Kendaraan
                            Bermotor, dan sejenisnya)</option>
                        <option value='pilih'>102 - Utang Kartu Kredit</option>
                        <option value='pilih'>103 - Utang Afiliasi (Pinjaman dari pihak yang memiliki hubungan
                            istimewasebagaimana dimaksud dalam Pasal 18 ayat (4) Undang-UndangPPh)</option>
                        <option value='pilih'>109 - Utang Lainnya</option>
                    </select></td>
                <td style="border: 1px solid black;"><input class="text" style="width: 100%; border: 1px solid white;text-align: center">
                </td>
                <td style="border: 1px solid black;"><input class="text" style="width: 100%; border: 1px solid white;text-align: center">
                </td>
                <td style="border: 1px solid black;"><input class="text" style="width: 100%; border: 1px solid white;text-align: center">
                </td>
                <td style="border: 1px solid black;"><input type="text" oninput="format2(this.value)" class="jumlah_pinjaman" style="width: 100%; border: 1px solid white;text-align: center">
                </td>
            </tr>
        </template>
        <!-- PENUTUP BAGIAN B. UTANG -->

        <!-- BAGIAN C. KELUARGA -->
        <p style="font-size: 11px; padding: 10px 0px 0px 0px">BAGIAN C : DAFTAR SUSUNAN ANGGOTA KELUARGA</p>
        <button type="button" data-bs-toggle="modal" data-bs-target="#exampleModal" data-bs-whatever="@mdo">Import Data</button>
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="import" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="input-group mb-3">
                                <input type="file" name="file" class="form-control">
                                <button class="btn btn-primary" type="submit">Submit</button>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>
        <table id="C_TblKeluarga" class="display" style="width:100%">
            <tr>
                <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 25%;  height: 30px">
                    NAMA ANGGOTA KELUARGA</th>
                <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 25%">
                    NIK</th>
                <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 25%">
                    HUBUNGAN</th>
                <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 25%">
                    PEKERJAAN</th>
            </tr>
            <tr>
                <td style="border: 1px solid black;"><input class="text" style="width: 100%; border: 1px solid white; text-align:center">
                </td>
                <td style="border: 1px solid black;"><input class="text" style="width: 100%; border: 1px solid white; text-align:center" maxlength="16" oninput="formatNpwp()" id="formatnpwp">
                </td>
                <td style="border: 1px solid black;"><input class="text" style="width: 100%; border: 1px solid white; text-align:center">
                </td>
                <td style="border: 1px solid black;"><input class="text" style="width: 100%; border: 1px solid white; text-align:center">
                </td>
            </tr>
        </table>
        <button type="button" onclick="addTableKeluarga(this)">Tambah</button>
        <button type="button" onclick="deleteTableKeluarga('C_TblKeluarga')">Hapus</button>
        <template id="rowTemplateKeluarga">
            <tr>
                <td style="border: 1px solid black;"><input class="text" style="width: 100%; border: 1px solid white; text-align:center">
                </td>
                <td style="border: 1px solid black;"><input class="text" style="width: 100%; border: 1px solid white; text-align:center" oninput="formatNpwp(this)" maxlength="16">
                </td>
                <td style="border: 1px solid black;"><input class="text" style="width: 100%; border: 1px solid white; text-align:center">
                </td>
                <td style="border: 1px solid black;"><input class="text" style="width: 100%; border: 1px solid white; text-align:center">
                </td>
            </tr>
        </template>
        <!-- PENUTUP BAGIAN C. KELUARGA -->
    </div>


    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
    </script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/numeral.js/2.0.6/numeral.min.js"></script>

    <script>
        let tr = 1;
        let tr2 = 1;
        let tr3 = 1;
        $(document).ready(function() {
            formatNpwp2();
        });

        function addTableHarta($this) {
            var template = document.querySelector('#rowTemplateHarta'),
                tbl = document.querySelector('#A_TblHarta'),
                td_choice = template.content.querySelectorAll("td"),
                tr_count = tbl.rows.length;

            td_choice.textContent = tr_count;
            var clone = document.importNode(template.content, true);
            tbl.appendChild(clone);
            format();
        }

        function deleteTableHarta(nama) {

            let tr_length = $('#' + nama + ' tr').length;

            if (tr_length > 2) {
                $('#' + nama + ' tr:last').remove();
            }
            format();
        }

        function addTableUtang($this) {
            var template = document.querySelector('#rowTemplateUtang'),
                tbl = document.querySelector('#B_TblUtang'),
                td_choice = template.content.querySelectorAll("td"),
                tr_count = tbl.rows.length;

            td_choice.textContent = tr_count;
            var clone = document.importNode(template.content, true);
            tbl.appendChild(clone);
            format2();
        }

        function deleteTableUtang(nama) {

            let tr_length = $('#' + nama + ' tr').length;

            if (tr_length > 2) {
                $('#' + nama + ' tr:last').remove();
            }
            format2();
        }

        function addTableKeluarga($this) {
            var template = document.querySelector('#rowTemplateKeluarga'),
                tbl = document.querySelector('#C_TblKeluarga'),
                td_choice = template.content.querySelectorAll("td"),
                tr_count = tbl.rows.length;

            td_choice.textContent = tr_count;
            var clone = document.importNode(template.content, true);
            tbl.appendChild(clone);

        }

        function deleteTableKeluarga(nama) {

            let tr_length = $('#' + nama + ' tr').length;

            if (tr_length > 2) {
                $('#' + nama + ' tr:last').remove();
            }

        }
    </script>

    <script>
        let sum = 0;
        let tmp = 0;

        function format() {
            $('.harga_perolehan').each(function() {
                console.log(this.value)
                if (this.value.length > 0 && this.value != 0) {
                    tmp2 = getNumPrice(this.value, '.');
                    this.value = numeral(this.value).format();
                    tmp += parseFloat(tmp2)
                } else {
                    tmp += 0
                }
            });
            sum = tmp
            $('#hasil1').val(numeral(sum).format());
            tmp = 0;
        }

        function format2() {
            $('.jumlah_pinjaman').each(function() {
                console.log(this.value)
                if (this.value.length > 0 && this.value != 0) {
                    tmp2 = getNumPrice(this.value, '.');
                    this.value = numeral(this.value).format();
                    tmp += parseFloat(tmp2)
                } else {
                    tmp += 0
                }
            });
            sum = tmp
            $('#hasil2').val(numeral(sum).format());
            tmp = 0;
        }

        function getNumPrice(price, decimalpoint) {
            var p = price.split(decimalpoint);
            for (var i = 0; i < p.length; i++) p[i] = p[i].replace(/\D/g, '');
            return p.join('.');
        }

        function formatNpwp(event) {
            formatnpwp = event.value
            formatnpwp2 = event
            if (!formatnpwp.match(/^[0-9./-]+$/i)) {
                //  alert('Angka saja')?
                formatnpwp2.value = formatnpwp.slice(0, -1);
                return;
            }
            formatnpwp2.value = formatnpwp.replace();
        }

        function formatNpwp2() {
            formatnpwp = document.getElementById('formatnpwpfix').value
            formatnpwp2 = document.getElementById('formatnpwpfix')
            if (typeof formatnpwp === 'string') {

            }
            formatnpwp2.value = formatnpwp.replace(/(\d{2})(\d{3})(\d{3})(\d{1})(\d{3})(\d{3})/, '$1.$2.$3.$4-$5.$6');
        }
    </script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"
        integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"
        integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous">
    </script>
    -->

</body>

</html>
<?php /**PATH D:\fatma\E-Form\resources\views/formulir-IV.blade.php ENDPATH**/ ?>