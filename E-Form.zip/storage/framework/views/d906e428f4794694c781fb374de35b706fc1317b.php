<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js" integrity="sha512-aVKKRRi/Q/YV+4mjoKBsE4x3H+BkegoM/em46NNlCqNTmUYADjBbeNefNxYV7giUp0VxICtqdrbqU7iVaeZNXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <title>Formulir 1770-I</title>
    <style>
        .bg-grey {
            font-family: arial;
            background-color: #ccc;
            padding: 1% 10% 1% 10%
        }

        .container {
            width: 90%;
            background-color: #fff
        }

        .satu {
            border-bottom: 2px solid black;
        }

        .formulir {
            padding: 50px 0px 10px 10px;
        }

        .formulir h6 {
            font-size: 10px;
            font-weight: bold;
            text-align: center;
            margin-top: -30px;
        }

        .formulir .h1 {
            font-size: 20px;
            font-weight: bold;
            text-align: center;
        }

        .formulir .h2 {
            font-size: 40px;
            font-weight: bold;
            text-align: center;
            margin-top: 30px;
        }

        .formulir p {
            font-size: 10px;
            font-weight: bold;
            text-align: center;
            margin-top: 30px;
            padding: 0px 5px 0px 0px;
        }

        .lampiran {
            border-left: 2px solid black;
            border-right: 2px solid black;
        }

        .dua b {
            font-size: 18px;
            text-align: center;
        }

        .dua p {
            font-size: 18px;
            font-weight: bold;
            text-align: center;
            border-bottom: 2px solid black;
        }

        .tiga {
            font-size: 12px;
        }

        .tahap {
            padding: 10px 10px 10px 10px;
        }

        .tahap a {
            font-size: 12px;
            width: 120px;
            height: 30px;
            margin-left: 10px
        }

        .tahap button {
            font-size: 12px;
            width: 120px;
            height: 30px;
            margin-left: 10px
        }

        .tahun {
            padding: 4% 10%;
        }

        .tahun th {
            text-align: center;
            width: 60px;
        }

        .bulan {
            padding: 1% 10%;
        }

        .bulan p {
            margin: 15px;
        }

        .form-check {
            font-size: 14px;
            margin: 0px 0px 0px 30px;
        }

        .stabilo {
            background-color: #F0E68C;
            padding: 4px 10px 10px 10px;
            height: 30px;
        }

        .input-group-prepend {
            margin-left: -11px
        }

        .input-group-prepend input {
            width: 20px;
            position: relative;
            left: 30px;
        }

        .mb-6 label {
            font-size: 12px;
            text-align: center;
            position: relative;
            left: 20px;
        }

        .mb-6 input {
            width: 20px;
            height: 20px;
            border: 1px solid;
        }

        .year {
            border: 1px solid black;
            width: 20px;
            font-size: 25px;
        }

        table tr th {
            border: 1px solid black;
            font-size: 25px;
        }

        .cetak-tebal {
            font-size: 10px;
        }

        .kotak {
            border: 1px solid black;
            background-color: #F0E68C;
            padding: 4px 20px 10px 10px;
            height: 75px;
            border: 2px solid;
        }

        .col-form-label {
            font-size: 12px;
        }

        .col-sm-8 input {
            border: 1px solid black;
            height: 30px;
            border-radius: 1px;
        }

        .jarak {
            padding: 10px 5px 1px 0px
        }

        .jarak p {
            font-size: 11px;
            padding: 0px 0px -7px 0px"

        }

        .thsatu {
            border: 1px solid black;
            font-size: 12px;
            font-weight: bold;
            text-align: center;
            width: 5%;
            height: 30px
        }

        .thdua {
            border: 1px solid black;
            font-size: 12px;
            font-weight: bold;
            text-align: center;
            width: 32%
        }

        .thtiga {
            border: 1px solid black;
            font-size: 12px;
            font-weight: bold;
            text-align: center;
            width: 30%
        }

        .thempat {
            border: 1px solid black;
            font-size: 12px;
            font-weight: bold;
            text-align: center;
            width: 7%
        }

        .kolom td {
            height: 20px;
        }

        .tdsatu {
            font-size: 14px;
            text-align: center;
            border: 1px solid black;
            height: 40px
        }

        .tddua {
            font-size: 13px;
            border: 1px solid black;
            height: 40px
        }

        .tdtiga {
            border: 1px solid black;
            height: 40px
        }

        .tdempat {
            border: 1px solid black;
            height: 40px
        }

        .tdtiga input {
            width: 100%;
            height: 40px;
            border: 1px solid white;
            text-align: right
        }

        .tdempat input {
            width: 100%;
            height: 40px;
            border: 1px solid white;
            text-align: center
        }

        .jumlahB {
            border: 1px solid black;
            width: 30%;
            height: 40px;
            background-color: #F0E68C
        }

        .jumlahB input {
            text-align: right
        }

        #BagianC tr th {
            border: 1px solid black;
            font-size: 12px;
            font-weight: bold;
            text-align: center;
            width: 20%;
            height: 35px
        }

        #table {
            display: none;
        }

        #table td {
            border: 1px solid black;
        }

        #table td input {
            border: 1px solid white;
            width: 100%;
            text-align: center
        }

        .jumlahC {
            border: 1px solid black;
            font-size: 12px;
            font-weight: bold;
            text-align: center;
            width: 80%;
            height: 30px
        }

        .thjumlah {
            border: 1px solid black;
            font-size: 12px;
            font-weight: bold;
            text-align: center;
            width: 400px;
            background-color: #F0E68C
        }

        .thjumlah input {
            border: 1px solid white;
            width: 100%;
            height: 30px;
            text-align: center;
            background-color: #F0E68C
        }

        .thdua2 {
            border: 1px solid black;
            font-size: 12px;
            text-align: center;
            font-weight: bold;
            width: 60%
        }

        .tddua2 {
            border: 1px solid black;
            font-size: 14px
        }

        .tddua2 input {
            width: 100%;
            height: 40px;
            border: 1px solid white;
            text-align: right
        }

        .tdsatu2 {
            border: 1px solid black;
            font-size: 12px;
            font-weight: bold;
            text-align: center;
            width: 57%;
            height: 40px;
        }

        .tddua3 {
            border: 1px solid black;
            font-size: 12px;
            font-weight: bold;
            text-align: center;
            width: 8%
        }

        .tdtiga2 {
            border: 1px solid black;
            ;
            background-color: #F0E68C
        }
    </style>
</head>

<body class="bg-grey">
    <div class="container">
        <div class="row satu">
            <div class="col-2 formulir">
                <h6>HALAMAN 2</h6>
                <h1 class="h1">FORMULIR</h1>
                <h1 class="h2">1770-I</h1>
                <p>KEMENTERIAN KEUANGAN RI DIREKTORAT JENDERAL PAJAK</p>
            </div>
            <div class="col-6 lampiran">
                <div class="row dua">
                    <b>LAMPIRAN-I</b>
                    <p>SPT TAHUNAN PPh WAJIB PAJAK ORANG PRIBADI</p>
                </div>
                <div class="row tiga">
                    <b>* PERHITUNGAN PENGHASILAN NETO DALAM NEGERI DARI USAHA DAN/ATAU PEKERJAAN BEBAS BAGI WAJIB PAJAK YANG MENYELENGGARAKAN PENCATATAN</b>
                    <b>* PERHITUNGAN PENGHASILAN NETO DALAM NEGERI SEHUBUNGAN DENGAN PEKERJAAN</b>
                    <b>* PENGHITUNGAN PENGHASILAN DALAM NEGERI LAINNYA </b>
                </div>
            </div>

            <div class="col-4 tahap">
                <form action="/formulir1770">
                    <input type="hidden" name="hasil1" value="<?php echo e(request()->all()['hasil1'] ?? 0); ?>">
                    <input type="hidden" name="hasil" value="<?php echo e(request()->all()['hasil'] ?? 0); ?>">
                    <input type="hidden" name="hasilPPhDipotongDipungut" value="<?php echo e(request()->all()['hasilPPhDipotongDipungut'] ?? 0); ?>">
                    <a href="/formulir-I" class="btn btn-secondary" font-size: 12px; width: 120px; height: 30px; margin-left: 10px>Sebelumnya</a>
                    <button class=" btn btn-secondary" type="submit">Selanjutnya</button>
                    <div class="row tahun">
                        <div class="col">
                            <table>
                                <tr>
                                    <th style="text-align: center" width="60px"><?php echo e(mb_substr($spt['tahun'], 0, 1)); ?></th>
                                    <th style="text-align: center" width="60px"><?php echo e(mb_substr($spt['tahun'], 1, 1)); ?></th>
                                    <th style="text-align: center" width="60px"><?php echo e(mb_substr($spt['tahun'], 2, 1)); ?></th>
                                    <th style="text-align: center" width="60px"><?php echo e(mb_substr($spt['tahun'], 3, 1)); ?></th>
                                </tr>
                            </table>
                        </div>
                    </div>
                    <div class="row bulan">
                        <div class="col-4">
                            <table>
                                <tr>
                                    <th>0</th>
                                    <th>1</th>
                                    <th><?php echo e(mb_substr($spt['tahun'], 2, 1)); ?></th>
                                    <th><?php echo e(mb_substr($spt['tahun'], 3, 1)); ?></th>
                                </tr>
                            </table>
                        </div>
                        <div class="col-2">
                            <p>sd</p>
                        </div>
                        <div class="col-4">
                            <table>
                                <tr>
                                    <th>1</th>
                                    <th>2</th>
                                    <th><?php echo e(mb_substr($spt['tahun'], 2, 1)); ?></th>
                                    <th><?php echo e(mb_substr($spt['tahun'], 3, 1)); ?></th>
                                </tr>
                            </table>
                        </div>
                    </div>

                    <div class="form-check" style="display:inline-block">
                        <input style="display:inline;" class="form-check-input" type="radio" name="flexRadioDisabled" id="flexRadioDisabled" checked onclick="Pembukuan()">
                        <label class="form-check-label" for="flexRadioDisabled">
                            Pembukuan
                        </label>
                    </div>
                    <div class="form-check" style="display:inline-block">
                        <input class="form-check-input" type="radio" name="flexRadioDisabled" id="flexRadioCheckedDisabled" onclick="Pencatatan()">
                        <label class="form-check-label" for="flexRadioCheckedDisabled">
                            Pencatatan
                        </label>
                    </div>
                    <div class="col-sm-12 stabilo">
                        <div class="input-group mb-6">
                            <div class="input-group-prepend">
                                <div>
                                    <input type="checkbox">
                                </div>
                            </div>
                            <label class="col-sm-9">SPT Pembetulan Ke</label>
                            <input>
                        </div>
                    </div>
            </div>
        </div>
        <b class="cetak-tebal">PERHATIAN *SEBELUM MENGISI BACALAH PETUNJUK PENGISIAN *ISI DENGAN HURU CETAK/DIKETIK
            DENGAN TINTA HITAM *BERI TANDA X DALAM KOTAK SESUAI PILIHAN</b>

        <div class="col-sm-11.5 kotak">
            <div class="row">
                <label class="col-sm-4 col-form-label">NPWP</label>
                <div class="col-sm-8">
                    <input class="form-control" type="text" value="<?php echo e($npwp); ?>" disabled="disabled" id="formatnpwpfix">
                </div>
            </div>
            <div class="row">
                <label class="col-sm-4 col-form-label">NAMA WAJIB PAJAK</label>
                <div class="col-sm-8">
                    <input class="form-control" type="text" value="<?php echo e($nama); ?>" disabled="disabled">
                </div>
            </div>
        </div>
        <div class="jarak">
            <p>BAGIAN B. PENGHASILAN NETO DALAM NEGERI DARI USAHA DAN/ATAU PEKERJAAN BEBAS
                (BAGI WAJIB PAJAK YANG MENYELENGGARAKAN PENCATATAN)</p>
        </div>
        <table id="Bagian_A" style="display: none;">
            <tr>
                <th class="thsatu">NO</th>
                <th class="thdua">JENIS USAHA</th>
                <th class="thtiga">PEREDARAN USAHA</br>(Rupiah)</th>
                <th class="thempat">NORMA</br>(%)</th>
                <th class="thtiga">PENGHASILAN NETO</br>(Rupiah)</th>
            </tr>
            <tr class="kolom">
                <td class="thsatu">(1)</td>
                <td class="thdua">(2)</td>
                <td class="thtiga">(3)</td>
                <td class="thempat">(4)</td>
                <td class="thtiga">(5)</td>
            </tr>
            <tr>
                <td class="tdsatu">1.</td>
                <td class="tddua">DAGANG</td>
                <td class="tdtiga"><input type="text" class="form-control" value="<?php echo e($formulir_i2b[0]->rupiah_peredaran_usaha ?? ''); ?>" oninput="format()" name="dagang_peredaran_usaha" id="dagang_peredaran_usaha" placeholder="0"></td>
                <td class="tdempat"><input type="text" class="form-control" value="<?php echo e($formulir_i2b[0]->norma ?? ''); ?>" id="norma_dagang" name="norma_dagang"></td>
                <td class="tdtiga"><input type="text" class="form-control" value="<?php echo e($formulir_i2b[0]->rupiah_penghasilan_neto ?? ''); ?>" oninput="format2()" name="dagang_penghasilan_neto" id="dagang_penghasilan_neto" placeholder="0"></td>
            </tr>
            <tr>
                <td class="tdsatu">2.</td>
                <td class="tddua">INDUSTRI</td>
                <td class="tdtiga"><input type="text" class="form-control" value="<?php echo e($formulir_i2b[1]->rupiah_peredaran_usaha ?? ''); ?>" oninput="format()" name="industri_peredaran_usaha" id="industri_peredaran_usaha" placeholder="0"></td>
                <td class="tdempat"><input type="text" class="form-control" value="<?php echo e($formulir_i2b[1]->norma ?? ''); ?>" id="norma_industri" name="norma_indutri"></td>
                <td class="tdtiga"><input type="text" class="form-control" value="<?php echo e($formulir_i2b[1]->rupiah_penghasilan_neto ?? ''); ?>" oninput="format3()" name="industri_penghasilan_neto" id="industri_penghasilan_neto" placeholder="0"></td>
            </tr>
            <tr>
                <td class="tdsatu">3.</td>
                <td class="tddua">JASA</td>
                <td class="tdtiga"><input type="text" class="form-control" value="<?php echo e($formulir_i2b[2]->rupiah_peredaran_usaha ?? ''); ?>" oninput="format()" name="jasa_peredaran_usaha" id="jasa_peredaran_usaha" placeholder="0"></td>
                <td class="tdempat"><input type="text" class="form-control" value="<?php echo e($formulir_i2b[2]->norma ?? ''); ?>" id="norma_jasa" name="norma_jasa"></td>
                <td class="tdtiga"><input type="text" class="form-control" value="<?php echo e($formulir_i2b[2]->rupiah_penghasilan_neto ?? ''); ?>" oninput="format4()" name="jasa_penghasilan_neto" id="jasa_penghasilan_neto" placeholder="0"></td>
            </tr>
            <tr>
                <td class="tdsatu">4.</td>
                <td class="tddua">PEKERJAAN BEBAS</td>
                <td class="tdtiga"><input type="text" class="form-control" value="<?php echo e($formulir_i2b[3]->rupiah_peredaran_usaha ?? ''); ?>" oninput="format()" name="pbebas_peredaran_usaha" id="pbebas_peredaran_usaha" placeholder="0"></td>
                <td class="tdempat"><input type="text" class="form-control" value="<?php echo e($formulir_i2b[3]->norma ?? ''); ?>" id="norma_pbebas" name="norma_pbebas"></td>
                <td class="tdtiga"><input type="text" class="form-control" value="<?php echo e($formulir_i2b[3]->rupiah_penghasilan_neto ?? ''); ?>" oninput="format5()" name="pbebas_penghasilan_neto" id="pbebas_penghasilan_neto" placeholder="0"></td>
            </tr>
            <tr>
                <td class="tdsatu">5.</td>
                <td class="tddua">USAHA LAINNYA</td>
                <td class="tdtiga"><input type="text" class="form-control" value="<?php echo e($formulir_i2b[4]->rupiah_peredaran_usaha ?? ''); ?>" oninput="format()" name="usaha_peredaran_usaha" id="usaha_peredaran_usaha" placeholder="0"></td>
                <td class="tdempat"><input type="text" class="form-control" value="<?php echo e($formulir_i2b[4]->norma ?? ''); ?>" id="norma_usaha" name="norma_usaha"></td>
                <td class="tdtiga"><input type="text" class="form-control" value="<?php echo e($formulir_i2b[4]->rupiah_penghasilan_neto ?? ''); ?>" oninput="format6()" name="usaha_penghasilan_neto" id="usaha_penghasilan_neto" placeholder="0"></td>
            </tr>
            <tr>
                <td class="tdsatu"></td>
                <td class="thdua">JUMLAH BAGIAN B</td>
                <td class="jumlahB"><input type="text" class="form-control" style="background-color: #F0E68C;" readonly="readonly" name="hasilusaha" id="hasilusaha"></td>
                <td class="thempat">JBB</td>
                <td class="jumlahB"><input input type="text" class="form-control" readonly="readonly" style="background-color: #F0E68C;" name="hasilneto" id="hasilneto"></td>
            </tr>
        </table>

        <table id="Bagian_A_disabled">
            <tr>
                <th class="thsatu">NO</th>
                <th class="thdua">JENIS USAHA</th>
                <th class="thtiga">PEREDARAN USAHA</br>(Rupiah)</th>
                <th class="thempat">NORMA</br>(%)</th>
                <th class="thtiga">PENGHASILAN NETO</br>(Rupiah)</th>
            </tr>
            <tr class="kolom">
                <td class="thsatu">(1)</td>
                <td class="thdua">(2)</td>
                <td class="thtiga">(3)</td>
                <td class="thempat">(4)</td>
                <td class="thtiga">(5)</td>
            </tr>
            <tr>
                <td class="tdsatu">1.</td>
                <td class="tddua">DAGANG</td>
                <td class="tdtiga"><input class="text" placeholder="0" disabled></td>
                <td class="tdempat"><input class="text" disabled></td>
                <td class="tdtiga"><input class="text" placeholder="0" disabled></td>
            </tr>
            <tr>
                <td class="tdsatu">2.</td>
                <td class="tddua">INDUSTRI</td>
                <td class="tdtiga"><input class="text" placeholder="0" disabled></td>
                <td class="tdempat"><input class="text" disabled></td>
                <td class="tdtiga"><input class="text" placeholder="0" disabled></td>
            </tr>
            <tr>
                <td class="tdsatu">3.</td>
                <td class="tddua">JASA</td>
                <td class="tdtiga"><input class="text" placeholder="0" disabled></td>
                <td class="tdempat"><input class="text" disabled></td>
                <td class="tdtiga"><input class="text" placeholder="0" disabled></td>
            </tr>
            <tr>
                <td class="tdsatu">4.</td>
                <td class="tddua">PEKERJAAN BEBAS</td>
                <td class="tdtiga"><input class="text" placeholder="0" disabled></td>
                <td class="tdempat"><input class="text" disabled></td>
                <td class="tdtiga"><input class="text" placeholder="0" disabled></td>
            </tr>
            <tr>
                <td class="tdsatu">5.</td>
                <td class="tddua">USAHA LAINNYA</td>
                <td class="tdtiga"><input class="text" placeholder="0" disabled></td>
                <td class="tdempat"><input class="text" disabled></td>
                <td class="tdtiga"><input class="text" placeholder="0" disabled></td>
            </tr>
            <tr>
                <td class="tdsatu"></td>
                <td class="thdua">JUMLAH BAGIAN B</td>
                <td class="jumlahB"><input type="text" class="form-control" style="background-color: #F0E68C;" readonly="readonly" name="hasilusaha" id="hasilusaha"></td>
                <td class="thempat">JBB</td>
                <td class="jumlahB"><input input type="text" class="form-control" readonly="readonly" style="background-color: #F0E68C;" name="hasilneto" id="hasilneto"></td>
            </tr>
        </table>
        <button type="button" onclick="BagianBSave(this)">Simpan</button>
        <button type="button" onclick="BagianBDelete()">Hapus</button>

        <script>
            function Pembukuan(src) {
                const myElement = document.getElementById("Bagian_A");
                myElement.style.display = "none";

                document.getElementById("Bagian_A_disabled").style.display = "block";
            }

            function Pencatatan(src) {
                const myElement = document.getElementById("Bagian_A_disabled");
                document.getElementById("Bagian_A").style.display = "block";

                myElement.style.display = "none";
            }
        </script>
        <div class="jarak">
            <p>BAGIAN C. PENGHASILAN NETO DALAM NEGERI SEHUBUNGAN DENGAN PEKERJAAN
                (TIDAK TERMASUK PENGHASILAN YANG DIKENAKAN PPh BERSIFAT FINAL)</p>
        </div>
        <table id="BagianC" class="display" width="100%">
            <tr>
                <th>NPWP PEMBERI KERJA</th>
                <th>NAMA PEMBERI KERJA</th>
                <th>PENGHASILAN BRUTO</th>
                <th>PENGURANGAN</br>PENGHASILAN BRUTO</th>
                <th>PENGHASILAN NETO</th>
            </tr>
            <tr>
                <td><input type="text" style="border: 1px solid black; height:35px; width: 100%; text-align:center"></td>
                <td><input type="text" style="border: 1px solid black; height:35px; width: 100%; text-align:center"></td>
                <td><input type="text" style="border: 1px solid black; height:35px; width: 100%; text-align:center" oninput="format_bagianC(this.value)" id="penghasilan_bruto" placeholder="0"></td>
                <td><input type="text" style="border: 1px solid black; height:35px; width: 100%; text-align:center" oninput="format_bagianC(this.value)" id="pengurangan_bruto" placeholder="0"></td>
                <td><input type="text" style="border: 1px solid black; height:35px; width: 100%; text-align:center" oninput="format_bagianC(this.value)" class="penghasilan_neto" placeholder="0"></td>
            </tr>
        </table>
        <table>
            <tr>
                <th class="jumlahC">JUMLAH BAGIAN C</th>
                <th class="thjumlah">
                    <input type="text" id="jumlah_bagianC" placeholder="0">
                </th>
            </tr>
        </table>
        <button type="button" onclick="addTableBagianC(this)">Tambah</button>
        <button type="button" onclick="deleteTableBagianC('BagianC')">Hapus</button>
        <button type="submit">Simpan</button>
        <template id="rowTemplateBagianC">
            <tr>
                <td><input type="text" style="border: 1px solid black; height:35px; width: 100%; text-align:center"></td>
                <td><input type="text" style="border: 1px solid black; height:35px; width: 100%; text-align:center"></td>
                <td><input type="text" style="border: 1px solid black; height:35px; width: 100%; text-align:center" oninput="format_bagianC(this.value)" id="penghasilan_bruto" placeholder="0"></td>
                <td><input type="text" style="border: 1px solid black; height:35px; width: 100%; text-align:center" oninput="format_bagianC(this.value)" id="pengurangan_bruto" placeholder="0"></td>
                <td><input type="text" style="border: 1px solid black; height:35px; width: 100%; text-align:center" oninput="format_bagianC(this.value)" class="penghasilan_neto" placeholder="0"></td>
            </tr>

        </template>

        <div class="jarak">
            <p>BAGIAN D. PENGHASILAN NETO DALAM NEGERI LAINNYA
                (TIDAK TERMASUK PENGHASILAN YANG DIKENAKAN PPh BERSIFAT FINAL)</p>
        </div>
        <table width="100%">
            <tr>
                <th class="thsatu">NO</th>
                <th class="thdua2">JENIS USAHA</th>
                <th class="thdua2">PENGHASILAN NETO</br>(Rupiah)</th>
            </tr>
            <tr class="kolom">
                <td class="thsatu">(1)</td>
                <td class="thdua">(2)</td>
                <td class="thdua">(3)</td>
            </tr>
            <tr>
                <td class="tdsatu">1.</td>
                <td class="tddua2">BUNGA</td>
                <td class="tddua2"><input type="text" oninput="format_bagianD()" name="bunga_penghasilan_neto" id="bunga_penghasilan_neto" placeholder="0"></td>
            </tr>
            <tr>
                <td class="tdsatu">2.</td>
                <td class="tddua2">ROYALTI</td>
                <td class="tddua2"><input type="text" oninput="format_bagianD()" name="royalti_penghasilan_neto" id="royalti_penghasilan_neto" placeholder="0"></td>
            </tr>
            <tr>
                <td class="tdsatu">3.</td>
                <td class="tddua2">SEWA</td>
                <td class="tddua2"><input type="text" oninput="format_bagianD()" name="sewa_penghasilan_neto" id="sewa_penghasilan_neto" placeholder="0"></td>
            </tr>
            <tr>
                <td class="tdsatu">4.</td>
                <td class="tddua2">PENGHARGAAN DAN HADIAH</td>
                <td class="tddua2"><input type="text" oninput="format_bagianD()" name="penghargaan_penghasilan_neto" id="penghargaan_penghasilan_neto" placeholder="0"></td>
            </tr>
            <tr>
                <td class="tdsatu">5.</td>
                <td class="tddua2">KEUNTUNGAN DARI PENJUALAN/PENGALIHAN HARTA</td>
                <td class="tddua2"><input type="text" oninput="format_bagianD()" name="keuntungan_penghasilan_neto" id="keuntungan_penghasilan_neto" placeholder="0"></td>
            </tr>
            <tr>
                <td class="tdsatu">6.</td>
                <td class="tddua2">PENGHASILAN LAINNYA</td>
                <td class="tddua2"><input class="text" oninput="format_bagianD()" name="penghasilanLain_penghasilan_neto" id="penghasilanLain_penghasilan_neto" placeholder="0"></td>
            </tr>
        </table>
        <table width="100%">
            <tr>
                <td class="tdsatu2">JUMLAH BAGIAN D</td>
                <td class="tddua3">JBD</td>
                <td class="tdtiga2"><input input type="text" class="form-control" readonly="readonly" style="background-color: #F0E68C; text-align:right" name="hasilnetolain" id="hasilnetolain"></td>
            </tr>
        </table>
        <button type="button">Simpan</button>
        <button type="button">Hapus</button>

        </form>
    </div>

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
    <!-- <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"> -->
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
    </script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/numeral.js/2.0.6/numeral.min.js"></script>

    <script>
        $(document).ready(function() {
            formatNpwp2();
        });


        let tr = 0;

        function addTableBagianC($this) {
            var template = document.querySelector('#rowTemplateBagianC'),
                tbl = document.querySelector('#BagianC'),
                td_choice = template.content.querySelectorAll("td"),
                tr_count = tbl.rows.length;

            td_choice.textContent = tr_count;
            var clone = document.importNode(template.content, true);
            tbl.appendChild(clone);
            formatPenghasilan();
        }

        function deleteTableBagianC(nama) {

            let tr_length = $('#' + nama + ' tr').length;

            if (tr_length > 2) {
                $('#' + nama + ' tr:last').remove();
            }
            formatPenghasilan();
        }
    </script>
    <script>
        // Format Bagian B
        function format() {
            valueDagangPeredaranUsaha = numeral(dagang_peredaran_usaha.value);
            document.getElementById('dagang_peredaran_usaha').value = valueDagangPeredaranUsaha.format();

            valueDagangPenghasilanNeto = numeral(dagang_penghasilan_neto.value);
            document.getElementById('dagang_penghasilan_neto').value = valueDagangPenghasilanNeto.format();

            valueIndustriPeredaranUsaha = numeral(industri_peredaran_usaha.value);
            document.getElementById('industri_peredaran_usaha').value = valueIndustriPeredaranUsaha.format();

            valueIndustriPenghasilanNeto = numeral(industri_penghasilan_neto.value);
            document.getElementById('industri_penghasilan_neto').value = valueIndustriPenghasilanNeto.format();

            valueJasaPeredaranUsaha = numeral(jasa_peredaran_usaha.value);
            document.getElementById('jasa_peredaran_usaha').value = valueJasaPeredaranUsaha.format();

            valueJasaPenghasilanNeto = numeral(jasa_penghasilan_neto.value);
            document.getElementById('jasa_penghasilan_neto').value = valueJasaPenghasilanNeto.format();

            valuePBebasPeredaranUsaha = numeral(pbebas_peredaran_usaha.value);
            document.getElementById('pbebas_peredaran_usaha').value = valuePBebasPeredaranUsaha.format();

            valuePBebasPenghasilanNeto = numeral(pbebas_penghasilan_neto.value);
            document.getElementById('pbebas_penghasilan_neto').value = valuePBebasPenghasilanNeto.format();

            valueUsahaPeredaranUsaha = numeral(usaha_peredaran_usaha.value);
            document.getElementById('usaha_peredaran_usaha').value = valueUsahaPeredaranUsaha.format();

            valueUsahaPenghasilanNeto = numeral(usaha_penghasilan_neto.value);
            document.getElementById('usaha_penghasilan_neto').value = valueUsahaPenghasilanNeto.format();

            var resultusaha = ((valueDagangPeredaranUsaha.value()) + (valueIndustriPeredaranUsaha.value()) +
                (valueJasaPeredaranUsaha.value()) + (valuePBebasPeredaranUsaha.value()) + (valueUsahaPeredaranUsaha.value()));
            if (!isNaN(resultusaha)) {
                document.getElementById('hasilusaha').value = numeral(resultusaha).format();
            }

            var resultneto = ((valueDagangPenghasilanNeto.value()) + (valueIndustriPenghasilanNeto.value()) +
                (valueJasaPenghasilanNeto.value()) + (valuePBebasPenghasilanNeto.value()) + (valueUsahaPenghasilanNeto.value()));
            if (!isNaN(resultneto)) {
                document.getElementById('hasilneto').value = numeral(resultneto).format();
            }
        }

        // Save Bagian B
        function BagianBSave() {
            dagang_peredaran_usaha = document.querySelector('#dagang_peredaran_usaha').value
            industri_peredaran_usaha = document.querySelector('#industri_peredaran_usaha').value
            jasa_peredaran_usaha = document.querySelector('#jasa_peredaran_usaha').value
            pbebas_peredaran_usaha = document.querySelector('#pbebas_peredaran_usaha').value
            usaha_peredaran_usaha = document.querySelector('#usaha_peredaran_usaha').value
            norma_dagang = document.querySelector('#norma_dagang').value
            norma_industri = document.querySelector('#norma_industri').value
            norma_jasa = document.querySelector('#norma_jasa').value
            norma_pbebas = document.querySelector('#norma_pbebas').value
            norma_usaha = document.querySelector('#norma_usaha').value
            dagang_penghasilan_neto = document.querySelector('#dagang_penghasilan_neto').value
            industri_penghasilan_neto = document.querySelector('#industri_penghasilan_neto').value
            jasa_penghasilan_neto = document.querySelector('#jasa_penghasilan_neto').value
            pbebas_penghasilan_neto = document.querySelector('#pbebas_penghasilan_neto').value
            usaha_penghasilan_neto = document.querySelector('#usaha_penghasilan_neto').value

            var data = {
                PeredaranUsaha: [dagang_peredaran_usaha, industri_peredaran_usaha, jasa_peredaran_usaha, pbebas_peredaran_usaha, usaha_peredaran_usaha],
                Norma: [norma_dagang, norma_industri, norma_jasa, norma_pbebas, norma_usaha],
                PenghasilanNeto: [dagang_penghasilan_neto, industri_penghasilan_neto, jasa_penghasilan_neto, pbebas_penghasilan_neto, usaha_penghasilan_neto]
            }
            console.log(data);
            
            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                type: "POST",
                url: 'http://localhost:8000/FormulirI2B_Point/Store',
                data: data,
                success: function(res) {
                    console.log(res)
                }
            });
        }

        // Delete Bagian B
         function BagianBDelete(nama) {
                $.ajax({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    type: "POST",
                    url: 'http://localhost:8000/FormulirI2B_Point/delete',
                    success: function(res) {
                        location.reload()
                    }
                });

            }

        // Format Bagian C
        let sum = 0;
        let tmp = 0;

        function format_bagianC() {
            valuePenghasilanBruto = numeral(penghasilan_bruto.value);
            document.getElementById('penghasilan_bruto').value = valuePenghasilanBruto.format();
            valuePenguranganBruto = numeral(pengurangan_bruto.value);
            document.getElementById('pengurangan_bruto').value = valuePenguranganBruto.format();

            $('.penghasilan_neto').each(function() {
                console.log(this.value)
                if (this.value.length > 0 && this.value != 0) {
                    tmp2 = getNumPrice(this.value, '.');
                    this.value = numeral(this.value).format();
                    tmp += parseFloat(tmp2)
                } else {
                    tmp += 0
                }
            });
            sum = tmp
            $('#jumlah_bagianC').val(numeral(sum).format());
            tmp = 0;
        }

        function getNumPrice(price, decimalpoint) {
            var p = price.split(decimalpoint);
            for (var i = 0; i < p.length; i++) p[i] = p[i].replace(/\D/g, '');
            return p.join('.');
        }



        function addTableBagianC($this) {
            var template = document.querySelector('#rowTemplateBagianC'),
                tbl = document.querySelector('#BagianC'),
                td_choice = template.content.querySelectorAll("td"),
                tr_count = tbl.rows.length;

            td_choice.textContent = tr_count;
            var clone = document.importNode(template.content, true);
            tbl.appendChild(clone);
        }

        function deleteTableBagianC(nama) {
            let tr_length = $('#' + nama + ' tr').length;

            if (tr_length > 2) {
                $('#' + nama + ' tr:last').remove();
            }
            format_bagianC();
        }

        // Format Bagian D
        function format_bagianD() {
            valueBungaPenghasilanNeto = numeral(bunga_penghasilan_neto.value);
            document.getElementById('bunga_penghasilan_neto').value = valueBungaPenghasilanNeto.format();
            valueRoyaltiPenghasilanNeto = numeral(royalti_penghasilan_neto.value);
            document.getElementById('royalti_penghasilan_neto').value = valueRoyaltiPenghasilanNeto.format();
            valueSewaPenghasilanNeto = numeral(sewa_penghasilan_neto.value);
            document.getElementById('sewa_penghasilan_neto').value = valueSewaPenghasilanNeto.format();
            valuePenghargaanPenghasilanNeto = numeral(penghargaan_penghasilan_neto.value);
            document.getElementById('penghargaan_penghasilan_neto').value = valuePenghargaanPenghasilanNeto.format();
            valueKeuntunganPenghasilanNeto = numeral(keuntungan_penghasilan_neto.value);
            document.getElementById('keuntungan_penghasilan_neto').value = valueKeuntunganPenghasilanNeto.format();
            valuePenghasilanLainPenghasilanNeto = numeral(penghasilanLain_penghasilan_neto.value);
            document.getElementById('penghasilanLain_penghasilan_neto').value = valuePenghasilanLainPenghasilanNeto.format();

            var resultnetoLain = ((valueBungaPenghasilanNeto.value()) + (valueRoyaltiPenghasilanNeto.value()) +
                (valueSewaPenghasilanNeto.value()) + (valuePenghargaanPenghasilanNeto.value()) + (valueKeuntunganPenghasilanNeto.value()) + (valuePenghasilanLainPenghasilanNeto.value()));
            if (!isNaN(resultnetoLain)) {
                document.getElementById('hasilnetolain').value = numeral(resultnetoLain).format();
            }
        }

        function format2() {
            valueDagangPeredaranUsaha = numeral(dagang_peredaran_usaha.value);
            dagang_peredaran_usaha = document.getElementById('dagang_peredaran_usaha');
            dagang_peredaran_usaha.value = valueDagangPeredaranUsaha.format();
            if (numeral(document.getElementById('dagang_penghasilan_neto').value)._value < numeral(dagang_peredaran_usaha.value)._value) {
                format()
            } else {
                document.getElementById('dagang_penghasilan_neto').value = 0;
                alert('Nilai Penghasilan Tidak Boleh Lebih Besar Dari Peredaran Usaha');
            }
        }

        function format3() {
            valueIndustriPeredaranUsaha = numeral(industri_peredaran_usaha.value);
            industri_peredaran_usaha = document.getElementById('industri_peredaran_usaha');
            industri_peredaran_usaha.value = valueIndustriPeredaranUsaha.format();
            if (numeral(document.getElementById('industri_penghasilan_neto').value)._value < numeral(industri_peredaran_usaha.value)._value) {
                format()
            } else {
                document.getElementById('industri_penghasilan_neto').value = 0;
                alert('Nilai Penghasilan Tidak Boleh Lebih Besar Dari Peredaran Usaha');
            }
        }

        function format4() {
            valueJasaPeredaranUsaha = numeral(jasa_peredaran_usaha.value);
            jasa_peredaran_usaha = document.getElementById('jasa_peredaran_usaha');
            jasa_peredaran_usaha.value = valueJasaPeredaranUsaha.format();
            if (numeral(document.getElementById('jasa_penghasilan_neto').value)._value < numeral(jasa_peredaran_usaha.value)._value) {
                format()
            } else {
                document.getElementById('jasa_penghasilan_neto').value = 0;
                alert('Nilai Penghasilan Tidak Boleh Lebih Besar Dari Peredaran Usaha');
            }
        }

        function format5() {
            valuePBebasPeredaranUsaha = numeral(pbebas_peredaran_usaha.value);
            pbebas_peredaran_usaha = document.getElementById('pbebas_peredaran_usaha');
            pbebas_peredaran_usaha.value = valuePBebasPeredaranUsaha.format();
            if (numeral(document.getElementById('pbebas_penghasilan_neto').value)._value < numeral(pbebas_peredaran_usaha.value)._value) {
                format()
            } else {
                document.getElementById('pbebas_penghasilan_neto').value = 0;
                alert('Nilai Penghasilan Tidak Boleh Lebih Besar Dari Peredaran Usaha');
            }
        }

        function format6() {
            valueUsahaPeredaranUsaha = numeral(usaha_peredaran_usaha.value);
            usaha_peredaran_usaha = document.getElementById('usaha_peredaran_usaha');
            usaha_peredaran_usaha.value = valueUsahaPeredaranUsaha.format();
            if (numeral(document.getElementById('usaha_penghasilan_neto').value)._value < numeral(usaha_peredaran_usaha.value)._value) {
                format()
            } else {
                document.getElementById('usaha_penghasilan_neto').value = 0;
                alert('Nilai Penghasilan Tidak Boleh Lebih Besar Dari Peredaran Usaha');
            }
        }

        // function format_bagian_c() {
        //     valuePenghasilanBruto = numeral(penghasilan_bruto.value);
        //     document.getElementById('penghasilan_bruto').value = valuePenghasilanBruto.format();
        //     valuePenguranganBruto = numeral(pengurangan_bruto.value);
        //     document.getElementById('pengurangan_bruto').value = valuePenguranganBruto.format();

        //     var result = ((valuePenghasilanBruto.value()) - (valuePenguranganBruto.value()));
        //     if (!isNaN(result)) {
        //         document.getElementById('penghasilanneto_C').value = numeral(result).format();
        //     }

        //     var result = ((valuePenghasilanBruto.value()) - (valuePenguranganBruto.value()));
        //     if (!isNaN(result)) {
        //         document.getElementById('penghasilanneto_total').value = numeral(result).format();
        //     }

        // }


        // let sumpenghasilanbruto = 0;
        // let tmppenghasilanbruto = 0;
        // let sumpenguranganbruto = 0;
        // let tmppenguranganbruto = 0;
        // let sumtotalbruto = 0;
        // let tmptotalbruto = 0;


        // function formatPenghasilan() {
        //     $('.penghasilan_bruto').each(function() {
        //         console.log(this.value)
        //         if (this.value.length > 0 && this.value != 0) {
        //             tmp2penghasilanbruto = getNumPrice(this.value, '.');
        //             this.value = numeral(this.value).format();
        //             tmppenghasilanbruto += parseFloat(tmp2penghasilanbruto)
        //         } else {
        //             tmppenghasilanbruto += 0
        //         }
        //     });
        //     sumpenghasilanbruto = tmppenghasilanbruto
        //     formatbruto()
        //     formattotalbruto();
        //     tmppenghasilanbruto = 0;

        // }

        // function formatPengurangan() {
        //     $('.pengurangan_bruto').each(function() {
        //         console.log(this.value)
        //         if (this.value.length > 0 && this.value != 0) {
        //             tmp2penguranganbruto = getNumPrice(this.value, '.');
        //             this.value = numeral(this.value).format();
        //             tmppenguranganbruto += parseFloat(tmp2penguranganbruto)
        //         } else {
        //             tmppenguranganbruto += 0
        //         }
        //     });
        //     sumpenguranganbruto = tmppenguranganbruto
        //     formatbruto()
        //     formattotalbruto();

        //     tmppenguranganbruto = 0;
        // }

        // function formatbruto() {
        //     var hasil = (sumpenghasilanbruto - sumpenguranganbruto);
        //     $('#penghasilanneto_C').val(numeral(hasil).format());

        //     // sumpenghasilanbruto=0;
        //     // sumpenguranganbruto=0;

        // }

        // function formattotalbruto() {
        //     console.log(2)
        //     $('.penghasilanneto_C').each(function() {
        //         console.log(this.value, 'a');
        //         if (this.value.length > 0 && this.value != 0) {
        //             tmp2totalbruto = getNumPrice(this.value, '.');
        //             this.value = numeral(this.value).format();
        //             tmptotalbruto += parseFloat(tmp2totalbruto)
        //         } else {
        //             tmptotalbruto += 0
        //         }
        //     });
        //     sumtotalbruto = tmptotalbruto
        //     $('#penghasilanneto_D').val(numeral(sumtotalbruto).format());
        //     tmptotalbruto = 0;

        // }

        function getNumPrice(price, decimalpoint) {
            var p = price.split(decimalpoint);
            for (var i = 0; i < p.length; i++) p[i] = p[i].replace(/\D/g, '');
            return p.join('.');
        }

        function formatNpwp2() {
            formatnpwp = document.getElementById('formatnpwpfix').value
            formatnpwp2 = document.getElementById('formatnpwpfix')
            if (typeof formatnpwp === 'string') {

            }
            formatnpwp2.value = formatnpwp.replace(/(\d{2})(\d{3})(\d{3})(\d{1})(\d{3})(\d{3})/, '$1.$2.$3.$4-$5.$6');
        }
    </script>
</body>

</html><?php /**PATH C:\xampp\htdocs\E-Form\resources\views/formulir-I hal 2.blade.php ENDPATH**/ ?>