<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Formulir 1770</title>
    <style>
        .bg-grey {
            font-family: arial;
            background-color: #ccc;
            padding: 1% 10% 1% 10%;
        }

        .container {
            width: 90%;
            background-color: #fff;
        }

        .item1 .row .col-2 {
            padding: 50px 0px -10px 10px
        }

        h1 {
            font-size: 20px;
            font-weight: bold;
            text-align: center;
            margin-top: 30px;
        }

        p {
            font-size: 10px;
            font-weight: bold;
            text-align: center;
            margin-top: 30px;
        }

        .item1 .row .col-6 {
            border-left: 2px solid black;
            border-right: 2px solid black;
        }

        .item1 .row .col-6 .row {
            font-size: 18px;
            font-weight: bold;
            padding: 10px 10px 10px 40px;
            border-bottom: 2px solid black;
        }

        .judul {
            font-size: 12px;
            font-weight: bold;
        }

        .vericaltext {
            writing-mode: vertical-lr;
            text-orientation: use-glyph-orientation;
        }

        .item1 .row .col-4 {
            padding: 5px 10px 5px 10px;
        }

        a {
            font-size: 12px;
            width: auto;
            height: auto;
            margin-left: 30px;
        }

        .year {
            border: 1px solid black;
            width: 20px;
            font-size: 25px;
        }

        table tr th {
            border: 1px solid black;
            font-size: 25px;
            text-align: center;
            width: 60px;

        }

        .form-check {
            display: inline-block;
            margin: 0px 10px 0px 0px;

        }

        .form-check-label {
            font-size: 14px;
            margin: 0px 20px 0px 0px;
        }

        .item1 .row .col-4 .col-sm-12 {
            background-color: #F0E68C;
            padding: 4px 10px 10px 10px;
            height: 30px
        }

        .item1 .row .col-4 .col-sm-12 label {
            font-size: 12px;
            text-align: center
        }

        b {
            font-size: 10px;
            margin-left: 10px;
        }

        .item2 .row label {
            font-size: 12px;
        }

        .item2 .row .form-control {
            border: 1px solid black;
            height: 30px;
            border-radius: 1px;
        }
        
        .item3 label{
            font-weight: bold; text-align:center
        }
    </style>
</head>

<body class="bg-grey">
    <div class="container">
        <div class="item1">
            <div class="row" style="border-bottom: 2px solid black;">
                <div class="col-2">
                    <h1>FORMULIR</h1>
                    <h1>1770</h1>
                    <p>KEMENTERIAN KEUANGAN
                        RI DIREKTORAT JENDERAL PAJAK
                    </p>
                </div>
                <div class="col-6">
                    <div class="row">
                        SPT TAHUNAN PPh WAJIB PAJAK ORANG PRIBADI
                    </div>
                    <div class="judul">
                        </br>BAGI WAJIB PAJAK YANG MEMPUNYAI PENGHASILAN :</br>
                        </br>*DARI USAHA/PEKERJAAN BEBAS</br>
                        *DARI SATU ATAU LEBIH PEMBERI KERJA</br>
                        *YANG DIKENAKAN PPh FINAL DAN/ATAU BERSIFAT FINAL; DAN/ATAU;</br>
                        *DALAM NEGERI LAINNYA ATAU LUAR NEGERI</br>
                    </div>
                </div>
                <div class="col-4">
                    <a href="/formulir-I hal 2" class="btn btn-secondary">SEBELUMNYA</a>
                    <a href=# class="btn btn-secondary">SUBMIT</a>
                    <div class="row" style="padding: 4% 10%;">
                        <div class="col">
                            <table>
                                <tr>
                                    <th>y</th>
                                    <th>y</th>
                                    <th>y</th>
                                    <th>y</th>
                                </tr>
                            </table>
                        </div>
                    </div>
                    <div class="row" style="padding: 1% 10%;">
                        <div class="col-4">
                            <table>
                                <tr>
                                    <th>m</th>
                                    <th>m</th>
                                    <th>y</th>
                                    <th>y</th>
                                </tr>
                            </table>
                        </div>
                        <div class="col-2">
                            <p style="margin: 15px;">sd</p>
                        </div>
                        <div class="col-4">
                            <table>
                                <tr>
                                    <th>m</th>
                                    <th>m</th>
                                    <th>y</th>
                                    <th>y</th>
                                </tr>
                            </table>
                        </div>
                    </div>

                    <div class="form-check" style="display:inline-block">
                        <input style="display:inline;" class="form-check-input" type="radio" name="flexRadioDisabled" id="flexRadioDisabled">
                        <label class="form-check-label" for="flexRadioDisabled" style="font-size: 14px;">
                            Pembukuan
                        </label>
                    </div>
                    <div class="form-check" style="display:inline-block">
                        <input class="form-check-input" type="radio" name="flexRadioDisabled" id="flexRadioCheckedDisabled">
                        <label class="form-check-label" for="flexRadioCheckedDisabled" style="font-size: 14px;">
                            Pencatatan
                        </label>
                    </div>
                    <div class="col-sm-12">
                        <div class="input-group mb-6">
                            <div class="input-group-prepend">
                                <div style="margin-left: -11px">
                                    <input type="checkbox" aria-label="Checkbox for following text input" style="width: 20px;">
                                </div>
                            </div>
                            <label class="col-sm-9">SPT Pembetulan Ke</label>
                            <input style="width:20px; height: 20px; border: 1px solid;">
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <b>PERHATIAN *SEBELUM MENGISI BACALAH PETUNJUK PENGISIAN *ISI DENGAN HURU CETAK/DIKETIK
            DENGAN TINTA HITAM *BERI TANDA X DALAM KOTAK SESUAI PILIHAN</b>
        <div class="item2">
            <div class="col-sm-11.5" style="padding: 4px 20px 10px 10px ; height: auto; border: 4px solid; margin-left: 10px">
                <div class="row">
                    <label class="col-sm-4 col-form-label">NPWP</label>
                    <div class="col-sm-8">
                        <input class="form-control" type="text" placeholder="Masukkan NPWP">
                    </div>
                </div>
                <div class="row">
                    <label class="col-sm-4 col-form-label">NAMA WAJIB PAJAK</label>
                    <div class="col-sm-8">
                        <input class="form-control" type="text" placeholder="Masukkan Nama">
                    </div>
                </div>
                <div class="row">
                    <label class="col-sm-4 col-form-label">JENIS USAHA/PEKERJAAN BEBAS</label>
                    <div class="col-sm-6">
                        <input class="form-control" type="text" placeholder="Masukkan Jenis Usaha/Pekerjaan Bebas">
                    </div>
                    <label class="col-sm-1 col-form-label">KLU</label>
                    <div class="col-sm-1">
                        <input class="form-control" type="text" placeholder="KLU">
                    </div>
                </div>
                <div class="row">
                    <label class="col-sm-4 col-form-label">NO.TELEPON/FAKSIMILI</label>
                    <div class="col-sm-5">
                        <input class="form-control" type="text" placeholder="Masukkan No.Telepon/Faksimili">
                    </div>

                    <label class="col-sm-1 col-form-label">FAX</label>
                    <div class="col-sm-2">
                        <input class="form-control" type="text" placeholder="Masukkan Fax">
                    </div>
                </div>
                <div class="row">
                    <label class="col-sm-4 col-form-label">STATUS KEWAJIBAN PERPAJAKAN SUAMI-ISTERI</label>
                    <div class="col-sm-4" style="border: 1px solid black; height: 30px; background-color:#fff; margin-left:12px">
                        <div class="form-check" style="display:inline-block">
                            <input style="display:inline;" class="form-check-input" type="radio" name="flexRadioDisabled" id="flexRadioDisabled">
                            <label class="form-check-label" for="flexRadioDisabled" style="font-size: 14px;">
                                KK
                            </label>
                        </div>
                        <div class="form-check" style="display:inline-block">
                            <input class="form-check-input" type="radio" name="flexRadioDisabled" id="flexRadioCheckedDisabled">
                            <label class="form-check-label" for="flexRadioCheckedDisabled" style="font-size: 14px;">
                                HB
                            </label>
                        </div>
                        <div class="form-check" style="display:inline-block">
                            <input class="form-check-input" type="radio" name="flexRadioDisabled" id="flexRadioCheckedDisabled">
                            <label class="form-check-label" for="flexRadioCheckedDisabled" style="font-size: 14px;">
                                PH
                            </label>
                        </div>
                        <div class="form-check" style="display:inline-block">
                            <input class="form-check-input" type="radio" name="flexRadioDisabled" id="flexRadioCheckedDisabled">
                            <label class="form-check-label" for="flexRadioCheckedDisabled" style="font-size: 14px;">
                                MT
                            </label>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <label class="col-sm-4 col-form-label">NPWP SUAMI/ISTERI</label>
                    <div class="col-sm-8">
                        <input class="form-control" type="text" disabled="disabled">
                    </div>
                </div>
                <div class="item3">
                <label>Permohonan perubahan data dapat disampaikan terpisah dari pelaporan SPT Tahunan Orang Pribadi ini, dengan menggunakan
                    Formulir Perubahan Data Wajib Pajak dan dilengkapi dokumen yang diisyaratkan
                </label>
                </div>
            </div>
        </div>


        <div class="row" style="margin: 10px 1px 10px 10px;">
            <div class="col-9" style="border: 1px solid black; font-size: 12px">*)Pengisian kolom-kolom yang berisi nilai rupiah harus tanpa nilai desimal (contoh penulisan lihat petunjuk pengisian halaman 3)</div>
            <div class="col-3" style="border: 1px solid black; font-size: 12px; text-align: center"> Rupiah</div>
        </div>
        <div class="row" style="margin: 10px 1px 10px 10px; margin-top: -10px">
            <div class="col-1" style="border: 1px solid black; font-size: 12px; text-align: center;">A. PENGHASILAN NETO</div>
            <!-- <div class="col-8" style="border: 1px solid black; font-size: 12px">
                1. PENGHASILAN NETO DALAM NEGERI DARI USAHA DAN/ATAU PEKERJAAN BEBAS</br>
                <u>[Diisi dari Formulir 1770-I Halaman 1 Jumlah Bagian A atau Formulir 1770-I Halaman 2 Jumlah Bagaian B Kolom 5]</u>
            </div>
            <div class="col-3" style="border: 1px solid black; font-size: 12px">
                <div class="col-sm-12" style="border: 1px solid white;">
                    <input type="text" style="border: 1px solid black; width: 100%; height: 32px">
                </div>
            </div>
            <div class="col-1" style="border: 1px solid black; font-size: 12px; text-align: center;">A. PENGHASILAN</div>
            <div class="col-8" style="border: 1px solid black; font-size: 12px">
                1. PENGHASILAN NETO DALAM NEGERI DARI USAHA DAN/ATAU PEKERJAAN BEBAS</br>
                <u>[Diisi dari Formulir 1770-I Halaman 1 Jumlah Bagian A atau Formulir 1770-I Halaman 2 Jumlah Bagaian B Kolom 5]</u>
            </div>
            <div class="col-3" style="border: 1px solid black; font-size: 12px">
                <div class="col-sm-12" style="border: 1px solid white;">
                    <input type="text" style="border: 1px solid black; width: 100%; height: 32px">
                </div>
            </div> -->
            <div class="col-8" style="border: 1px solid black; font-size: 12px">1. PENGHASILAN NETO DALAM NEGERI DARI USAHA DAN/ATAU PEKERJAAN BEBAS</br>
                <u>[Diisi dari Formulir 1770-I Halaman 1 Jumlah Bagian A atau Formulir 1770-I Halaman 2 Jumlah Bagaian B Kolom 5]</u>
                </br>2. PENGHASILAN NETO DALAM NEGERI SEHUBUNGAN DENGAN PEKERJAAN</br>
                <u>[Diisi dri Formulir 1770-I Halaman 2 Jumlah Bagian C Kolom 5]</u>
                </br>3. PENGHASILAN NETO DALAM NEGERI LAINNYA</br>
                <u>[Diisi dri Formulir 1770-I Halaman 2 Jumlah Bagian D Kolom 3]</u>
                </br>4. PENGHASILAN NETO LUAR NEGERI</br>
                <u>[Apabila memiliki penghasilan dari luar negeri agar diisi dari Lampiran Tersendiri, lihat petunjuk pengisian]</u>
                </br>5. JUMLAH PENGHASILAN NETO (1+2+3+4)</br>
                </br>6. ZAKAT / SUMBANGAN KEAGAMAAN YANG BERSIFAT WAJIB</br>
                </br>7. JUMLAH PENGHASILAN NETO SETELAH PENGURANGAN ZAKAT / SUMBANGAN
                KEAGAMAAN YANG SIFATNYA WAJIB (5-6)

            </div>
            <div class="col-3" style="border: 1px solid black; font-size: 12px">
                <div class="col-sm-12" style="border: 1px solid white;">
                    <input type="text" style="border: 1px solid black; width: 100%; height: 32px; background-color: #F0E68C">
                </div>
                <div class="col-sm-12" style="border: 1px solid white;">
                    <input type="text" style="border: 1px solid black; width: 100%; height: 32px; background-color: #F0E68C">
                </div>
                <div class="col-sm-12" style="border: 1px solid white;">
                    <input type="text" style="border: 1px solid black; width: 100%; height: 32px; background-color: #F0E68C">
                </div>
                <div class="col-sm-12" style="border: 1px solid white;">
                    <input type="text" style="border: 1px solid black; width: 100%; height: 32px">
                </div>
                <div class="col-sm-12" style="border: 1px solid white;">
                    <input type="text" style="border: 1px solid black; width: 100%; height: 32px; background-color: #F0E68C">
                </div>
                <div class="col-sm-12" style="border: 1px solid white;">
                    <input type="text" style="border: 1px solid black; width: 100%; height: 32px">
                </div>
                <div class="col-sm-12" style="border: 1px solid white;">
                    <input type="text" style="border: 1px solid black; width: 100%; height: 32px; background-color: #F0E68C">
                </div>
            </div>

        </div>

        <div class="row" style="margin: 10px 1px 10px 10px; margin-top: -10px">
            <div class="col-1" style="border: 1px solid black; font-size: 12px; text-align: center;">B. PENGHASILAN KENA PAJAK</div>
            <div class="col-8" style="border: 1px solid black; font-size: 12px">
                8. KOMPENSASI KERUGIAN</br>
                </br>9. JUMLAH PENGHASILAN NETO SETELAH KOMPENSASI KERUGIAN (7-8)</br>
                </br> 10. PENGHASILAN TIDAK KENA PAJAK
                <div class="form-check" style="display:inline-block">
                    <input style="display:inline;" class="form-check-input" type="radio" name="flexRadioDisabled" id="flexRadioDisabled">
                    <label class="form-check-label" for="flexRadioDisabled" style="font-size: 14px;">
                        TK
                    </label>
                </div>
                <div class="form-check" style="display:inline-block">
                    <input class="form-check-input" type="radio" name="flexRadioDisabled" id="flexRadioCheckedDisabled">
                    <label class="form-check-label" for="flexRadioCheckedDisabled" style="font-size: 14px;">
                        K
                    </label>
                </div>
                <div class="form-check" style="display:inline-block">
                    <input class="form-check-input" type="radio" name="flexRadioDisabled" id="flexRadioCheckedDisabled">
                    <label class="form-check-label" for="flexRadioCheckedDisabled" style="font-size: 14px;">
                        K/I
                    </label>
                </div>
                </br> 11. PENGHASILAN KENA PAJAK (9-10)
                <select class="col-sm-1" style="height: 20px; border: 1px solid black">
                    <option>0</option>
                    <option>1</option>
                    <option>2</option>
                    <option>3</option>
                </select>
            </div>
            <div class="col-3" style="border: 1px solid black; font-size: 12px">
                <div class="col-sm-12" style="border: 1px solid white;">
                    <input type="text" style="border: 1px solid black; width: 100%; height: 32px">
                </div>
                <div class="col-sm-12" style="border: 1px solid white;">
                    <input type="text" style="border: 1px solid black; width: 100%; height: 32px; background-color: #F0E68C">
                </div>
                <div class="col-sm-12" style="border: 1px solid white;">
                    <input type="text" style="border: 1px solid black; width: 100%; height: 32px; background-color: #F0E68C">
                </div>
                <div class="col-sm-12" style="border: 1px solid white;">
                    <input type="text" style="border: 1px solid black; width: 100%; height: 32px; background-color: #F0E68C">
                </div>

            </div>

        </div>
        <div class="row" style="margin: 10px 1px 10px 10px; margin-top: -10px">
            <div class="col-1" style="border: 1px solid black; font-size: 12px; text-align: center;">C. PPh TERUTANG</div>
            <div class="col-8" style="border: 1px solid black; font-size: 12px">
                12. PPh TERUTANG (TARIF PASAL 17 UU PPh X ANGKA 11)</br>
                </br>13. PENGEMBALIAN/PENGURANGAN PPh PASAL 24 YANG TELAH DIKREDITKAN</br>
                </br> 14. JUMLAH PPh TERUTANG (12 + 13)</br>
            </div>
            <div class="col-3" style="border: 1px solid black; font-size: 12px">
                <div class="col-sm-12" style="border: 1px solid white;">
                    <input type="text" style="border: 1px solid black; width: 100%; height: 32px; background-color: #F0E68C">
                </div>
                <div class="col-sm-12" style="border: 1px solid white;">
                    <input type="text" style="border: 1px solid black; width: 100%; height: 32px">
                </div>
                <div class="col-sm-12" style="border: 1px solid white;">
                    <input type="text" style="border: 1px solid black; width: 100%; height: 32px; background-color: #F0E68C">
                </div>


            </div>

        </div>



        <!-- <table style="margin-top: 20px; width: 100%; margin-left: 5px">
            <tr>
                <td style="border: 1px solid black; font-size: 11px">*)Pengisian kolom-kolom yang berisi nilai rupiah harus tanpa nilai desimal (contoh penulisan lihat petunjuk pengisian halaman 3)</td>
                <td style="border: 1px solid black; width: 30%; font-size: 12px; text-align: center">Rupiah</td>
            </tr>
        </table>
        <table style="width: 100%; margin-left: 5px">
            <tr>
            <td style="border: 1px solid black; text-align:center; font-size: 11px">A.PENGHASILAN</br>NETO</td>    
            <td style="border: 1px solid black; font-size: 11px">1. PENGHASILAN NETO DALAM NEGERI DARI USAHA DAN/ATAU PEKERJAAN BEBAS</td>
                <td style="border: 1px solid black; width: 30%; font-size: 12px; text-align: center">1 <input type="text" style="border: 1px solid black; width: 90%"></td>
            </tr>
        </table> -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
        </script>
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous">
        </script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
        </script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
        </script>
  </body>
</html><?php /**PATH C:\xampp\htdocs\E-Form\resources\views/coba.blade.php ENDPATH**/ ?>