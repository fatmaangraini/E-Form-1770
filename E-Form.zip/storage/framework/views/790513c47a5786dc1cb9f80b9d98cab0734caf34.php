<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js" integrity="sha512-aVKKRRi/Q/YV+4mjoKBsE4x3H+BkegoM/em46NNlCqNTmUYADjBbeNefNxYV7giUp0VxICtqdrbqU7iVaeZNXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <title>Formulir 1770-IV</title>
    <style>
        .bg-grey {
            font-family: arial;
            background-color: #ccc;
        }

        .vericaltext {
            writing-mode: vertical-lr;
            text-orientation: use-glyph-orientation;
        }

        .year {
            border: 1px solid black;
            width: 20px;
            font-size: 25px;
        }

        table tr th {
            border: 1px solid black;
            font-size: 25px;
        }
    </style>
</head>

<body class="bg-grey" style="padding: 1% 10% 1% 10%">
    <div class="container " style="width : 90%; background-color: #fff;">
        <div class="row" style="border-bottom: 2px solid black;">
            <div class="col-2" style="padding: 50px 0px 10px 10px">
                <h1 style="font-size: 20px; font-weight: bold; text-align: center; margin-top: -10px">FORMULIR</h1>
                <h1 style="font-size: 40px; font-weight: bold; text-align: center; margin-top: 30px">1770-IV</h1>
                <p style="font-size: 10px; font-weight: bold; text-align: center; margin-top: 30px">KEMENTERIAN KEUANGAN
                    RI DIREKTORAT JENDERAL PAJAK
                </p>
            </div>
            <div class="col-6" style="border-left: 2px solid black; border-right:2px solid black;">
                <div class="row">
                    <b style="font-size: 18px; text-align: center;">LAMPIRAN-IV </b>
                    <p style=" font-size: 18px; font-weight: bold;  text-align: center; border-bottom: 2px solid black">
                        SPT TAHUNAN PPh WAJIB PAJAK ORANG PRIBADI</p>
                </div>
                <div class="row">
                    <b style="font-size: 12px;">* HARTA PADA AKHIR TAHUN</b>
                    <b style="font-size: 12px;">* KEWAJIBAN/UTANG PADA AKHIR TAHUN</b>
                    <b style="font-size: 12px;">* DAFTAR SUSUNAN ANGGOTA KELUARGA</b>
                </div>
            </div>

            <div class="col-4" style="padding: 10px 10px 10px 10px">
                <!-- <b class="vericaltext fs-7">
                    TAHUN PAJAK
                </b> -->
                <a href="/formulir-III" class="btn btn-secondary" style="font-size: 12px; width: 120px; height: 30px; margin-left: 150px">Selanjutnya</a>
                <div class="row" style="padding: 4% 10%;">
                    <div class="col">
                        <table>
                            <tr>
                                <th style="text-align: center" width="60px"><?php echo e(mb_substr($spt['tahun'], 0, 1)); ?></th>
                                <th style="text-align: center" width="60px"><?php echo e(mb_substr($spt['tahun'], 1, 1)); ?></th>
                                <th style="text-align: center" width="60px"><?php echo e(mb_substr($spt['tahun'], 2, 1)); ?></th>
                                <th style="text-align: center" width="60px"><?php echo e(mb_substr($spt['tahun'], 3, 1)); ?></th>
                            </tr>
                        </table>
                    </div>
                </div>
                <div class="row" style="padding: 1% 20%;">
                    <div class="col-4">
                        <table>
                            <tr>
                                <th>0</th>
                                <th>1</th>
                                <th><?php echo e(mb_substr($spt['tahun'], 2, 1)); ?></th>
                                <th><?php echo e(mb_substr($spt['tahun'], 3, 1)); ?></th>

                            </tr>
                        </table>
                    </div>
                    <div class="col-3">
                        <p style="padding: 10px 10px ;">sd</p>
                    </div>
                    <div class="col-4">
                        <table>
                            <tr>
                                <th>1</th>
                                <th>2</th>
                                <th><?php echo e(mb_substr($spt['tahun'], 2, 1)); ?></th>
                                <th><?php echo e(mb_substr($spt['tahun'], 3, 1)); ?></th>
                            </tr>
                        </table>
                    </div>
                </div>

                <div class="form-check" style="display:inline-block; margin-left: 10px">
                    <input style="display:inline;" class="form-check-input" type="radio" name="flexRadioDisabled" id="flexRadioDisabled">
                    <label class="form-check-label" for="flexRadioDisabled" style="font-size: 14px;">
                        Pembukuan
                    </label>
                </div>
                <div class="form-check" style="display:inline-block; margin-left: 10px">
                    <input class="form-check-input" type="radio" name="flexRadioDisabled" id="flexRadioCheckedDisabled" checked>
                    <label class="form-check-label" for="flexRadioCheckedDisabled" style="font-size: 14px;">
                        Pencatatan
                    </label>
                </div>
                <div class="col-sm-12" style="background-color: #F0E68C ; padding: 4px 10px 10px 10px ; height: 30PX">
                    <div class="input-group mb-6">
                        <div class="input-group-prepend">
                            <div style="margin-left: -11px">
                                <input type="checkbox" aria-label="Checkbox for following text input" style="width: 20px;">
                            </div>
                        </div>
                        <label class="col-sm-9" style="font-size: 11px; text-align: center">SPT Pembetulan Ke</label>
                        <input style="width:20px; height: 20px; border: 1px solid;" value="<?php echo e($spt['pembetulan']); ?>">
                    </div>
                </div>
            </div>
        </div>
        <b style="font-size: 10px;">PERHATIAN *SEBELUM MENGISI BACALAH PETUNJUK PENGISIAN *ISI DENGAN HURU CETAK/DIKETIK
            DENGAN TINTA HITAM *BERI TANDA X DALAM KOTAK SESUAI PILIHAN</b>
        <div class="col-sm-11.5" style=" border: 1px solid black; background-color: #F0E68C ; padding: 4px 20px 10px 10px ; height: 80PX; border: 2px solid; margin-left: 10px">
            <div class="row">
                <label class="col-sm-4 col-form-label" style="font-size: 12px;">NPWP</label>
                <div class="col-sm-8">
                    <input class="form-control" type="text" style="border: 1px solid black; height: 30px; border-radius: 1px; " value="<?php echo e($npwp); ?>" disabled="disabled" id="formatnpwpfix">
                </div>
            </div>
            <div class="row">
                <label class="col-sm-4 col-form-label" style="font-size: 12px;">NAMA WAJIB PAJAK</label>
                <div class="col-sm-8">
                    <input class="form-control" type="text" style="border: 1px solid black; height: 30px; border-radius: 1px;" value="<?php echo e($nama); ?>" disabled="disabled">
                </div>
            </div>
        </div>
        <p style="font-size: 11px; margin-left:10px">BAGIAN A. HARTA PADA AKHIR TAHUN</p>
        <button type="button" data-bs-toggle="modal" data-bs-target="#exampleModal" data-bs-whatever="@mdo">Import Data</button>
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Import Data Harta</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="/DataHartaImport" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="input-group mb-3">
                                <input type="file" name="file" class="form-control" accept=".csv">
                                <button class="btn btn-primary" type="submit">Submit</button>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>

        <!-- BAGIAN A. HARTA -->
        <form action="/SaveDataHarta" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="counted" value="<?php echo e(count($data_harta)); ?>">
            <table id="A_TblHarta" class="display">
                <thead>
                    <tr>
                        <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width:25%; height: 30px">
                            KODE HARTA</th>
                        <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width:20%;">
                            NAMA HARTA</th>
                        <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width:20%;">
                            TAHUN PEROLEHAN</th>
                        <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width:20%;">
                            HARGA PEROLEHAN</th>
                        <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width:20%;">
                            KETERANGAN</th>
                    </tr>
                    <?php if(count($data_harta) == 0): ?>

                    <tr>
                        <td style="border: 1px solid black"><select name='harta[]' style="width:100%; height: 28px; border: 1px solid white">
                                <option value='pilih'>Pilih...</option>
                                <option value='011'>011 - Uang Tunai</option>
                                <option value='012'>012 - Tabungan</option>
                                <option value='013'>013 - Giro</option>
                                <option value='014'>014 - Deposito</option>
                                <option value='019'>019 - Setara Kas Lainnya</option>
                                <option value='021'>021 - Piutang</option>
                                <option value='022'>022 - Piutang Afiliasi (Piutang kepada pihak yang mempunyai hubungan
                                    istimewa sebagaimana dimaksud)</option>
                                <option value='029'>029 - Piutang Lainnya</option>
                                <option value='031'>031 - Saham Yang Dibeli Untuk Dijual Kembali</option>
                                <option value='032'>032 - Saham</option>
                                <option value='033'>033 - Obligasi Perusahaan</option>
                                <option value='034'>034 - Obligasi Pemerintah Indonesia (Obligasi Ritel Indonesia atau ORI,
                                    surat berharga syariah negara, dll)</option>
                                <option value='035'>035 - Surat Utang Lainnya</option>
                                <option value='036'>036 - Reksadana</option>
                                <option value='037'>037 - Instrumen Derivatif (Right, Warran, Kontrak Berjangka, Opsi, dll)
                                </option>
                                <option value='038'>038 - Penyertaan Modal Perusahaan Lain Yang Tidak Atas Saham Meliputi
                                    Penyertaan Modal Pada CV, Firma, dan Sejenisnya</option>
                                <option value='039'>039 - Investasi Lainnya</option>
                                <option value='041'>041 - Sepeda</option>
                                <option value='042'>042 - Sepeda Motor</option>
                                <option value='043'>043 - Mobil </option>
                                <option value='049'>049 - Alat Transportasi Lainnya</option>
                                <option value='051'>051 - Logam Mulia (Emas Batangan, Emas Perhiasan, Platina Batangan,
                                    Platina Perhiasan, Logam Mulia Lainnya)</option>
                                <option value='052'>052 - Batu Mulia (Intan, Berlian. Batu Mulia Lainnya)</option>
                                <option value='053'>053 - Barang Seni dan Antik (Barang-Barang Seni, Barang-Barang Antik)
                                </option>
                                <option value='054'>054 - Kapal Pesiar, Pesawat Terbang, Helikopter,Jetski dan Peralatan
                                    Olahraga Khusus</option>
                                <option value='055'>055 - Peralatan Elektronik dan Furnitur</option>
                                <option value='059'>059 - Harta Bergerak Lainnya</option>
                                <option value='061'>061 - Tanah dan/atau Bangunan Untuk Tempat Tinggal</option>
                                <option value='062'>062 - Tanah dan/atau Bangunan Untuk Usaha (Toko, Pabrik, Gudang, dan
                                    Sejenisnya)</option>
                                <option value='063'>063 - Tanah atau Lahan Untuk Usaha (Lahan Pertanian, Perkebunan,
                                    Perikanan Darat, dan Sejenisnya)</option>
                                <option value='069'>069 - Harta Tidak Bergerak Lainnya</option>
                            </select></td>
                        <td style="border: 1px solid black;"><input name='nama_harta[]' class="text"  style="width: 100%; border: 1px solid white;text-align: center;text-transform:uppercase">
                        </td>
                        <td style="border: 1px solid black;"><input name='tahun_perolehan[]' class="text" style="width: 100%; border: 1px solid white;text-align: center">
                        </td>
                        <td style="border: 1px solid black;"><input name='harta_perolehan[]' type="text" oninput="format(this.value)" class="harga_perolehan" style="width: 100%; border: 1px solid white;text-align: center">
                        </td>
                        <td style="border: 1px solid black;"><input name='keterangan[]' class="text" style="width: 100%; border: 1px solid white;text-align: center;text-transform:uppercase">
                        </td>
                    </tr>
                    <?php endif; ?>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data_harta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td style="border: 1px solid black"><select name='harta[]' style="width:100%; height: 28px; border: 1px solid white">
                                <option value='pilih'>Pilih...</option>
                                <option value='011' <?php if($dh['kode_harta']=="011" ): ?> selected="selected" <?php endif; ?>>011 - Uang Tunai</option>
                                <option value='012' <?php if($dh['kode_harta']=="012" ): ?> selected="selected" <?php endif; ?>>012 - Tabungan</option>
                                <option value='013' <?php if($dh['kode_harta']=="013" ): ?> selected="selected" <?php endif; ?>>013 - Giro</option>
                                <option value='014' <?php if($dh['kode_harta']=="014" ): ?> selected="selected" <?php endif; ?>>014 - Deposito</option>
                                <option value='019' <?php if($dh['kode_harta']=="019" ): ?> selected="selected" <?php endif; ?>>019 - Setara Kas Lainnya</option>
                                <option value='021' <?php if($dh['kode_harta']=="021" ): ?> selected="selected" <?php endif; ?>>021 - Piutang</option>
                                <option value='022' <?php if($dh['kode_harta']=="022" ): ?> selected="selected" <?php endif; ?>>022 - Piutang Afiliasi (Piutang kepada pihak yang mempunyai hubungan
                                    istimewa sebagaimana dimaksud)</option>
                                <option value='029' <?php if($dh['kode_harta']=="029" ): ?> selected="selected" <?php endif; ?>>029 - Piutang Lainnya</option>
                                <option value='031' <?php if($dh['kode_harta']=="031" ): ?> selected="selected" <?php endif; ?>>031 - Saham Yang Dibeli Untuk Dijual Kembali</option>
                                <option value='032' <?php if($dh['kode_harta']=="032" ): ?> selected="selected" <?php endif; ?>>032 - Saham</option>
                                <option value='033' <?php if($dh['kode_harta']=="033" ): ?> selected="selected" <?php endif; ?>>033 - Obligasi Perusahaan</option>
                                <option value='032' <?php if($dh['kode_harta']=="034" ): ?> selected="selected" <?php endif; ?>>034 - Obligasi Pemerintah Indonesia (Obligasi Ritel Indonesia atau ORI,
                                    surat berharga syariah negara, dll)</option>
                                <option value='035' <?php if($dh['kode_harta']=="035" ): ?> selected="selected" <?php endif; ?>>035 - Surat Utang Lainnya</option>
                                <option value='036' <?php if($dh['kode_harta']=="036" ): ?> selected="selected" <?php endif; ?>>036 - Reksadana</option>
                                <option value='037' <?php if($dh['kode_harta']=="037" ): ?> selected="selected" <?php endif; ?>>037 - Instrumen Derivatif (Right, Warran, Kontrak Berjangka, Opsi, dll)
                                </option>
                                <option value='038' <?php if($dh['kode_harta']=="038" ): ?> selected="selected" <?php endif; ?>>038 - Penyertaan Modal Perusahaan Lain Yang Tidak Atas Saham Meliputi
                                    Penyertaan Modal Pada CV, Firma, dan Sejenisnya</option>
                                <option value='039' <?php if($dh['kode_harta']=="039" ): ?> selected="selected" <?php endif; ?>>039 - Investasi Lainnya</option>
                                <option value='041' <?php if($dh['kode_harta']=="041" ): ?> selected="selected" <?php endif; ?>>041 - Sepeda</option>
                                <option value='042' <?php if($dh['kode_harta']=="042" ): ?> selected="selected" <?php endif; ?>>042 - Sepeda Motor</option>
                                <option value='043' <?php if($dh['kode_harta']=="043" ): ?> selected="selected" <?php endif; ?>>043 - Mobil </option>
                                <option value='049' <?php if($dh['kode_harta']=="049" ): ?> selected="selected" <?php endif; ?>>049 - Alat Transportasi Lainnya</option>
                                <option value='051' <?php if($dh['kode_harta']=="051" ): ?> selected="selected" <?php endif; ?>>051 - Logam Mulia (Emas Batangan, Emas Perhiasan, Platina Batangan,
                                    Platina Perhiasan, Logam Mulia Lainnya)</option>
                                <option value='052' <?php if($dh['kode_harta']=="052" ): ?> selected="selected" <?php endif; ?>>052 - Batu Mulia (Intan, Berlian. Batu Mulia Lainnya)</option>
                                <option value='053' <?php if($dh['kode_harta']=="053" ): ?> selected="selected" <?php endif; ?>>053 - Barang Seni dan Antik (Barang-Barang Seni, Barang-Barang Antik)
                                </option>
                                <option value='054' <?php if($dh['kode_harta']=="054" ): ?> selected="selected" <?php endif; ?>>054 - Kapal Pesiar, Pesawat Terbang, Helikopter,Jetski dan Peralatan
                                    Olahraga Khusus</option>
                                <option value='055' <?php if($dh['kode_harta']=="055" ): ?> selected="selected" <?php endif; ?>>055 - Peralatan Elektronik dan Furnitur</option>
                                <option value='059' <?php if($dh['kode_harta']=="059" ): ?> selected="selected" <?php endif; ?>>059 - Harta Bergerak Lainnya</option>
                                <option value='061' <?php if($dh['kode_harta']=="061" ): ?> selected="selected" <?php endif; ?>>061 - Tanah dan/atau Bangunan Untuk Tempat Tinggal</option>
                                <option value='062' <?php if($dh['kode_harta']=="062" ): ?> selected="selected" <?php endif; ?>>062 - Tanah dan/atau Bangunan Untuk Usaha (Toko, Pabrik, Gudang, dan
                                    Sejenisnya)</option>
                                <option value='063' <?php if($dh['kode_harta']=="063" ): ?> selected="selected" <?php endif; ?>>063 - Tanah atau Lahan Untuk Usaha (Lahan Pertanian, Perkebunan,
                                    Perikanan Darat, dan Sejenisnya)</option>
                                <option value='069' <?php if($dh['kode_harta']=="069" ): ?> selected="selected" <?php endif; ?>>069 - Harta Tidak Bergerak Lainnya</option>
                            </select></td>
                        <td style="border: 1px solid black;"><input name="nama_harta[]" class="text" value="<?php echo e($dh['nama_harta']); ?>" style="width: 100%; border: 1px solid white;text-align: center; text-transform:uppercase">
                        </td>
                        <td style="border: 1px solid black;"><input name="tahun_perolehan[]" class="text" value="<?php echo e($dh['tahun_perolehan']); ?>" style="width: 100%; border: 1px solid white;text-align: center">
                        </td>
                        <td style="border: 1px solid black;"><input name="harta_perolehan[]" type="text" oninput="format(this.value)" value="<?php echo e($dh['harta_perolehan']); ?>" class="harga_perolehan" style="width: 100%; border: 1px solid white;text-align: center">
                        </td>
                        <td style="border: 1px solid black;"><input name="keterangan[]" class="text" value="<?php echo e($dh['keterangan']); ?>" style="width: 100%; border: 1px solid white;text-align: center; text-transform:uppercase">
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div style="padding: 10px;"></div>
            <table>
                <tr>
                    <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 670px;  height: 30px">
                        JUMLAH BAGIAN A</th>
                    <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 400px; background-color: #F0E68C">
                        <input type="text" class="form-control" readonly="readonly" style="background-color: #F0E68C; text-align: right" name="hasil1" id="hasil1">
                    </th>
                </tr>
            </table>
            <button type="button" onclick="addTableHarta(this)">Tambah</button>
            <button type="button" onclick="deleteTableHarta('A_TblHarta')">Hapus</button>
            <button type="submit">Simpan</button>

            <template id="rowTemplateHarta">
                <tr>
                    <td style="border: 1px solid black"><select name='harta[]' style="width:100%; height: 28px; border: 1px solid white">
                            <option value='pilih'>Pilih...</option>
                            <option value='011'>011 - Uang Tunai</option>
                            <option value='012'>012 - Tabungan</option>
                            <option value='013'>013 - Giro</option>
                            <option value='014'>014 - Deposito</option>
                            <option value='019'>019 - Setara Kas Lainnya</option>
                            <option value='021'>021 - Piutang</option>
                            <option value='022'>022 - Piutang Afiliasi (Piutang kepada pihak yang mempunyai hubungan
                                istimewa sebagaimana dimaksud)</option>
                            <option value='029'>029 - Piutang Lainnya</option>
                            <option value='031'>031 - Saham Yang Dibeli Untuk Dijual Kembali</option>
                            <option value='032'>032 - Saham</option>
                            <option value='033'>033 - Obligasi Perusahaan</option>
                            <option value='034'>034 - Obligasi Pemerintah Indonesia (Obligasi Ritel Indonesia atau ORI,
                                surat berharga syariah negara, dll)</option>
                            <option value='035'>035 - Surat Utang Lainnya</option>
                            <option value='036'>036 - Reksadana</option>
                            <option value='037'>037 - Instrumen Derivatif (Right, Warran, Kontrak Berjangka, Opsi, dll)
                            </option>
                            <option value='038'>038 - Penyertaan Modal Perusahaan Lain Yang Tidak Atas Saham Meliputi
                                Penyertaan Modal Pada CV, Firma, dan Sejenisnya</option>
                            <option value='039'>039 - Investasi Lainnya</option>
                            <option value='041'>041 - Sepeda</option>
                            <option value='042'>042 - Sepeda Motor</option>
                            <option value='043'>043 - Mobil </option>
                            <option value='049'>049 - Alat Transportasi Lainnya</option>
                            <option value='051'>051 - Logam Mulia (Emas Batangan, Emas Perhiasan, Platina Batangan,
                                Platina Perhiasan, Logam Mulia Lainnya)</option>
                            <option value='052'>052 - Batu Mulia (Intan, Berlian. Batu Mulia Lainnya)</option>
                            <option value='053'>053 - Barang Seni dan Antik (Barang-Barang Seni, Barang-Barang Antik)
                            </option>
                            <option value='054'>054 - Kapal Pesiar, Pesawat Terbang, Helikopter,Jetski dan Peralatan
                                Olahraga Khusus</option>
                            <option value='055'>055 - Peralatan Elektronik dan Furnitur</option>
                            <option value='059'>059 - Harta Bergerak Lainnya</option>
                            <option value='061'>061 - Tanah dan/atau Bangunan Untuk Tempat Tinggal</option>
                            <option value='062'>062 - Tanah dan/atau Bangunan Untuk Usaha (Toko, Pabrik, Gudang, dan
                                Sejenisnya)</option>
                            <option value='063'>063 - Tanah atau Lahan Untuk Usaha (Lahan Pertanian, Perkebunan,
                                Perikanan Darat, dan Sejenisnya)</option>
                            <option value='069'>069 - Harta Tidak Bergerak Lainnya</option>
                        </select></td>
                    <td style="border: 1px solid black;"><input name="nama_harta[]" class="text" style="width: 100%; border: 1px solid white;text-align: center; text-transform:uppercase">
                    </td>
                    <td style="border: 1px solid black;"><input name="tahun_perolehan[]" class="text" style="width: 100%; border: 1px solid white;text-align: center">
                    </td>
                    <td style="border: 1px solid black;"><input name="harta_perolehan[]" type="text" oninput="format(this.value)" class="harga_perolehan" style="width: 100%; border: 1px solid white;text-align: center">
                    </td>
                    <td style="border: 1px solid black;"><input name="keterangan[]" class="text" style="width: 100%; border: 1px solid white;text-align: center; text-transform:uppercase">
                    </td>
                </tr>
            </template>
        </form>

        <!-- PENUTUP BAGIAN A. HARTA -->

        <!-- BAGIAB B. KEWAJIBAN/UTANG -->
        <p style="font-size: 11px; padding: 10px 0px 0px 0px">BAGIAN B : KEWAJIBAN/UTANG PADA AKHIR TAHUN</p>
        <button type="button" data-bs-toggle="modal" data-bs-target="#exampleModal2" data-bs-whatever="@mdo">Import Data</button>
        <div class="modal fade" id="exampleModal2" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Import Data Utang</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="/DataUtangImport" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="input-group mb-3">
                                <input type="file" name="file" class="form-control" accept=".csv">
                                <button class="btn btn-primary" type="submit">Submit</button>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>

        <form action="/SaveDataUtang" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="counted" value="<?php echo e(count($data_utang)); ?>">
            <table id="B_TblUtang" class="display" style="width:100%">
                <tr>
                    <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width:25%; height: 30px;text-align: center">
                        KODE UTANG</th>
                    <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width:20%;text-align: center">
                        NAMA PEMBERI PINJAMAN</th>
                    <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width:20%;text-align: center">
                        ALAMAT PEMBERI PINJAMAN</th>
                    <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width:20%;text-align: center">
                        TAHUN PEMINJAMAN</th>
                    <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width:20%;text-align: center">
                        JUMLAH PINJAMAN</th>
                </tr>
                <?php if(count($data_utang) == 0): ?>
                <tr>
                    <td style="border: 1px solid black"><select name='kode_utang[]' style="width: 100%; height: 28px; border: 1px solid white">
                            <option value='pilih'>Pilih...</option>
                            <option value='101'>101 - Utang Bank/Lembaga Keuangan Bukan Bank (KPR, Leasing Kendaraan
                                Bermotor, dan sejenisnya)</option>
                            <option value='102'>102 - Utang Kartu Kredit</option>
                            <option value='103'>103 - Utang Afiliasi (Pinjaman dari pihak yang memiliki hubungan
                                istimewasebagaimana dimaksud dalam Pasal 18 ayat (4) Undang-UndangPPh)</option>
                            <option value='109'>109 - Utang Lainnya</option>
                        </select></td>
                    <td style="border: 1px solid black;"><input name='nama_pemberi_pinjaman[]' class="text" style="width: 100%; border: 1px solid white;text-align: center; text-transform:uppercase">
                    </td>
                    <td style="border: 1px solid black;"><input name='alamat_pemberi_pinjaman[]' class="text" style="width: 100%; border: 1px solid white;text-align: center; text-transform:uppercase">
                    </td>
                    <td style="border: 1px solid black;"><input name='tahun_pinjaman[]' class="text" style="width: 100%; border: 1px solid white;text-align: center">
                    </td>
                    <td style="border: 1px solid black;"><input name='jumlah_pinjaman[]' type="text" oninput="format2(this.value)" class="jumlah_pinjaman" style="width: 100%; border: 1px solid white;text-align: center">
                    </td>
                </tr>
                <?php endif; ?>
                <tbody>
                    <?php $__currentLoopData = $data_utang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="border: 1px solid black"><select name='kode_utang[]' style="width: 100%; height: 28px; border: 1px solid white">
                                <option value='pilih'>Pilih...</option>
                                <option value='101' <?php if($dh['kode_utang']=="101" ): ?> selected="selected" <?php endif; ?>>101 - Utang Bank/Lembaga Keuangan Bukan Bank (KPR, Leasing Kendaraan
                                    Bermotor, dan sejenisnya)</option>
                                <option value='102' <?php if($dh['kode_utang']=="102" ): ?> selected="selected" <?php endif; ?>>102 - Utang Kartu Kredit</option>
                                <option value='103' <?php if($dh['kode_utang']=="103" ): ?> selected="selected" <?php endif; ?>>103 - Utang Afiliasi (Pinjaman dari pihak yang memiliki hubungan
                                    istimewasebagaimana dimaksud dalam Pasal 18 ayat (4) Undang-UndangPPh)</option>
                                <option value='109' <?php if($dh['kode_utang']=="109" ): ?> selected="selected" <?php endif; ?>>109 - Utang Lainnya</option>
                            </select></td>
                        <td style="border: 1px solid black;"><input name="nama_pemberi_pinjaman[]" class="text" value="<?php echo e($dh['nama_pemberi_pinjaman']); ?>" style="width: 100%; border: 1px solid white;text-align: center; text-transform:uppercase">
                        </td>
                        <td style="border: 1px solid black;"><input name="alamat_pemberi_pinjaman[]" class="text" value="<?php echo e($dh['alamat_pemberi_pinjaman']); ?>" style="width: 100%; border: 1px solid white;text-align: center; text-transform:uppercase">
                        </td>
                        <td style="border: 1px solid black;"><input name="tahun_pinjaman[]" class="text" value="<?php echo e($dh['tahun_pinjaman']); ?>" style="width: 100%; border: 1px solid white;text-align: center">
                        </td>
                        <td style="border: 1px solid black;"><input name="jumlah_pinjaman[]" type="text" oninput="format2(this.value)" class="jumlah_pinjaman" value="<?php echo e($dh['jumlah_pinjaman']); ?>" style="width: 100%; border: 1px solid white;text-align: center">
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div style="padding: 10px;"></div>
            <table>
                <tr>
                    <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 670px;  height: 30px">
                        JUMLAH BAGIAN B</th>
                    <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 400px; background-color: #F0E68C">
                        <input type="text" class="form-control" disabled="true" readonly="readonly" style="background-color: #F0E68C; text-align: right" name="hasil2" id="hasil2">
                    </th>
                </tr>
            </table>
            <button type="button" onclick="addTableUtang(this)">Tambah</button>
            <button type="button" onclick="deleteTableUtang('B_TblUtang')">Hapus</button>
            <button type="submit">Simpan</button>

            <template id="rowTemplateUtang">
                <tr>
                    <td style="border: 1px solid black"><select name='kode_utang[]' style="width: 100%; height: 28px; border: 1px solid white">
                            <option value='pilih'>Pilih...</option>
                            <option value='101'>101 - Utang Bank/Lembaga Keuangan Bukan Bank (KPR, Leasing Kendaraan
                                Bermotor, dan sejenisnya)</option>
                            <option value='102'>102 - Utang Kartu Kredit</option>
                            <option value='103'>103 - Utang Afiliasi (Pinjaman dari pihak yang memiliki hubungan
                                istimewasebagaimana dimaksud dalam Pasal 18 ayat (4) Undang-UndangPPh)</option>
                            <option value='109'>109 - Utang Lainnya</option>
                        </select></td>
                    <td style="border: 1px solid black;"><input name="nama_pemberi_pinjaman[]" class="text" style="width: 100%; border: 1px solid white;text-align: center; text-transform:uppercase">
                    </td>
                    <td style="border: 1px solid black;"><input name="alamat_pemberi_pinjaman[]" class="text" style="width: 100%; border: 1px solid white;text-align: center; text-transform:uppercase">
                    </td>
                    <td style="border: 1px solid black;"><input name="tahun_pinjaman[]" class="text" style="width: 100%; border: 1px solid white;text-align: center">
                    </td>
                    <td style="border: 1px solid black;"><input name="jumlah_pinjaman[]" type="text" oninput="format2(this.value)" class="jumlah_pinjaman" style="width: 100%; border: 1px solid white;text-align: center">
                    </td>
                </tr>
            </template>
        </form>

        <!-- PENUTUP BAGIAN B. UTANG -->

        <!-- BAGIAN C. KELUARGA -->
        <p style="font-size: 11px; padding: 10px 0px 0px 0px">BAGIAN C : DAFTAR SUSUNAN ANGGOTA KELUARGA</p>

        <form action="/SaveDataKel" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="counted" value="<?php echo e(count($data_kel)); ?>">
            <table id="C_TblKeluarga" class="display" style="width:100%">
                <tr>
                    <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 25%;  height: 30px">
                        NAMA ANGGOTA KELUARGA</th>
                    <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 25%">
                        NIK</th>
                    <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 25%">
                        HUBUNGAN</th>
                    <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 25%">
                        PEKERJAAN</th>
                </tr>
                <?php if(count($data_kel) == 0): ?>
                <tr>
                    <td style="border: 1px solid black;"><input name="nama_anggota_kel[]" class="text" style="width: 100%; border: 1px solid white; text-align:center; text-transform:uppercase">
                    </td>
                    <td style="border: 1px solid black;"><input name="nik[]" class="text" style="width: 100%; border: 1px solid white; text-align:center" maxlength="16" oninput="formatNpwp()" id="formatnpwp">
                    </td>
                    <td style="border: 1px solid black;"><input name="hubungan[]" class="text" style="width: 100%; border: 1px solid white; text-align:center; text-transform:uppercase">
                    </td>
                    <td style="border: 1px solid black;"><input name="pekerjaan[]" class="text" style="width: 100%; border: 1px solid white; text-align:center; text-transform:uppercase">
                    </td>
                </tr>
                <?php endif; ?>
                <tbody>
                    <?php $__currentLoopData = $data_kel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="border: 1px solid black;"><input name="nama_anggota_kel[]" class="text" value="<?php echo e($dh['nama_anggota_kel']); ?>" style="width: 100%; border: 1px solid white; text-align:center; text-transform:uppercase">
                        </td>
                        <td style="border: 1px solid black;"><input name="nik[]" class="text" value="<?php echo e($dh['nik']); ?>" style="width: 100%; border: 1px solid white; text-align:center" maxlength="16" oninput="formatNpwp()" id="formatnpwp">
                        </td>
                        <td style="border: 1px solid black;"><input name="hubungan[]" class="text" value="<?php echo e($dh['hubungan']); ?>" style="width: 100%; border: 1px solid white; text-align:center; text-transform:uppercase">
                        </td>
                        <td style="border: 1px solid black;"><input name="pekerjaan[]" class="text" value="<?php echo e($dh['pekerjaan']); ?>" style="width: 100%; border: 1px solid white; text-align:center; text-transform:uppercase">
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <button type="button" onclick="addTableKeluarga(this)">Tambah</button>
            <button type="button" onclick="deleteTableKeluarga('C_TblKeluarga')">Hapus</button>
            <button type="submit">Simpan</button>

            <template id="rowTemplateKeluarga">
                <tr>
                    <td style="border: 1px solid black;"><input name="nama_anggota_kel[]" class="text" style="width: 100%; border: 1px solid white; text-align:center; text-transform:uppercase">
                    </td>
                    <td style="border: 1px solid black;"><input name="nik[]" class="text" style="width: 100%; border: 1px solid white; text-align:center" oninput="formatNpwp(this)" maxlength="16">
                    </td>
                    <td style="border: 1px solid black;"><input name="hubungan[]" class="text" style="width: 100%; border: 1px solid white; text-align:center; text-transform:uppercase">
                    </td>
                    <td style="border: 1px solid black;"><input name="pekerjaan[]" class="text" style="width: 100%; border: 1px solid white; text-align:center; text-transform:uppercase">
                    </td>
                </tr>
            </template>
        </form>

        <!-- PENUTUP BAGIAN C. KELUARGA -->
    </div>


    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
    <!-- <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"> -->
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
    </script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/numeral.js/2.0.6/numeral.min.js"></script>


    <script>
        let counted = 0;
        let counted2 = 0;
        let counted3 = 0;
        let tr = 1;
        let tr2 = 1;
        let tr3 = 1;
        $(document).ready(function() {
            formatNpwp2();
            format();
            format2();
        });

        function addTableHarta($this) {
            var countdata = <?= count($data_harta) ?>,
                template = document.querySelector('#rowTemplateHarta'),
                tbl = document.querySelector('#A_TblHarta'),
                td_choice = template.content.querySelectorAll("td"),
                last_td = $('#A_TblHarta tr:last'),
                tr_count = tbl.rows.length;

            var kode_harta = last_td.find('td:eq(0)').find('option:selected').val()
            var nama_harta = last_td.find('td:eq(1)').find('input').val();
            var tahun_perolehan = last_td.find('td:eq(2)').find('input').val();
            var harta_perolehan = last_td.find('td:eq(3)').find('input').val();
            var keterangan = last_td.find('td:eq(4)').find('input').val();
            if (kode_harta === 'pilih' || nama_harta === '' || tahun_perolehan === '' || harta_perolehan === '' || keterangan === '') {
                alert('isi dulu datanya');
                return
            }
            // if (counted == 0 && countdata > 0) {
            td_choice.textContent = tr_count;
            var clone = document.importNode(template.content, true);
            tbl.appendChild(clone);
            format();
            counted += 1
            return
            // }
            // var data = {
            //     kode_harta: kode_harta,
            //     nama_harta: nama_harta,
            //     tahun_perolehan: tahun_perolehan,
            //     harta_perolehan: harta_perolehan,
            //     keterangan: keterangan
            // }

            // $.ajax({
            //     headers: {
            //         'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            //     },
            //     type: "POST",
            //     url: 'http://localhost:8000/DataHarta/Store',
            //     data: data,
            //     success: function(res) {
            //         console.log(res)
            //         td_choice.textContent = tr_count;
            //         var clone = document.importNode(template.content, true);
            //         tbl.appendChild(clone);
            //         format();
            //     }
            // });

        }

        // function simpanTableHarta() {
        //     var data = {
        //         kode_harta: kode_harta,
        //         nama_harta: nama_harta,
        //         tahun_perolehan: tahun_perolehan,
        //         harta_perolehan: harta_perolehan,
        //         keterangan: keterangan
        //     }
        //     console.log(data);
        //     $.ajax({
        //         headers: {
        //             'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        //         },
        //         type: "POST",
        //         url: 'http://localhost:8000/DataHarta/Store',
        //         data: data,
        //         success: function(res) {
        //             console.log(res)
        //         }
        //     });
        // }


        function deleteTableHarta(nama) {

            let tr_length = $('#' + nama + ' tr').length;

            if (tr_length == 2) {
                $.ajax({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    type: "POST",
                    url: 'http://localhost:8000/DataHarta/delete',
                    success: function(res) {
                        $('#' + nama + ' tr:last').remove();
                        var countdata = <?= count($data_harta) ?>,
                            template = document.querySelector('#rowTemplateHarta'),
                            tbl = document.querySelector('#A_TblHarta'),
                            td_choice = template.content.querySelectorAll("td"),
                            last_td = $('#A_TblHarta tr:last'),
                            tr_count = tbl.rows.length;
                        td_choice.textContent = tr_count;
                        var clone = document.importNode(template.content, true);
                        tbl.appendChild(clone);
                        format();
                    }
                });
            }
            if (tr_length > 2) {
                $.ajax({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    type: "POST",
                    url: 'http://localhost:8000/DataHarta/delete',
                    success: function(res) {
                        $('#' + nama + ' tr:last').remove();
                        format();
                    }
                });
            }
            counted -= 1;
            format();
        }

        function addTableUtang($this) {
            var countdata = <?= count($data_utang) ?>,
                template = document.querySelector('#rowTemplateUtang'),
                tbl = document.querySelector('#B_TblUtang'),
                td_choice = template.content.querySelectorAll("td"),
                last_td = $('#B_TblUtang tr:last'),
                tr_count = tbl.rows.length;

            var kode_utang = last_td.find('td:eq(0)').find('option:selected').val()
            var nama_pemberi_pinjaman = last_td.find('td:eq(1)').find('input').val();
            var alamat_pemberi_pinjaman = last_td.find('td:eq(2)').find('input').val();
            var tahun_pinjaman = last_td.find('td:eq(3)').find('input').val();
            var jumlah_pinjaman = last_td.find('td:eq(4)').find('input').val();

            console.log(data)
            if (kode_utang === 'pilih' || nama_pemberi_pinjaman === '' || alamat_pemberi_pinjaman === '' || tahun_pinjaman === '' || jumlah_pinjaman === '') {
                alert('isi dulu datanya');
                return
            }
            if (counted2 == 0 && countdata > 0) {
                td_choice.textContent = tr_count;
                var clone = document.importNode(template.content, true);
                tbl.appendChild(clone);
                format2();
                counted2 += 1
                return
            }
            var data = {
                kode_utang: kode_utang,
                nama_pemberi_pinjaman: nama_pemberi_pinjaman,
                alamat_pemberi_pinjaman: alamat_pemberi_pinjaman,
                tahun_pinjaman: tahun_pinjaman,
                jumlah_pinjaman: jumlah_pinjaman
            }

            td_choice.textContent = tr_count;
            var clone = document.importNode(template.content, true);
            tbl.appendChild(clone);
            format2();
        }



        function deleteTableUtang(nama) {

            let tr_length = $('#' + nama + ' tr').length;

            if (tr_length == 2) {
                $.ajax({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    type: "POST",
                    url: 'http://localhost:8000/DataUtang/delete',
                    success: function(res) {
                        $('#' + nama + ' tr:last').remove();
                        var countdata = <?= count($data_utang) ?>,
                            template = document.querySelector('#rowTemplateUtang'),
                            tbl = document.querySelector('#B_TblUtang'),
                            td_choice = template.content.querySelectorAll("td"),
                            last_td = $('#B_TblUtang tr:last'),
                            tr_count = tbl.rows.length;
                        td_choice.textContent = tr_count;
                        var clone = document.importNode(template.content, true);
                        tbl.appendChild(clone);
                        format2();
                    }
                });
            }
            if (tr_length > 2) {
                $.ajax({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    type: "POST",
                    url: 'http://localhost:8000/DataUtang/delete',
                    success: function(res) {
                        $('#' + nama + ' tr:last').remove();
                        format2();
                    }
                });
            }
            counted2 -= 1;
            format2();
        }

        function addTableKeluarga($this) {
            var countdata = <?= count($data_kel) ?>,
                template = document.querySelector('#rowTemplateKeluarga'),
                tbl = document.querySelector('#C_TblKeluarga'),
                td_choice = template.content.querySelectorAll("td"),
                last_td = $('#C_TblKeluarga tr:last'),
                tr_count = tbl.rows.length;
            var nama_anggota_kel = last_td.find('td:eq(0)').find('input').val()
            var nik = last_td.find('td:eq(1)').find('input').val();
            var hubungan = last_td.find('td:eq(2)').find('input').val();
            var pekerjaan = last_td.find('td:eq(3)').find('input').val();
            if (nama_anggota_kel === '' || nik === '' || hubungan === '' || pekerjaan === '') {
                alert('isi dulu datanya');
                return
            }
            if (counted3 == 0 && countdata > 0) {
                td_choice.textContent = tr_count;
                var clone = document.importNode(template.content, true);
                tbl.appendChild(clone);
                counted3 += 1
                return
            }
            var data = {
                nama_anggota_kel: nama_anggota_kel,
                nik: nik,
                hubungan: hubungan,
                pekerjaan: pekerjaan,
            }

            td_choice.textContent = tr_count;
            var clone = document.importNode(template.content, true);
            tbl.appendChild(clone);
        }


        // function addTableKeluarga($this) {
        //     var template = document.querySelector('#rowTemplateKeluarga'),
        //         tbl = document.querySelector('#C_TblKeluarga'),
        //         td_choice = template.content.querySelectorAll("td"),
        //         tr_count = tbl.rows.length;

        //     td_choice.textContent = tr_count;
        //     var clone = document.importNode(template.content, true);
        //     tbl.appendChild(clone);

        // }

        function deleteTableKeluarga(nama) {

            let tr_length = $('#' + nama + ' tr').length;

            if (tr_length == 2) {
                $.ajax({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    type: "POST",
                    url: 'http://localhost:8000/DataKel/delete',
                    success: function(res) {
                        $('#' + nama + ' tr:last').remove();
                        var countdata = <?= count($data_kel) ?>,
                            template = document.querySelector('#rowTemplateKeluarga'),
                            tbl = document.querySelector('#C_TblKeluarga'),
                            td_choice = template.content.querySelectorAll("td"),
                            last_td = $('#C_TblKeluarga tr:last'),
                            tr_count = tbl.rows.length;
                        td_choice.textContent = tr_count;
                        var clone = document.importNode(template.content, true);
                        tbl.appendChild(clone);
                    }
                });
            }
            if (tr_length > 2) {
                $.ajax({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    type: "POST",
                    url: 'http://localhost:8000/DataKel/delete',
                    success: function(res) {
                        $('#' + nama + ' tr:last').remove();
                    }
                });
            }
            counted3 -= 1;
        }
    </script>

    <script>
        let sum = 0;
        let tmp = 0;

        function format() {
            $('.harga_perolehan').each(function() {
                if (this.value.length > 0 && this.value != 0) {
                    tmp2 = getNumPrice(this.value, '.');
                    this.value = numeral(this.value).format();
                    tmp += parseFloat(tmp2)
                } else {
                    tmp += 0
                }
            });
            sum = tmp
            $('#hasil1').val(numeral(sum).format());
            tmp = 0;
        }

        function format2() {
            $('.jumlah_pinjaman').each(function() {
                console.log(this.value)
                if (this.value.length > 0 && this.value != 0) {
                    tmp2 = getNumPrice(this.value, '.');
                    this.value = numeral(this.value).format();
                    tmp += parseFloat(tmp2)
                } else {
                    tmp += 0
                }
            });
            sum = tmp
            $('#hasil2').val(numeral(sum).format());
            tmp = 0;
        }

        function getNumPrice(price, decimalpoint) {
            var p = price.split(decimalpoint);
            for (var i = 0; i < p.length; i++) p[i] = p[i].replace(/\D/g, '');
            return p.join('.');
        }

        function formatNpwp(event) {
            formatnpwp = event.value
            formatnpwp2 = event
            if (!formatnpwp.match(/^[0-9./-]+$/i)) {
                //  alert('Angka saja')?
                formatnpwp2.value = formatnpwp.slice(0, -1);
                return;
            }
            formatnpwp2.value = formatnpwp.replace();
        }

        function formatNpwp2() {
            formatnpwp = document.getElementById('formatnpwpfix').value
            formatnpwp2 = document.getElementById('formatnpwpfix')
            if (typeof formatnpwp === 'string') {

            }
            formatnpwp2.value = formatnpwp.replace(/(\d{2})(\d{3})(\d{3})(\d{1})(\d{3})(\d{3})/, '$1.$2.$3.$4-$5.$6');
        }
    </script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"
        integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"
        integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous">
    </script>
    -->

</body>

</html><?php /**PATH C:\xampp\htdocs\E-Form\resources\views/formulir-IV.blade.php ENDPATH**/ ?>