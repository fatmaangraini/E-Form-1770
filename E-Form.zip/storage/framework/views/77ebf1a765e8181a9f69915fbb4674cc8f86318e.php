<style>
        table {
            border-collapse: collapse;
        }
        table, th, td  {
            border: 1px solid black;
        }
        th, td  {
            padding: 10px;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
    </style>
<table style="width:100%">
        <tr>
            <th class="text-center">Nama</th>
            <th class="text-center">NPWP</th>
            <th class="text-center">Tahun Pajak</th>
            <th class="text-center">Jenis Pelaporan</th>
            <th class="text-center">Pembetulan ke</th>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>   
        </tr>
</table><?php /**PATH C:\xampp\htdocs\E-Form\resources\views/data.blade.php ENDPATH**/ ?>