<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Preview Menu</title>
  </head>
  <style>
    .content {
      background-image: url("<?php echo e(asset('cobabg.png')); ?>");
      height : 600px;
    }
  </style>
  <body>
<div>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark" style="height:40px">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDarkDropdown" aria-controls="navbarNavDarkDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDarkDropdown">
      <ul class="navbar-nav" style="margin-left: 140px;">
      <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Profil
          </a>
          <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDarkDropdownMenuLink">
            <li><a class="dropdown-item" href="#">Peraturan</a></li>
            <li><a class="dropdown-item" href="#">Kurs</a></li>
            <li><a class="dropdown-item" href="#">Tarif Bunga</a></li>
          </ul>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Pengaturan
          </a>
          <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDarkDropdownMenuLink">
            <li><a class="dropdown-item" href="#">Overview</a></li>
            <li><a class="dropdown-item" href="#">Visi, Misi, Tujuan, dan Maklumat Pelayanan </a></li>
            <li><a class="dropdown-item" href="#">Tugas dan Fungsi</a></li>
            <li><a class="dropdown-item" href="#">Logo DJP</a></li>
            <li><a class="dropdown-item" href="#">Kode etik dan kode perilaku</a></li>
            <li><a class="dropdown-item" href="#">Struktur Organisasi</a></li>
            <li><a class="dropdown-item" href="#">Daftar pejabat</a></li>
            <li><a class="dropdown-item" href="#">Unik kerja</a></li>
            <li><a class="dropdown-item" href="#">Hasil survei kepuasan</a></li>
            <li><a class="dropdown-item" href="#">Hasil survei penilaian integritas</a></li>
            <li><a class="dropdown-item" href="#">Hasil survei click ball</a></li>
            <li><a class="dropdown-item" href="#">Hasil survei counter</a></li>
            <li><a class="dropdown-item" href="#">Hasil survei Aplikasi e-riset</a></li>
          </ul>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Unduh
          </a>
          <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDarkDropdownMenuLink">
            <li><a class="dropdown-item" href="#">Aplikasi Perpajakan</a></li>
            <li><a class="dropdown-item" href="#">Formulir Perpajakan</a></li>
          </ul>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Informasi Publik
          </a>
          <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDarkDropdownMenuLink">
            <li><a class="dropdown-item" href="#">Daftar Inofrmasi Publik</a></li>
            <li><a class="dropdown-item" href="#">Anggaran dan Realisasi keuangan</a></li>
            <li><a class="dropdown-item" href="#">Transparansi Kinerja Ditjen Pajak</a></li>
            <li><a class="dropdown-item" href="#">PPID</a></li>
            <li><a class="dropdown-item" href="#">Pengaduan Penyalahgunaan Wewenang</a></li>
            <li><a class="dropdown-item" href="#">Penyediaan pembicara, Pembahas, atau Moderator pada kegiatan</a></li>
          </ul>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Internasional
          </a>
          <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDarkDropdownMenuLink">
            <li><a class="dropdown-item" href="#">APA dan MAP</a></li>
            <li><a class="dropdown-item" href="#">Pertukaran Informasi</a></li>
            <li><a class="dropdown-item" href="#">Tax Treaty</a></li>
          </ul>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Tema
          </a>
          <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDarkDropdownMenuLink">
            <li><a class="dropdown-item" href="#">UU Harmonisasi Pertukaran Perpajakan</a></li>
            <li><a class="dropdown-item" href="#">Program Pengungakapan sukarela</a></li>
            <li><a class="dropdown-item" href="#">DJP Tanggap Covid-19</a></li>
            <li><a class="dropdown-item" href="#">Pajak Digital</a></li>
            <li><a class="dropdown-item" href="#">Edukasi Pajak</a></li>
            <li><a class="dropdown-item" href="#">Infografis</a></li>
            <li><a class="dropdown-item" href="#">Jurnal Pajak</a></li>
            <li><a class="dropdown-item" href="#">Buku Elektronik</a></li>
            <li><a class="dropdown-item" href="#">Kerja Sama dalam Kemitraan</a></li>
            <li><a class="dropdown-item" href="#">Klaster Kemudahan Berusaha Bidang Perpajakan</a></li>
            <li><a class="dropdown-item" href="#">Penegakan Hukum</a></li>
          </ul>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Reformasi Perpajakan
          </a>
        </li>
        <li style=" margin-left:250px; height:40px;" > 
          <button type="button" class="btn btn-warning text-white">Pencarian</button>
        </li>
      </ul>
    </div>
  </div>
</nav>
</div>
<div class="shadow-sm  mb-3 bg-body rounded"><img src="<?php echo e(asset('LOGO DJP.png')); ?>" width="150px" style="margin-left: 140px" alt="" srcset=""></div>
<div class='content' style="padding-top :10px; padding-left:130px; padding-right:130px">
<button  type="button" class="btn btn-dark text-white" data-toggle="button" aria-pressed="false" autocomplete="off">
  Dashboard</button>
  <a href= "<?php echo e(url('/pajak penghasilan')); ?>" type="button" class="btn btn-dark text-white" data-toggle="button" aria-pressed="false" autocomplete="off">
  Pajak Penghasilan</a>
  <button type="button" class="btn btn-dark text-white" data-toggle="button" aria-pressed="false" autocomplete="off">
  SPT Masa</button>
  <a href= "<?php echo e(url('/pengaturan')); ?>" type="button" class="btn btn-dark text-white" data-toggle="button" aria-pressed="false" autocomplete="off">
  Pengaturan </a>
  <div style="background-color:white; height:540px; padding:15px;">
    <div>
      <div class="btn btn-dark text-white" role="button" style="width: 100%; text-align:left;">
      <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAABmJLR0QA/wD/AP+gvaeTAAAA2ElEQVRIie3UsS6EQRQF4O+IFpHo0fAUKg8hEjXv4AUk3oB6oxE1/T4D0SFaiVZ3Nf/GX0h2/o2NkD3VPZmZc+69M3NZ4LeRSVBVFzju6GWSk97aDlYaNQsPST5geeruqm089pNpwBlOmwzwjEOsNYoXbiek36JNbHT0LclLo+A/R79FR9jr6DjJ6CcM+pe85+uZwqgzXscNVhs1C+dJrmFpwKGZ0K9g/F2c5B37sxr8fcz9o00ddlUVHBj2iu6SvNI2i7ZwZV7DLslTVe0aVsH9gGQWmDM+AdbiP8eoQyLjAAAAAElFTkSuQmCC">
  Daftar SPT Masa PPh Unifikasi yang telah dikirim
  <span style= "margin-left:540px; border: 3px solid white; border-radius: 30px; background-color: orange; height:60px;"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABUAAAAVCAYAAACpF6WWAAAABmJLR0QA/wD/AP+gvaeTAAAC8UlEQVQ4je2Sy08TYRTF7zczdPqgaUtJsVAQaGkCBSskLSwqRBElIoSFLPQPMCQk6kZFN04gkUQ2RGUhxsge3UDQuICEYKLQQJECYiiPUtvK02nLtEPbmXFhYmoL1b2e7bn3l3Pu9wH800LpTJOJEoEi1ixRiJsIgsgUeGE/HGTeOiczRgAo3mS7a2MODhc25vrov4KaG6h2jUbdoTMYiEy1+ms8yscwgZewTCDX63Yz275trypbZVueX77kdfZ/SNwljgJWXex6YrZWNgKpXFl1Lpfsb9vzESAaECiztTqhsLTcX1olVgjxiGRzdUObvJ8CNTdQ7Wbr6cZQBPMuTYydjLLMfdd07ysAEIw1nc8jTLiFDR/KAjg6I0KcQyKR6pIZWPINNRp1B5CqlUW7/QTN+Opc071DACAAAHACbw993930rXsquTg/zUYRj2fgKUl/g/IqtklnMBCuhS+GcOjgnm9mYDfRX516NLA4IVR7XAu37GNjwpbXiwuA1Gnry+SyVqlS7QnsOHLdevcwzCaPAwBQ/JodXgLAYJTtvEZkIGnapBzPD0+MvNk7DDOTMDTEHYVMkIDjmE1EkPWVF7qvHAt1vHvwOh47HOcE7j384Q9DWxtOSjJttc2NahyH5kQr5fXFJGnRlhktIpK6wbLMs7Up2SAAxSfPFa/ntypLNCImQOuCB6H+Y5MCACAEuzl5eZz1/FlUoC/rM9WhKX31neuJM5rymzlimfyhwWRY21x1ReVhejQtlOfifrFIwDCCsGgLC2blquwCHCHrT5fCiq23r2ars8ZNlmo/xwZK9v3bj2dmBmJp60ciUY+YxMskBDmJOIGRSKU0KZXbKs51fwQBKbO0pZi+TO/iIkGjc/rTiGOs60UyIwXKMKFvTvtchN6jA4osZVGRUQ+naiq8sRgXxXF0wAT2dO6led3+1k7PUcAjoWQG99nv9bUsTfRMAlCYqXbrslwhqwcAbTzKhYLh4FN5mB51JFX+r1/6ARTpQKhp8mRyAAAAAElFTkSuQmCC"><h15>Refresh</h15></span>
  </div>
  <div style="padding:5px;"></div>
  <form>
  <div class="form-row align-items-center">
    <div class="col-auto my-1">
      <label class="mr-sm-2" for="inlineFormCustomSelect">Tampilkan</label>
      <select class="custom-select mr-sm-2" id="inlineFormCustomSelect">
        <option selected>Choose</option>
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
      </select>
      <label class="mr-sm-2" for="inlineFormCustomSelect">entri</label>
      <table class="table table-bordered">
      <div style="padding:10px;"></div>
  <thead>
  <tr class="bg-warning">
      <th scope="col">No</th>
      <th scope="col">No. BPE/NTTE</th>
      <th scope="col">Masa/Tahun pajak</th>
      <th scope="col">PBLT ke</th>
      <th scope="col">Tanggal Kirim</th>
      <th scope="col">Aksi</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>265976756931</td>
      <td>2022-05</td>
      <td>Normal</td>
      <td>14-10-2021</td>
      <td>Icon</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>6428767566582</td>
      <td>2022-01</td>
      <td>1</td>
      <td>10-09-2021</td>
      <td>Icon</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>1615867863155</td>
      <td>2021-12</td>
      <td>Normal</td>
      <td>14-10-2021</td>
      <td>Icon</td>
    </tr>
  </tbody>
  </table> 
  <div style = "display: flex; justify-content: space-between;">
  <div>
    Menampilkan 1 sampai 3 dari entri
  </div>
  <div >
    <nav aria-label="Page navigation example">
  <ul class="pagination">
    <li class="page-item"><a class="page-link" href="#">Sebelumnya</a></li>
    <li class="page-item"><a class="page-link" href="#">1</a></li>
    <li class="page-item"><a class="page-link" href="#">2</a></li>
    <li class="page-item"><a class="page-link" href="#">3</a></li>
    <li class="page-item"><a class="page-link" href="#">Selanjutnya</a></li>
  </ul>
  </div>
</nav>
    </div>
  </div>
  </div>
  </div>
  

  


   
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    
  </body>
</html><?php /**PATH C:\xampp\htdocs\E-Form\resources\views/home.blade.php ENDPATH**/ ?>