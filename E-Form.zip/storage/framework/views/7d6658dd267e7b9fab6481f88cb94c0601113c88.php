<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
    <link type="stylesheet" href="//cdn.datatables.net/1.13.1/css/jquery.dataTables.min.css">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Arsip SPT</title>
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 0;
            font-family: arial;
            font-size: 16px;
            line-height: 1.6;
            background-image: url("<?php echo e(asset('poltek4.jpeg')); ?>");
            background-repeat: no-repeat;
            background-size: cover;
        }

        header {
            background-color: rgba(0, 0, 0, 0.7);
        }

        header span {
            color: rgb(255, 157, 49)
        }

        .content {
            padding-top: 10px;
            padding-left: 250px;
            padding-right: 250px;
            height: auto;
        }

        .card-box {
            width: 840px;
            background-color: #f5f5f5;
            padding: 18px 20px 10px 20px;
            height: auto
        }

        .card-tab {
            background-color: rgb(255, 157, 49);
            border-radius: 8px 8px 8px 8px;
            box-shadow: 2px 2px 2px 2px lightgrey;
            padding: 10px 10px 10px 10px
        }

        .nav-tabs {
            height: 40px;
            border-bottom: 0px
        }

        .card-box2 {
            background-color: #FFFFFF;
            border-radius: 8px 8px 0px 0px
        }

        .navbar-expand-lg {
            background-color: #191970;
            font-variant: normal;
        }

        .nav-link {
            color: #FFFFFF;
        }

        .container {
            max-width: 1000px;
            margin: 20px auto;
        }

        .title_1 {
            background-color: rgb(4, 153, 195);
            height: 40px;
            padding: 10px 0px 0px 10px;
            border-radius: 8px 8px 0px 0px
        }

        .title_1 span {
            color: #FFFFFF;
            font-weight: bold;
        }

        thead tr {
            background-color: rgb(4, 153, 195)
        }

        thead tr th {
            color: #FFFFFF;
            font-size: 12px;
            text-align: center;
        }

        tbody tr td {
            background-color: #FFFFFF;
            font-size: 13.5px;
            text-align: center;
            font-weight: bold;
        }

        .media-social {
            font-size: 18px;
            display: inline-block;
            background: #ffb727;
            color: #fff;
            line-height: 1;
            padding: 8px 0;
            margin-right: 4px;
            border-radius: 50%;
            text-align: center;
            width: 36px;
            height: 36px;
        }

        .media-social i {
            color: #FFF;
        }

        .copyright {
            font-size: 12px;
            color: #FFF;
            padding-top: 30px;
        }

        .tab_container_wrap input {
            position: absolute;
            width: 0;
            height: 0;
            margin: 0;
            z-index: -100;
            top: -1000px;
        }

        .tab_container_wrap input:checked+.tab_content_box {
            display: block;
        }

        .tab_content_box {
            background: #F5F5F5;
            padding: 20px;
            display: none;
        }

        .tab_content_box:nth-child(1) {
            background: #f0f0f0;

        }

        .tab_content_box:nth-child(2) {
            background: #f0f0f0;
        }


        .tab_content_box h2 {
            margin: 0 0 20px;
        }
    </style>
</head>

<body>
    <div>
        <header class="mb-3 border-bottom">
            <div class="container-fluid d-grid gap-3 align-items-center" style="grid-template-columns: 1fr 2fr;"><img src="<?php echo e(asset('taxcentre1.png')); ?>" alt="" srcset="">
                <div class="d-flex align-items-center">
                    <form class="w-100 me-3">
                    </form>
                    <div class="flex-shrink-0 dropdown">
                        <a href="#" class="d-block link-dark text-decoration-none dropdown-toggle" id="dropdownUser2" data-bs-toggle="dropdown" aria-expanded="false">
                            <span>User &nbsp;</span><img src="https://github.com/mdo.png" alt="mdo" width="32" height="32" class="rounded-circle">
                        </a>
                        <ul class="dropdown-menu text-small shadow" aria-labelledby="dropdownUser2">
                            <li><a class="dropdown-item" href="#">Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </header>
        <div>
            <div class="container mt-4">
                <div class="page-inner">
                    <div class="row">
                        <div class="col-lg-12 col-md-9">
                            <div class="card">
                                <div class="card-body">

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>
    <div class="shadow-sm " id="footer" style="background-color: rgba(0,0,0,0.7); height:auto">
        <div>
            <div align="center" class="col-sm-3">
                <img src="<?php echo e(asset('taxcentre.png')); ?>" alt="">
            </div>
            <div align="center" class="col-sm-4">
                <span style="color: #FFF;"> <i>Alamat</i> </span>
                <div align="left" class="col-sm-8">
                    <span style="color: #FFF;"><i>Jl. Ahmad Yani Batam Kota. Kota Batam. <br> kepulauan Riau.
                            Indonesia</i> </span>
                </div>
                <div align="left" class="col-sm-8">
                    <span style="color: #FFF;"><i><br> Email : info@polibatam.ac.id <br>Phone : +62-778-469858 Ext.1017
                            <br>Fax : +62-778-463620 <br>
                            Email : info@polibatam.ac.id</i> </span>
                </div>
            </div>
            <div align="center" class="col-sm-12">
                <span style="color: #FFF; font-size: 36px; font-family:'Satisfy',serif;"> <i>Tax Center</i> </span>
            </div>
            <div align="center" class="col-sm-12">
                <span style="color: #FFF; font-size: 14px"> <i>Politeknik Negeri Batam</i> </span>
            </div>
        </div>
        <div align="center" class="col-sm-12" style="padding-top: 30px;">
            <div class="media-social">
                <a href=""><i class="fa-brands fa-twitter"></i></a>
            </div>
            <div class="media-social">
                <a href=""><i class="fa-brands fa-facebook-f"></i></a>
            </div>
            <div class="media-social">
                <a href=""><i class="fa-brands fa-instagram"></i></i></a>
            </div>
            <div class="media-social">
                <a href=""><i class="fa-brands fa-skype"></i></a>
            </div>
            <div class="media-social">
                <a href=""><i class="fa-brands fa-linkedin-in"></i></a>
            </div>
        </div>

        <div align="center" class="col-sm-12">
            <div class="copyright">
                <i class="fa-regular fa-copyright"></i> Copyright
                <strong>Polibatam Software Team</strong>
                All Rights Reserved
            </div>
        </div>

    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js" integrity="sha512-aVKKRRi/Q/YV+4mjoKBsE4x3H+BkegoM/em46NNlCqNTmUYADjBbeNefNxYV7giUp0VxICtqdrbqU7iVaeZNXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="//cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#example').DataTable();
        });
    </script>
    <script>
        function nav() {
            document.getElementById("nav-home-tab").classList.toggle("active");;
        }
    </script>
</body>



</html><?php /**PATH C:\xampp\htdocs\E-Form\resources\views/tes1.blade.php ENDPATH**/ ?>