<!DOCTYPE html>
<html lang="en">

<head>
  <title>Form</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <!-- <script src="jquery/jquery-3.4.1.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script> -->
  <style>
    table {
      border-collapse: collapse;
    }

    table,
    th,
    td {
      border: 1px solid orange;
    }

    th,
    td {
      padding: 10px;
    }

    th {
      background-color: #FF8C00;
      color: white;
    }
  </style>
</head>
<style>
  table tr td {
    height: 20px;
  }
</style>

<body>
  <div class="container p-3 my-3 border">
    <h1 class="text-center">Formulir Lorem Ipsum</h1>
    <!-- <?php $token = md5(now()) ?> -->
    <form id="form" action="<?php echo e(route('add')); ?>" method="post">
      <?php echo csrf_field(); ?>
      <div class="alert alert-secondary">
        <strong>Data Diri</strong>
      </div>
      <div class="row">
        <div class="col-sm-6">
          <div class="form-group">
            <label>Nama Lengkap</label>
            <input type="text" name="name" class="form-control" placeholder="Masukan Nama Lengkap">
          </div>
        </div>
        <div class="col-sm-6">
          <div class="form-group">
            <label>Nomor Identitas (NIK):</label>
            <input type="text" name="nik" class="form-control" placeholder="Masukan Nomor NIK">
          </div>
        </div>
        <div class="col-sm-6">
          <div class="form-group">
            <label>Tempat Lahir:</label>
            <input type="text" name="tempat_lahir" class="form-control" placeholder="Masukan Tempat Lahir">
          </div>
        </div>
        <div class="col-sm-6">
          <div class="form-group">
            <label>Tanggal Lahir:</label>
            <input type="date" name="tanggal_lahir" class="form-control">
          </div>
        </div>

        <div class="col-sm-6">
          <div class="form-group">
            <label>NPWP</label>
            <input type="text" name="npwp" class="form-control" placeholder="Masukan NPWP">
          </div>
        </div>
        <div class="col-sm-6">
          <div class="form-group">
            <label>Tahun Pajak</label>
            <input type="text" name="tahun" class="form-control" placeholder="Masukan Tahun">
          </div>
        </div>
        <div class="col-sm-6">
          <div class="form-group">
            <label>Jenis Pelaporan</label>
            <div class="form-check">
              <label class="form-check-label">
                <input type="radio" class="form-check-input" value="Pembukuan" name="jenis_pelaporan" checked>Pembukuan
              </label>
            </div>
            <div class="form-check">
              <label class="form-check-label">
                <input type="radio" class="form-check-input" value="Pencatatan" name="jenis_pelaporan">Pencatatan
              </label>
            </div>
          </div>
        </div>

        <div class="col-sm-6">
          <div class="form-group">
            <div class="form-check">
              <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
              <label class="form-check-label" for="defaultCheck1">Ceklis Pembetulan Ke</label>
              <input type="text" class="form-control" placeholder="0" name="pembetulan">
            </div>
          </div>
        </div>
      </div>
      <div class="alert alert-secondary">
        <strong>Data Tabel</strong>
      </div>


      <table id="myTable" class="display" style="width:100%">
        <tr>
          <th class="text-center">Lorem ipsum</th>
          <th class="text-center">Lorem ipsum</th>
          <th class="text-center">Lorem ipsum</th>
          <th class="text-center">Lorem ipsum</th>
          <th class="text-center">Lorem ipsum</th>
        </tr>
        <tr>
          <td><select size="1" id="row-1-office" name="choice[]" style="width:100%">
              <option value="Edinburgh" selected="selected" name="">
                Pilih...
              </option>
              <option value="Pilihan 1">
                Pilihan 1
              </option>
              <option value="Pilihan 2">
                Pilihan 2
              </option>
              <option value="Pilihan 3">
                Pilihan 3
              </option>
              <option value="Pilihan 4">
                Pilihan 4
            </select>
          <td><input type="text" style="width:100%" name="name_treasure[]"> </td>
          <td><input type="text" style="width:100%" name="acquisition_year[]"> </td>
          <td><input type="text" style="width:100%" name="acquisition_cost[]"> </td>
          <td><input type="text" style="width:100%" name="description[]"> </td>
        </tr>
      </table>
      <div class="col-sm-2">
        <button type="button" onclick="myFunction(this)">Tambah</button>
      </div>
      <h1></h1>
      <table id="myTable" class="display" style="width:100%">
        <tr>
          <th class="text-center">NO</th>
          <th class="text-center">Lorem ipsum</th>
          <th class="text-center">Lorem ipsum</th>
          <th class="text-center">Lorem ipsum</th>
        </tr>
        <td>1.</td>
        <td style="width:30%">Lorem ipsum lorem ipsum</td>
        <td><input type="text" style="width:100%" placeholder="0"> </td>
        <td><input type="text" style="width:100%" placeholder="0"> </td>
        <tr>
          <td>2.</td>
          <td style="width:30%">Lorem ipsum lorem ipsum</td>
          <td><input type="text" style="width:100%" placeholder="0"> </td>
          <td><input type="text" style="width:100%" placeholder="0"> </td>
        </tr>
      </table>
      <h1></h1>
      <div class="row">
        <div class="col-sm-4">
          <a href="/form1" class="btn btn-secondary">Selanjutnya</a>
        </div>
      </div>
  </div>


  </form>

  </div>


  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  <script>
    function myFunction($this) {
      var $tableBody = $('#myTable'),
        $trLast = $tableBody.find("tr:last"),
        $trNew = $trLast.clone();

      $trLast.after($trNew);
    }
  </script>
</body>

</html><?php /**PATH C:\xampp\htdocs\E-Form\resources\views/index.blade.php ENDPATH**/ ?>