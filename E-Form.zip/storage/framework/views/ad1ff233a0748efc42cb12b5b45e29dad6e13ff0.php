<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js" integrity="sha512-aVKKRRi/Q/YV+4mjoKBsE4x3H+BkegoM/em46NNlCqNTmUYADjBbeNefNxYV7giUp0VxICtqdrbqU7iVaeZNXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <title>PP46/23</title>
    <style>
        .bg-grey {
            font-family: arial;
            background-color: #ccc;
        }

        .vericaltext {
            writing-mode: vertical-lr;
            text-orientation: use-glyph-orientation;
        }

        .year {
            border: 1px solid black;
            width: 20px;
            font-size: 25px;
        }

        table tr th {
            border: 1px solid black;
            font-size: 25px;
        }
    </style>
</head>

<body class="bg-grey" style="padding: 1% 10% 1% 10%">
    <div class="container" style="width : 90%; background-color: #fff">
        <div style="padding: 10px"></div>
        <div class="row" style="font-size: 12px; font-weight: bold; text-align:center">
            <div class="col-sm-5"><a href="/formulir-III" class="btn btn-secondary" style="font-size: 12px; width: 120px; height: 30px">Sebelumnya</a></div>
            <div class="col-sm-7"><a href="/formulir-II" class="btn btn-secondary" style="font-size: 12px; width: 120px; height: 30px">Selanjutnya</a></div>
            <b style="padding: 10px;">DAFTAR JUMLAH PENGHASILAN BRUTO DAN PEMBAYARAN PPh FINAL BERDASARKAN PP 46 TAHUN 2013 DAN ATAU PP 23 TAHUN 2018
                </br>PER MASA PAJAK SERTA DARI MASING-MASING TEMPAT USAHA</b>
        </div>
        <div style="padding: 5px;"></div>
        <div class="col-sm-11.5" style=" border: 1px solid black; background-color: #F0E68C ; padding: 4px 20px 10px 10px ; height: auto; border: 2px solid; margin-left: 10px">
            <div class="row">
                <label class="col-sm-4 col-form-label" style="font-size: 12px;">NPWP</label>
                <div class="col-sm-8">
                    <input class="form-control" type="text" style="border: 1px solid black; height: 30px; border-radius: 1px; " value="<?php echo e($npwp); ?>" disabled="disabled" id="npwpWP">
                </div>
            </div>
            <div class="row">
                <label class="col-sm-4 col-form-label" style="font-size: 12px;">NAMA WAJIB PAJAK</label>
                <div class="col-sm-8">
                    <input class="form-control" type="text" style="border: 1px solid black; height: 30px; border-radius: 1px;" value="<?php echo e($nama); ?>" disabled="disabled">
                </div>
            </div>
            <div class="row">
                <label class="col-sm-4 col-form-label" style="font-size: 12px;">ALAMAT</label>
                <div class="col-sm-8">
                    <input class="form-control" type="text" style="border: 1px solid black; height: 30px; border-radius: 1px; background-color: #FFFFFF">
                </div>
            </div>
        </div>

        <div style="padding: 10px;"></div>
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Import Daftar PP4623</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="/DataDaftar4623Import" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="input-group mb-3">
                                <input type="file" name="file" class="form-control" accept=".csv">
                                <button class="btn btn-primary" type="submit">Submit</button>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>
        <form action="/SaveDataPP4623" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="counted" value="<?php echo e(count($datadaftarpp4623)); ?>">
            <button type="button" data-bs-toggle="modal" data-bs-target="#exampleModal" data-bs-whatever="@mdo">Import Data</button>

            <table id="PP46_23" class="display" style="width:100%">
                <tr>
                    <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 20%;  height: 30px">
                        NPWP</th>
                    <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 20%">
                        MASA PAJAK</th>
                    <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 20%">
                        ALAMAT</th>
                    <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 20%">
                        PEREDARAN BRUTO</th>
                    <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 20%">
                        JUMLAH PPh FINAL YANG DIBAYAR</th>
                </tr>
                <?php if(count($datadaftarpp4623) == 0): ?>
                <tr>
                    <td style="border: 1px solid black;"><input name="npwp[]" type="text" style="border: 1px solid white; font-size: 14px; text-align: center; width: 100%; height: 30px" maxlength="20" oninput="formatNpwp2(this)" id="formatnpwpfix"></td>
                    <td style="border: 1px solid black;"><select name='masa_pajak[]' style="width:100%; height:30px; border: 1px solid white">
                            <option value='pilih'>Pilih...</option>
                            <option value='1'>Januari</option>
                            <option value='2'>Februari</option>
                            <option value='3'>Maret</option>
                            <option value='4'>April</option>
                            <option value='5'>Mei</option>
                            <option value='6'>Juni</option>
                            <option value='7'>Juli</option>
                            <option value='8'>Agustus</option>
                            <option value='9'>September</option>
                            <option value='10'>Oktober</option>
                            <option value='11'>November</option>
                            <option value='12'>Desember</option>

                        </select> </td>
                    <td style="border: 1px solid black;"><input name="alamat[]" type="text" style="border: 1px solid white; font-size: 14px; width:100%; height: 30px; text-align:center; text-transform:uppercase"></td>
                    <td style="border: 1px solid black;"><input name="peredaran_bruto[]" type="text" style="border: 1px solid white; font-size: 14px; text-align: center; width:100%; height: 30px" oninput="formatperedaranbruto(this.value)" class="peredaranbruto"></td>
                    <td style="border: 1px solid black;"><input name="jumlahPPhFinal_dibayar[]" type="text" style="border: 1px solid white; font-size: 14px; text-align: center; width:100%; height: 30px" oninput="formatJmlPPhFinalDibayar(this.value)" class="jumlahPPhFinalYangDibayar"></td>
                </tr>
                <?php endif; ?>
                <tbody>
                    <?php $__currentLoopData = $datadaftarpp4623; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="border: 1px solid black;"><input name="npwp[]" type="text" value="<?php echo e($dh['npwp']); ?>" style="border: 1px solid white; font-size: 14px; text-align: center; width: 100%; height: 30px" maxlength="20" oninput="formatNpwp2(this)" id="formatnpwpfix"></td>
                        <td style="border: 1px solid black;"><select name='masa_pajak[]' style="width:100%; height:30px; border: 1px solid white">
                                <option value='pilih'>Pilih...</option>
                                <option value='1' <?php if($dh['masa_pajak']=="1" ): ?> selected="selected" <?php endif; ?>>Januari</option>
                                <option value='2' <?php if($dh['masa_pajak']=="2" ): ?> selected="selected" <?php endif; ?>>Februari</option>
                                <option value='3' <?php if($dh['masa_pajak']=="3" ): ?> selected="selected" <?php endif; ?>>Maret</option>
                                <option value='4' <?php if($dh['masa_pajak']=="4" ): ?> selected="selected" <?php endif; ?>>April</option>
                                <option value='5' <?php if($dh['masa_pajak']=="5" ): ?> selected="selected" <?php endif; ?>>Mei</option>
                                <option value='6' <?php if($dh['masa_pajak']=="6" ): ?> selected="selected" <?php endif; ?>>Juni</option>
                                <option value='7' <?php if($dh['masa_pajak']=="7" ): ?> selected="selected" <?php endif; ?>>Juli</option>
                                <option value='8' <?php if($dh['masa_pajak']=="8" ): ?> selected="selected" <?php endif; ?>>Agustus</option>
                                <option value='9' <?php if($dh['masa_pajak']=="9" ): ?> selected="selected" <?php endif; ?>>September</option>
                                <option value='10' <?php if($dh['masa_pajak']=="10" ): ?> selected="selected" <?php endif; ?>>Oktober</option>
                                <option value='11' <?php if($dh['masa_pajak']=="11" ): ?> selected="selected" <?php endif; ?>>November</option>
                                <option value='12' <?php if($dh['masa_pajak']=="12" ): ?> selected="selected" <?php endif; ?>>Desember</option>

                            </select> </td>
                        <td style="border: 1px solid black;"><input name="alamat[]" type="text" value="<?php echo e($dh['alamat']); ?>" style="border: 1px solid white; font-size: 14px; text-align:center; width:100%; height: 30px; text-transform:uppercase"></td>
                        <td style="border: 1px solid black;"><input name="peredaran_bruto[]" type="text" value="<?php echo e($dh['peredaran_bruto']); ?>" style="border: 1px solid white; font-size: 14px; text-align: center; width:100%; height: 30px" oninput="formatperedaranbruto(this.value)" class="peredaranbruto"></td>
                        <td style="border: 1px solid black;"><input name="jumlahPPhFinal_dibayar[]" type="text" value="<?php echo e($dh['jumlahPPhFinal_dibayar']); ?>" style="border: 1px solid white; font-size: 14px; text-align: center; width:100%; height: 30px" oninput="formatJmlPPhFinalDibayar(this.value)" class="jumlahPPhFinalYangDibayar"></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </br>
            </table>
            <div style="padding: 10px;"></div>
            <table>
                <tr>
                    <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 670px;  height: 30px">PEREDARAN BRUTO</th>
                    <th style="background-color: #F0E68C; border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 400px">
                        <input type="text" class="form-control" disabled="true" readonly="readonly" style="background-color: #F0E68C; text-align: right; height:30px" name="hasilPbruto" id="hasilPbruto">
                    </th>
                    <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 400px">JUMLAH PPh FINAL YANG DIBAYAR</th>
                    <th style="background-color: #F0E68C; border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 400px">
                        <input type="text" class="form-control" disabled="true" readonly="readonly" style="background-color: #F0E68C; text-align: right; height:30px" name="hasilPPhFinal" id="hasilPPhFinal">
                    </th>
                </tr>
            </table>
            <button type="button" onclick="addTablePP46_23(this)">Tambah</button>
            <button type="button" onclick="deleteTablePP46_23('PP46_23')">Hapus</button>
            <button type="submit">Simpan</button>

            <template id="rowTemplatePP46_23">
                <tr>
                    <td style="border: 1px solid black;"><input name="npwp[]" type="text" style="border: 1px solid white; font-size: 14px; text-align: center; width: 100%; height: 30px" maxlength="20" oninput="formatNpwp2(this)" id="formatnpwpfix"></td>
                    <td style="border: 1px solid black;"><select name='masa_pajak[]' style="width:100%; height:30px; border: 1px solid white">
                            <option value='pilih'>Pilih...</option>
                            <option value='1'>Januari</option>
                            <option value='2'>Februari</option>
                            <option value='3'>Maret</option>
                            <option value='4'>April</option>
                            <option value='5'>Mei</option>
                            <option value='6'>Juni</option>
                            <option value='7'>Juli</option>
                            <option value='8'>Agustus</option>
                            <option value='9'>September</option>
                            <option value='10'>Oktober</option>
                            <option value='11'>November</option>
                            <option value='12'>Desember</option>

                        </select></td>
                    <td style="border: 1px solid black;"><input name="alamat[]" type="text" style="border: 1px solid white; font-size: 14px; text-align:center; width:100%; height: 30px; text-transform:uppercase"></td>
                    <td style="border: 1px solid black;"><input name="peredaran_bruto[]" type="text" style="border: 1px solid white; font-size: 14px; text-align: center; width:100%; height: 30px" oninput="formatperedaranbruto(this.value)" class="peredaranbruto"></td>
                    <td style="border: 1px solid black;"><input name="jumlahPPhFinal_dibayar[]" type="text" style="border: 1px solid white; font-size: 14px; text-align: center; width:100%; height: 30px" oninput="formatJmlPPhFinalDibayar(this.value)" class="jumlahPPhFinalYangDibayar"></td>
                </tr>
            </template>
        </form>

        <div style="padding: 10px;">
            <label style="font-size: 14px;">PINDAHKAN NILAI KE LAMPIRAN III ?</label>
            <div class="form-check" style="display:inline-block; margin-left: 10px">
                <input style="display:inline;" class="form-check-input" type="radio" name="flexRadioDisabled" id="flexRadioDisabled">
                <label class="form-check-label" for="flexRadioDisabled" style="font-size: 14px;">
                    Ya
                </label>
            </div>
            <div class="form-check" style="display:inline-block; margin-left: 10px">
                <input class="form-check-input" type="radio" name="flexRadioDisabled" id="flexRadioCheckedDisabled">
                <label class="form-check-label" for="flexRadioCheckedDisabled" style="font-size: 14px;">
                    Tidak
                </label>
            </div>
        </div>

    </div>
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
    <!-- <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous">
    </script> -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
    </script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/numeral.js/2.0.6/numeral.min.js"></script>
   
    <script>
        let counted = 0;
        $(document).ready(function() {
            formatperedaranbruto();
            formatJmlPPhFinalDibayar();
            npwpWP();
        });

        function formatNpwp2(event) {
            formatnpwp = event.value
            formatnpwp2 = event
            if (!formatnpwp.match(/^[0-9./-]+$/i)) {
                alert('Angka saja')
                formatnpwp2.value = formatnpwp.slice(0, -1);
                return;
            }
            formatnpwp2.value = formatnpwp.replace(/(\d{2})(\d{3})(\d{3})(\d{1})(\d{3})(\d{3})/, '$1.$2.$3.$4-$5.$6');
        }

        function npwpWP() {
                npwpWP = document.getElementById('npwpWP').value
                npwpWP2 = document.getElementById('npwpWP')
                if (typeof npwpWP === 'string') {

                }
                npwpWP2.value = npwpWP.replace(/(\d{2})(\d{3})(\d{3})(\d{1})(\d{3})(\d{3})/, '$1.$2.$3.$4-$5.$6');
        }

        function addTablePP46_23($this) {
            var countdata = <?= count($datadaftarpp4623) ?>,
                template = document.querySelector('#rowTemplatePP46_23'),
                tbl = document.querySelector('#PP46_23'),
                td_choice = template.content.querySelectorAll("td"),
                last_td = $('#PP46_23 tr:last'),
                tr_count = tbl.rows.length;
            var npwp = last_td.find('td:eq(0)').find('input').val()
            var masa_pajak = last_td.find('td:eq(1)').find('option:selected').val();
            var alamat = last_td.find('td:eq(2)').find('input').val();
            var peredaran_bruto = last_td.find('td:eq(3)').find('input').val();
            var jumlahPPhFinal_dibayar = last_td.find('td:eq(4)').find('input').val();
            if (npwp === '' || masa_pajak === 'pilih' || alamat === '' || peredaran_bruto === '' || jumlahPPhFinal_dibayar === '') {
                alert('isi dulu datanya');
                return
            }
            if (counted == 0 && countdata > 0) {
                td_choice.textContent = tr_count;
                var clone = document.importNode(template.content, true);
                tbl.appendChild(clone);
                formatperedaranbruto();
                formatJmlPPhFinalDibayar();

                counted += 1
                return
            }
            var data = {
                npwp: npwp,
                masa_pajak: masa_pajak,
                alamat: alamat,
                peredaran_bruto: peredaran_bruto,
                jumlahPPhFinal_dibayar: jumlahPPhFinal_dibayar
            }


            td_choice.textContent = tr_count;
            var clone = document.importNode(template.content, true);
            tbl.appendChild(clone);
            formatperedaranbruto();
            formatJmlPPhFinalDibayar();
        }


        function deleteTablePP46_23(nama) {

            let tr_length = $('#' + nama + ' tr').length;

            if (tr_length == 2) {
                $.ajax({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    type: "POST",
                    url: 'http://localhost:8000/Datapp46danpp23/delete',
                    success: function(res) {
                        $('#' + nama + ' tr:last').remove();
                        var countdata = <?= count($datadaftarpp4623) ?>,
                            template = document.querySelector('#rowTemplatePP46_23'),
                            tbl = document.querySelector('#PP46_23'),
                            td_choice = template.content.querySelectorAll("td"),
                            last_td = $('#PP46_23 tr:last'),
                            tr_count = tbl.rows.length;
                        td_choice.textContent = tr_count;
                        var clone = document.importNode(template.content, true);
                        tbl.appendChild(clone);
                        formatperedaranbruto();
                        formatJmlPPhFinalDibayar();
                    }
                });
            }
            if (tr_length > 2) {
                $.ajax({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    type: "POST",
                    url: 'http://localhost:8000/Datapp46danpp23/delete',
                    success: function(res) {
                        $('#' + nama + ' tr:last').remove();
                        formatperedaranbruto();
                        formatJmlPPhFinalDibayar();
                    }
                });
            }
            counted -= 1;
            formatperedaranbruto();
            formatJmlPPhFinalDibayar();
        }

        // function addTablePP46_23($this) {
        //     var template = document.querySelector('#rowTemplatePP46_23'),
        //         tbl = document.querySelector('#PP46_23'),
        //         td_choice = template.content.querySelectorAll("td"),
        //         tr_count = tbl.rows.length;

        //     td_choice.textContent = tr_count;
        //     var clone = document.importNode(template.content, true);
        //     tbl.appendChild(clone);
        //     formatJmlPPhFinalDibayar();
        // }

        // function deleteTablePP46_23(nama) {

        //     let tr_length = $('#' + nama + ' tr').length;

        //     if (tr_length > 2) {
        //         $('#' + nama + ' tr:last').remove();
        //     }
        //     formatJmlPPhFinalDibayar();
        // }
    </script>
    <script>
        let sum = 0;
        let tmp = 0;

        function formatperedaranbruto() {
            $('.peredaranbruto').each(function() {
                console.log(this.value)
                if (this.value.length > 0 && this.value != 0) {
                    tmp2 = getNumPrice(this.value, '.');
                    this.value = numeral(this.value).format();
                    tmp += parseFloat(tmp2)
                } else {
                    tmp += 0
                }
            });
            sum = tmp
            $('#hasilPbruto').val(numeral(sum).format());
            tmp = 0;
        }

        function formatJmlPPhFinalDibayar() {
            $('.jumlahPPhFinalYangDibayar').each(function() {
                console.log(this.value)
                if (this.value.length > 0 && this.value != 0) {
                    tmp2 = getNumPrice(this.value, '.');
                    this.value = numeral(this.value).format();
                    tmp += parseFloat(tmp2)
                } else {
                    tmp += 0
                }
            });
            sum = tmp
            $('#hasilPPhFinal').val(numeral(sum).format());
            tmp = 0;
        }

        function getNumPrice(price, decimalpoint) {
            var p = price.split(decimalpoint);
            for (var i = 0; i < p.length; i++) p[i] = p[i].replace(/\D/g, '');
            return p.join('.');
        }
    </script>
</body>

</html><?php /**PATH C:\xampp\htdocs\E-Form\resources\views/PP46atau23.blade.php ENDPATH**/ ?>