<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.1/css/dataTables.bootstrap5.min.css">
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <title>Arsip SPT</title>
  <style>
    * {
      box-sizing: border-box;
    }

    body {
      margin: 0;
      padding: 0;
      font-family: arial;
      font-size: 16px;
      line-height: 1.6;
      background-image: url("<?php echo e(asset('poltek4.jpeg')); ?>");
      background-repeat: no-repeat;
      background-size: cover;
    }

    header {
      background-color: rgba(0, 0, 0, 0.7);
    }

    header span {
      color: rgb(255, 157, 49)
    }

    .content {
      padding-top: 10px;
      padding-left: 250px;
      padding-right: 250px;
      height: auto;
    }

    .card-box {
      width: 840px;
      background-color: #f5f5f5;
      padding: 18px 20px 10px 20px;
      height: auto
    }

    .card-tab {
      background-color: rgb(255, 157, 49);
      border-radius: 8px 8px 8px 8px;
      box-shadow: 2px 2px 2px 2px lightgrey;
      padding: 10px 10px 10px 10px
    }

    .nav-tabs {
      height: 40px;
      border-bottom: 0px
    }

    .card-box2 {
      background-color: #FFFFFF;
      border-radius: 8px 8px 0px 0px
    }

    .navbar-expand-lg {
      background-color: #191970;
      font-variant: normal;
    }

    .nav-link {
      color: #FFFFFF;
    }

    .container {
      max-width: 1000px;
      margin: 20px auto;
    }

    .title_1 {
      background-color: rgb(4, 153, 195);
      height: 40px;
      padding: 10px 0px 0px 10px;
      border-radius: 8px 8px 0px 0px
    }

    .title_1 span {
      color: #FFFFFF;
      font-weight: bold;
    }

    thead tr {
      background-color: rgb(4, 153, 195)
    }

    thead tr th {
      color: #FFFFFF;
      font-size: 11.5px;
      text-align: center;
    }

    tbody tr td {
      background-color: #FFFFFF;
      font-size: 13.5px;
      text-align: center;
      font-weight: bold;
    }

    .media-social {
      font-size: 18px;
      display: inline-block;
      background: #ffb727;
      color: #fff;
      line-height: 1;
      padding: 8px 0;
      margin-right: 4px;
      border-radius: 50%;
      text-align: center;
      width: 36px;
      height: 36px;
    }

    .media-social i {
      color: #FFF;
    }

    .copyright {
      font-size: 12px;
      color: #FFF;
      padding-top: 30px;
    }

    .tab_container_wrap input {
      position: absolute;
      width: 0;
      height: 0;
      margin: 0;
      z-index: -100;
      top: -1000px;
    }

    .tab_container_wrap input:checked+.tab_content_box {
      display: block;
    }

    .tab_content_box {
      background: #F5F5F5;
      padding: 20px;
      display: none;
    }

    .tab_content_box:nth-child(1) {
      background: #f0f0f0;

    }

    .tab_content_box:nth-child(2) {
      background: #f0f0f0;
    }


    .tab_content_box h2 {
      margin: 0 0 20px;
    }
  </style>
</head>

<body>
  <div>
    <header class="mb-3 border-bottom">
      <div class="container-fluid d-grid gap-3 align-items-center" style="grid-template-columns: 1fr 2fr;"><img src="<?php echo e(asset('taxcentre1.png')); ?>" alt="" srcset="">
        <div class="d-flex align-items-center">
          <form class="w-100 me-3">
          </form>
          <div class="flex-shrink-0 dropdown">
            <a href="#" class="d-block link-dark text-decoration-none dropdown-toggle" id="dropdownUser2" data-bs-toggle="dropdown" aria-expanded="false">
              <span>User &nbsp;</span><img src="https://github.com/mdo.png" alt="mdo" width="32" height="32" class="rounded-circle">
            </a>
            <ul class="dropdown-menu text-small shadow" aria-labelledby="dropdownUser2">
              <li><a class="dropdown-item" href="#">Logout</a></li>
            </ul>
          </div>
        </div>
      </div>
    </header>
    <div class="content">
      <div class="card-box">
        <nav class="card-tab">
          <div class="nav nav-tabs" id="nav-tab" role="tablist">
            <a style="border-radius: 2px 30px 2px 30px; height:40px; padding: 8px 20px; text-align: center;" href="<?php echo e(url('/arsipSPT')); ?>" class="nav-link active" type="button">Arsip SPT</a>
            <a style="border-radius: 2px 30px 2px 30px; height:40px; padding: 8px 20px; text-align: center;" href="<?php echo e(url('/buatSPT')); ?>" class="nav-link" type="button">Buat SPT</a>
            <div align="right" class="col-sm-8">
              <img src="<?php echo e(asset('form.jpg')); ?>" width="100px">
            </div>
          </div>
        </nav>
        <div class="card-box2">
          <div class="tab-content" id="nav-tabContent" style="margin-top: 20px;">
            <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
              <div class="table title_1">
                <span>
                  <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABcAAAAXCAYAAADgKtSgAAAABmJLR0QA/wD/AP+gvaeTAAABD0lEQVRIib3VMUvDQBjG8f+rCXUQFDengk6C0FGKq7tfQbr0q/gRRHBydHLXwSVbp3ZydHBx0E2qto9DFOS8nvcm1AeyvJf7vZccucASY2FB0hpwDGwk5s3M7MLdTdK5/s6rpANJuylrJVLbz1zHNnArqevBPekCd4saNMVL4Am4B2bAmaT18KbYhlZAP6PBzdf1nUczu0zOkFRlbGgsVWi1fefJFImxB+AjqG0Bm23xKXBKvVk/0wdO2uIdYMjvlQOMIkbPg78BVwvwmLHnwUvgyIGXHvyd+vFz8UMPXgA7DnzVg8+BZwc+9+AFMMiAk1nqF/rv+KShNQ4LsSO3Q/0PzT5DgBfg2symDRfmzydLjp+KLkhQbQAAAABJRU5ErkJggg==">
                  Daftar SPT
                </span>
              </div>
              <div style="padding: 0px 20px ;">
                <!-- <label class="mr-sm-2" for="inlineFormCustomSelect">Tampilkan</label> -->
                <!-- <input type="number" class="form-control" id="exampleFormControlInput1" placeholder="0" style="width: 15%; display: inline-block"> -->
                <!-- <label class="mr-sm-2" for="inlineFormCustomSelect">entri</label> -->
                <table id="example" class="table w-100 table-bordered table-hover">
                  <div style="padding: 10px;"></div>
                  <thead>
                    <tr>
                      <th>N0</th>
                      <th>JENIS SPT</th>
                      <th>TAHUN/MASA PAJAK</th>
                      <th>PEMBETULAN KE</th>
                      <th>STATUS</th>
                      <th>JUMLAH</th>
                      <th>SUMBER</th>
                      <th>AKSI</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <th scope="row">1</th>
                      <td>SPT 1770</td>
                      <td>2021/01-12</td>
                      <td>0</td>
                      <td>Nihil</td>
                      <td>0</td>
                      <td>E-Form 1770</td>
                      <td><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAABmJLR0QA/wD/AP+gvaeTAAAAkklEQVRIiWNgGAVkAGUGBoZnDAwM/0nEz6B6CYLNZBgOw5sIGe4KVfiJgYFBkhjXQIEYAwPDe6heT3wKL0MVFZNgOAwUQ/VeRhZkRFP0nwyDsQG4uUxUMhAnYCHkAhIBRggMmA/QAa64IejTQeMDcuOE9j4YtWDwWfAYSpNbXCObgRV4MDAwPKLAgkdQM0YB8QAAz9dJogjSQNkAAAAASUVORK5CYII=">
                      </td>
                    </tr>
                    <tr>
                      <th scope="row">2</th>
                      <td>SPT 1770</td>
                      <td>2020/01-12</td>
                      <td>0</td>
                      <td>Nihil</td>
                      <td>0</td>
                      <td>E-Form 1770</td>
                      <td><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAABmJLR0QA/wD/AP+gvaeTAAAAkklEQVRIiWNgGAVkAGUGBoZnDAwM/0nEz6B6CYLNZBgOw5sIGe4KVfiJgYFBkhjXQIEYAwPDe6heT3wKL0MVFZNgOAwUQ/VeRhZkRFP0nwyDsQG4uUxUMhAnYCHkAhIBRggMmA/QAa64IejTQeMDcuOE9j4YtWDwWfAYSpNbXCObgRV4MDAwPKLAgkdQM0YB8QAAz9dJogjSQNkAAAAASUVORK5CYII=">
                      </td>
                    </tr>
                    <tr>
                      <th>3</th>
                      <td>SPT 1770</td>
                      <td>2019/01-12</td>
                      <td>0</td>
                      <td>Nihil</td>
                      <td>0</td>
                      <td>E-Form 1770</td>
                      <td><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAABmJLR0QA/wD/AP+gvaeTAAAAkklEQVRIiWNgGAVkAGUGBoZnDAwM/0nEz6B6CYLNZBgOw5sIGe4KVfiJgYFBkhjXQIEYAwPDe6heT3wKL0MVFZNgOAwUQ/VeRhZkRFP0nwyDsQG4uUxUMhAnYCHkAhIBRggMmA/QAa64IejTQeMDcuOE9j4YtWDwWfAYSpNbXCObgRV4MDAwPKLAgkdQM0YB8QAAz9dJogjSQNkAAAAASUVORK5CYII=">
                      </td>
                    </tr>
                    <tr>
                      <th>4</th>
                      <td>SPT 1770</td>
                      <td>2019/01-12</td>
                      <td>0</td>
                      <td>Nihil</td>
                      <td>0</td>
                      <td>E-Form 1770</td>
                      <td><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAABmJLR0QA/wD/AP+gvaeTAAAAkklEQVRIiWNgGAVkAGUGBoZnDAwM/0nEz6B6CYLNZBgOw5sIGe4KVfiJgYFBkhjXQIEYAwPDe6heT3wKL0MVFZNgOAwUQ/VeRhZkRFP0nwyDsQG4uUxUMhAnYCHkAhIBRggMmA/QAa64IejTQeMDcuOE9j4YtWDwWfAYSpNbXCObgRV4MDAwPKLAgkdQM0YB8QAAz9dJogjSQNkAAAAASUVORK5CYII=">
                      </td>
                    </tr>
                    <tr>
                      <th>5</th>
                      <td>SPT 1770</td>
                      <td>2019/01-12</td>
                      <td>0</td>
                      <td>Nihil</td>
                      <td>0</td>
                      <td>E-Form 1770</td>
                      <td><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAABmJLR0QA/wD/AP+gvaeTAAAAkklEQVRIiWNgGAVkAGUGBoZnDAwM/0nEz6B6CYLNZBgOw5sIGe4KVfiJgYFBkhjXQIEYAwPDe6heT3wKL0MVFZNgOAwUQ/VeRhZkRFP0nwyDsQG4uUxUMhAnYCHkAhIBRggMmA/QAa64IejTQeMDcuOE9j4YtWDwWfAYSpNbXCObgRV4MDAwPKLAgkdQM0YB8QAAz9dJogjSQNkAAAAASUVORK5CYII=">
                      </td>
                    </tr>
                    <tr>
                      <th>6</th>
                      <td>SPT 1770</td>
                      <td>2019/01-12</td>
                      <td>0</td>
                      <td>Nihil</td>
                      <td>0</td>
                      <td>E-Form 1770</td>
                      <td><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAABmJLR0QA/wD/AP+gvaeTAAAAkklEQVRIiWNgGAVkAGUGBoZnDAwM/0nEz6B6CYLNZBgOw5sIGe4KVfiJgYFBkhjXQIEYAwPDe6heT3wKL0MVFZNgOAwUQ/VeRhZkRFP0nwyDsQG4uUxUMhAnYCHkAhIBRggMmA/QAa64IejTQeMDcuOE9j4YtWDwWfAYSpNbXCObgRV4MDAwPKLAgkdQM0YB8QAAz9dJogjSQNkAAAAASUVORK5CYII=">
                      </td>
                    </tr>
                    <tr>
                      <th>7</th>
                      <td>SPT 1770</td>
                      <td>2019/01-12</td>
                      <td>0</td>
                      <td>Nihil</td>
                      <td>0</td>
                      <td>E-Form 1770</td>
                      <td><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAABmJLR0QA/wD/AP+gvaeTAAAAkklEQVRIiWNgGAVkAGUGBoZnDAwM/0nEz6B6CYLNZBgOw5sIGe4KVfiJgYFBkhjXQIEYAwPDe6heT3wKL0MVFZNgOAwUQ/VeRhZkRFP0nwyDsQG4uUxUMhAnYCHkAhIBRggMmA/QAa64IejTQeMDcuOE9j4YtWDwWfAYSpNbXCObgRV4MDAwPKLAgkdQM0YB8QAAz9dJogjSQNkAAAAASUVORK5CYII=">
                      </td>
                    </tr>
                    <tr>
                      <th>8</th>
                      <td>SPT 1770</td>
                      <td>2019/01-12</td>
                      <td>0</td>
                      <td>Nihil</td>
                      <td>0</td>
                      <td>E-Form 1770</td>
                      <td><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAABmJLR0QA/wD/AP+gvaeTAAAAkklEQVRIiWNgGAVkAGUGBoZnDAwM/0nEz6B6CYLNZBgOw5sIGe4KVfiJgYFBkhjXQIEYAwPDe6heT3wKL0MVFZNgOAwUQ/VeRhZkRFP0nwyDsQG4uUxUMhAnYCHkAhIBRggMmA/QAa64IejTQeMDcuOE9j4YtWDwWfAYSpNbXCObgRV4MDAwPKLAgkdQM0YB8QAAz9dJogjSQNkAAAAASUVORK5CYII=">
                      </td>
                    </tr>
                    <tr>
                      <th>9</th>
                      <td>SPT 1770</td>
                      <td>2019/01-12</td>
                      <td>0</td>
                      <td>Nihil</td>
                      <td>0</td>
                      <td>E-Form 1770</td>
                      <td><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAABmJLR0QA/wD/AP+gvaeTAAAAkklEQVRIiWNgGAVkAGUGBoZnDAwM/0nEz6B6CYLNZBgOw5sIGe4KVfiJgYFBkhjXQIEYAwPDe6heT3wKL0MVFZNgOAwUQ/VeRhZkRFP0nwyDsQG4uUxUMhAnYCHkAhIBRggMmA/QAa64IejTQeMDcuOE9j4YtWDwWfAYSpNbXCObgRV4MDAwPKLAgkdQM0YB8QAAz9dJogjSQNkAAAAASUVORK5CYII=">
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <!-- <div style="display: flex; justify-content: space-between;">
                <div>
                  Menampilkan 1 sampai 2 dari 2 entri
                </div>
                <div>
                  <nav aria-label="Page navigation example">
                    <ul class="pagination justify-content-end">
                      <li class="page-item ">
                        <a class="page-link" style="background-color: rgb(255, 157, 49);" href="#" tabindex="-1" aria-disabled="true">
                          <span style="color: #FFFFFF;">Sebelumnya</span></a>
                      </li>
                      <li class="page-item"><a class="page-link" style="background-color: rgb(4, 153, 195);" href="#">
                          <span style="color: #FFFFFF;">1</span></a></li>
                      <li class="page-item"><a class="page-link" style="background-color: rgb(255, 157, 49);" href="#">
                          <span style="color: #FFFFFF;">2</span></a></li>
                      <li class="page-item">
                        <a class="page-link" style="background-color: rgb(4, 153, 195);" href="#" tabindex="-1" aria-disabled="true">
                          <span style="color: #FFFFFF;">Selanjutnya</span></a>
                      </li>
                    </ul>
                  </nav>
                </div>
              </div> -->
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>

  <div style="padding: 20px;"></div>
  <div class="shadow-sm " id="footer" style="background-color: rgba(0,0,0,0.7); height:auto">
    <div>
      <div align="center" class="col-sm-3">
        <img src="<?php echo e(asset('taxcentre.png')); ?>" alt="">
      </div>
      <div align="center" class="col-sm-4">
        <span style="color: #FFF;"> <i>Alamat</i> </span>
        <div align="left" class="col-sm-8">
          <span style="color: #FFF;"><i>Jl. Ahmad Yani Batam Kota. Kota Batam. <br> kepulauan Riau.
              Indonesia</i> </span>
        </div>
        <div align="left" class="col-sm-8">
          <span style="color: #FFF;"><i><br> Email : info@polibatam.ac.id <br>Phone : +62-778-469858 Ext.1017
              <br>Fax : +62-778-463620 <br>
              Email : info@polibatam.ac.id</i> </span>
        </div>
      </div>
      <div align="center" class="col-sm-12">
        <span style="color: #FFF; font-size: 36px; font-family:'Satisfy',serif;"> <i>Tax Center</i> </span>
      </div>
      <div align="center" class="col-sm-12">
        <span style="color: #FFF; font-size: 14px"> <i>Politeknik Negeri Batam</i> </span>
      </div>
    </div>
    <div align="center" class="col-sm-12" style="padding-top: 30px;">
      <div class="media-social">
        <a href=""><i class="fa-brands fa-twitter"></i></a>
      </div>
      <div class="media-social">
        <a href=""><i class="fa-brands fa-facebook-f"></i></a>
      </div>
      <div class="media-social">
        <a href=""><i class="fa-brands fa-instagram"></i></i></a>
      </div>
      <div class="media-social">
        <a href=""><i class="fa-brands fa-skype"></i></a>
      </div>
      <div class="media-social">
        <a href=""><i class="fa-brands fa-linkedin-in"></i></a>
      </div>
    </div>

    <div align="center" class="col-sm-12">
      <div class="copyright">
        <i class="fa-regular fa-copyright"></i> Copyright
        <strong>Polibatam Software Team</strong>
        All Rights Reserved
      </div>
    </div>

  </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
  </script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js" integrity="sha512-aVKKRRi/Q/YV+4mjoKBsE4x3H+BkegoM/em46NNlCqNTmUYADjBbeNefNxYV7giUp0VxICtqdrbqU7iVaeZNXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
  <!-- <script src="//cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script> -->
  <script src="http://kp.bkd.sidoarjokab.go.id/website/lib/DataTables-1.10.7/media/js/jquery.dataTables.js"></script>
  <script src="https://cdn.datatables.net/1.13.1/js/dataTables.bootstrap5.min.js"></script>
  <script>
    $(document).ready(function() {
      $('#example').DataTable();
    });
  </script>
  <script>
    function nav() {
      document.getElementById("nav-home-tab").classList.toggle("active");;
    }
  </script>
</body>



</html><?php /**PATH C:\xampp\htdocs\E-Form\resources\views/arsipSPT.blade.php ENDPATH**/ ?>