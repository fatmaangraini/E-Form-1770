<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js" integrity="sha512-aVKKRRi/Q/YV+4mjoKBsE4x3H+BkegoM/em46NNlCqNTmUYADjBbeNefNxYV7giUp0VxICtqdrbqU7iVaeZNXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <title>Formulir 1770-II</title>
    <style>
        .bg-grey {
            font-family: arial;
            background-color: #ccc;
        }

        .vericaltext {
            writing-mode: vertical-lr;
            text-orientation: use-glyph-orientation;
        }

        .year {
            border: 1px solid black;
            width: 20px;
            font-size: 25px;
        }

        table tr th {
            border: 1px solid black;
            font-size: 25px;
        }
    </style>
</head>

<body class="bg-grey" style="padding: 1% 10% 1% 10%">
    <div class="container" style="width : 90%; background-color: #fff">
        <div class="row" style="border-bottom: 2px solid black;">
            <div class="col-2" style="padding: 50px 0px 10px 10px">
                <h1 style="font-size: 20px; font-weight: bold; text-align: center; margin-top: -10px">FORMULIR</h1>
                <h1 style="font-size: 40px; font-weight: bold; text-align: center; margin-top: 30px">1770-II</h1>
                <p style="font-size: 10px; font-weight: bold; text-align: center; margin-top: 30px">KEMENTERIAN KEUANGAN RI DIREKTORAT JENDERAL PAJAK
                </p>
            </div>
            <div class="col-6" style="border-left: 2px solid black; border-right:2px solid black;">
                <div class="row">
                    <b style="font-size: 18px; text-align: center;">LAMPIRAN-II</b>
                    <p style=" font-size: 18px; font-weight: bold;  text-align: center; border-bottom: 2px solid black">
                        SPT TAHUNAN PPh WAJIB PAJAK ORANG PRIBADI</p>
                </div>
                <div class="row" style="font-size: 12px; text-align: center">
                    <b>DAFTAR PEMOTONGAN PEMUNGUTAN PPh OLEH PIHAK LAIN,</b>
                    <b>PPh YANG DIBAYAR/DIPOTONG DI LUAR NEGERI DAN</b>
                    <b>PPh DITANGGUNG PEMERINTAH</b>
                </div>
            </div>


            <div class="col-4" style="padding: 10px 10px 10px 10px">
                <!-- <b class="vericaltext fs-7">
                    TAHUN PAJAK
                </b> -->
                <form action="/formulir-I">
                    <input type="hidden" name="hasil" value="<?php echo e(request()->all()['hasil'] ?? 0); ?>">
                    <a href="/formulir-III" class="btn btn-secondary" style="font-size: 12px; width: 120px; height: 30px; margin-left: 10px">Sebelumnya</a>
                    <button class="btn btn-secondary" style="font-size: 12px; width: 120px; height: 30px; margin-left: 10px">Selanjutnya</button>

                    <div class="row" style="padding: 4% 10%;">
                        <div class="col">
                            <table>
                                <tr>
                                    <th style="text-align: center" width="60px"><?php echo e(mb_substr($spt['tahun'], 0, 1)); ?></th>
                                    <th style="text-align: center" width="60px"><?php echo e(mb_substr($spt['tahun'], 1, 1)); ?></th>
                                    <th style="text-align: center" width="60px"><?php echo e(mb_substr($spt['tahun'], 2, 1)); ?></th>
                                    <th style="text-align: center" width="60px"><?php echo e(mb_substr($spt['tahun'], 3, 1)); ?></th>
                                </tr>
                            </table>
                        </div>
                    </div>
                    <div class="row" style="padding: 1% 10%;">
                        <div class="col-4">
                            <table>
                                <tr>
                                    <th>0</th>
                                    <th>1</th>
                                    <th><?php echo e(mb_substr($spt['tahun'], 2, 1)); ?></th>
                                    <th><?php echo e(mb_substr($spt['tahun'], 3, 1)); ?></th>
                                </tr>
                            </table>
                        </div>
                        <div class="col-2">
                            <p style="margin: 15px;">sd</p>
                        </div>
                        <div class="col-4">
                            <table>
                                <tr>
                                    <th>1</th>
                                    <th>2</th>
                                    <th><?php echo e(mb_substr($spt['tahun'], 2, 1)); ?></th>
                                    <th><?php echo e(mb_substr($spt['tahun'], 3, 1)); ?></th>
                                </tr>
                            </table>
                        </div>
                    </div>

                    <div class="form-check" style="display:inline-block; margin-left: 10px">
                        <input style="display:inline;" class="form-check-input" type="radio" name="flexRadioDisabled" id="flexRadioDisabled">
                        <label class="form-check-label" for="flexRadioDisabled" style="font-size: 14px;">
                            Pembukuan
                        </label>
                    </div>
                    <div class="form-check" style="display:inline-block; margin-left: 10px">
                        <input class="form-check-input" type="radio" name="flexRadioDisabled" id="flexRadioCheckedDisabled" checked>
                        <label class="form-check-label" for="flexRadioCheckedDisabled" style="font-size: 14px;">
                            Pencatatan
                        </label>
                    </div>
                    <div class="col-sm-12" style="background-color: #F0E68C ; padding: 4px 10px 10px 10px ; height: 30PX">
                        <div class="input-group mb-6">
                            <div class="input-group-prepend">
                                <div style="margin-left: -11px">
                                    <input type="checkbox" aria-label="Checkbox for following text input" style="width: 20px;">
                                </div>
                            </div>
                            <label class="col-sm-9" style="font-size: 11px; text-align: center">SPT Pembetulan Ke</label>
                            <input style="width:20px; height: 20px; border: 1px solid;">
                        </div>
                    </div>
            </div>
        </div>
        <b style="font-size: 10px;">PERHATIAN *SEBELUM MENGISI BACALAH PETUNJUK PENGISIAN *ISI DENGAN HURU CETAK/DIKETIK DENGAN TINTA HITAM *BERI TANDA X DALAM KOTAK SESUAI PILIHAN</b>
        <div class="col-sm-11.5" style=" border: 1px solid black; background-color: #F0E68C ; padding: 4px 20px 10px 10px ; height: 80px; border: 2px solid; margin-left: 10px">
            <div class="row">
                <label class="col-sm-4 col-form-label" style="font-size: 12px;">NPWP</label>
                <div class="col-sm-8">
                    <input class="form-control" type="text" style="border: 1px solid black; height: 30px; border-radius: 1px; " value="<?php echo e($npwp); ?>" disabled="disabled" id="npwpWP">
                </div>
            </div>
            <div class="row">
                <label class="col-sm-4 col-form-label" style="font-size: 12px;">NAMA WAJIB PAJAK</label>
                <div class="col-sm-8">
                    <input class="form-control" type="text" style="border: 1px solid black; height: 30px; border-radius: 1px;" value="<?php echo e($nama); ?>" disabled="disabled">
                </div>
            </div>
        </div>
        </form>


        <p style="font-size: 11px; padding: 10px 0px 0px 0px">BAGIAN A : DAFTAR PEMOTONGAN/PEMUNGUTAN PPh OLEH PIHAK LAIN,
            PPh YANG DIBAYAR/DIPOTONG DI LUAR NEGERI DAN PPh DITANGGUNG PEMERINTAH</p>
        <button type="button" data-bs-toggle="modal" data-bs-target="#exampleModal" data-bs-whatever="@mdo">Import Data</button>
        <form action="/SaveDataPotongPungut" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="counted" value="<?php echo e(count($data_potong_pungut)); ?>">
            <table id="BagianA" class="display">
                <tr>
                    <th style="border: 1px solid black; font-size: 11px; font-weight: bold; text-align: center; width: 5%; height: 30px">
                        <br>NO <br> <br>(1)
                    </th>
                    <th style="border: 1px solid black; font-size: 11px; font-weight: bold; text-align: center; width: 15%">
                        NAMA</br>PEMOTONG/</br>PEMUNGUT PAJAK <br> (2)</th>
                    <th style="border: 1px solid black; font-size: 11px; font-weight: bold; text-align: center; width: 25%">
                        NPWP</br>PEMOTONG/</br>PEMUNGUT PAJAK <br>(3)</th>
                    <th style="border: 1px solid black; font-size: 11px; font-weight: bold; text-align: center; width: 15%">
                        NOMOR</br>BUKTI</br>PEMOTONGAN <br>(4)</th>
                    <th style="border: 1px solid black; font-size: 11px; font-weight: bold; text-align: center; width: 10%">
                        TANGGAL</br>BUKTI</br>PEMOTONGAN <br>(5)</th>
                    <th style="border: 1px solid black; font-size: 11px; font-weight: bold; text-align: center; width: 15%">
                        JENIS PAJAK :</br>PPh PASAL</br>21/22/23/26DTP <br>(6)</th>
                    <th style="border: 1px solid black; font-size: 11px; font-weight: bold; text-align: center; width: 20%">
                        JUMLAH PPh</br>YANG DIPOTONG/</br>DIPUNGUT <br>(7)</th>
                </tr>
                <?php if(count($data_potong_pungut) == 0): ?>
                <tr>
                    <td style="border: 1px solid black; width: 5%; text-align:center">1</td>
                    <td style="border: 1px solid black"><input name="nama_pemotong[]" type="text" class="form-control" style="border: 1px solid white; width: 100%; text-transform:uppercase"></td>
                    <td style="border: 1px solid black;"><input name="npwp_pemotong[]" type="text" class="form-control" style="border: 1px solid white; width: 100%" maxlength="20" oninput="formatNpwp(this)" id="formatnpwp"></td>
                    <td style="border: 1px solid black;"><input name="nomor_bupot[]" type="text" class="form-control" style="border: 1px solid white; width: 100%; text-transform:uppercase"></td>
                    <td style="border: 1px solid black;"><input name="tgl_bupot[]" type="date" class="form-control" style="border: 1px solid white; width: 100%"></td>
                    <td style="border: 1px solid black;"><select name='jenis_pajak[]' style="width:100%; height:30px; border: 1px solid white">
                            <option value='pilih'>Pilih...</option>
                            <option value='21'>Pasal 21</option>
                            <option value='22'>Pasal 22</option>
                            <option value='23'>Pasal 23</option>
                            <option value='24'>Pasal 24</option>
                            <option value='26'>Pasal 26</option>
                            <option value='DTP'>Pasal DTP</option>
                        </select> </td>
                    <td style="border: 1px solid black;"><input name="jumlahPPh_potong[]" class="jumlahpph" type="text" class="form-control" style="border: 1px solid white; width: 100%; text-align: right" oninput="formatJmlPPhDipotongDipungut(this.value)" name="jumlahPPh" placeholder="0"></td>
                </tr>
                <?php endif; ?>
                <tbody>
                    <?php $i = 0; ?>
                    <?php $__currentLoopData = $data_potong_pungut; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="border: 1px solid black; width: 5%; text-align:center"><?= $i += 1 ?></td>
                        <td style="border: 1px solid black"><input name="nama_pemotong[]" type="text" class="form-control" value="<?php echo e($dh['nama_pemotong']); ?>" style="border: 1px solid white; width: 100%; text-transform:uppercase"></td>
                        <td style="border: 1px solid black;"><input name="npwp_pemotong[]" type="text" class="form-control" value="<?php echo e($dh['npwp_pemotong']); ?>" style="border: 1px solid white; width: 100%" maxlength="20" oninput="formatNpwp(this)" id="formatnpwp"></td>
                        <td style="border: 1px solid black;"><input name="nomor_bupot[]" type="text" class="form-control" value="<?php echo e($dh['nomor_bupot']); ?>" style="border: 1px solid white; width: 100%; text-transform:uppercase"></td>
                        <td style="border: 1px solid black;"><input name="tgl_bupot[]" type="date" class="form-control" value="<?php echo e($dh['tgl_bupot']); ?>" style="border: 1px solid white; width: 100%"></td>
                        <td style="border: 1px solid black;"><select name='jenis_pajak[]' style="width:100%; height:30px; border: 1px solid white">
                                <option value='pilih'>Pilih...</option>
                                <option value='21' <?php if($dh['jenis_pajak']=="21" ): ?> selected="selected" <?php endif; ?>>Pasal 21</option>
                                <option value='22' <?php if($dh['jenis_pajak']=="22" ): ?> selected="selected" <?php endif; ?>>Pasal 22</option>
                                <option value='23' <?php if($dh['jenis_pajak']=="23" ): ?> selected="selected" <?php endif; ?>>Pasal 23</option>
                                <option value='24' <?php if($dh['jenis_pajak']=="24" ): ?> selected="selected" <?php endif; ?>>Pasal 24</option>
                                <option value='26' <?php if($dh['jenis_pajak']=="26" ): ?> selected="selected" <?php endif; ?>>Pasal 26</option>
                                <option value='DTP' <?php if($dh['jenis_pajak']=="DTP" ): ?> selected="selected" <?php endif; ?>>Pasal DTP</option>
                            </select> </td>
                        <td style="border: 1px solid black;"><input name="jumlahPPh_potong[]" class="jumlahpph" type="text" class="form-control" value="<?php echo e($dh['jumlahPPh_potong']); ?>" style="border: 1px solid white; width: 100%; text-align: right" oninput="formatJmlPPhDipotongDipungut(this.value)" name="jumlahPPh" id="jumlahPPh" placeholder="0"></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div style="padding: 10px;"></div>
            <table>
                <tr>
                    <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 670px;  height: 30px">
                        JUMLAH BAGIAN A</th>

                    <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 400px; background-color: #F0E68C">
                        <input type="text" class="form-control" readonly="readonly" style="background-color: #F0E68C; text-align: right; border: 1px solid white" name="hasilPPhDipotongDipungut" id="hasilPPhDipotongDipungut">
                    </th>
                </tr>
            </table>
            <button type="button" onclick="addTableBagianA(this)">Tambah</button>
            <button type="button" onclick="deleteTableBagianA('BagianA')">Hapus</button>
            <button type="submit">Simpan</button>

            <template id="rowTemplateBagianA">
                <tr>
                    <td style="border: 1px solid black; width: 5%; text-align:center"><span id="nomortemplate"></span></td>
                    <td style="border: 1px solid black"><input name="nama_pemotong[]" type="text" class="form-control" style="border: 1px solid white; width: 100%; text-transform:uppercase"></td>
                    <td style="border: 1px solid black;"><input name="npwp_pemotong[]" type="text" class="form-control" style="border: 1px solid white; width: 100%" maxlength="20" oninput="formatNpwp2(this)" id="formatnpwpfix"></td>
                    <td style="border: 1px solid black;"><input name="nomor_bupot[]" type="text" class="form-control" style="border: 1px solid white; width: 100%; text-transform:uppercase"></td>
                    <td style="border: 1px solid black;"><input name="tgl_bupot[]" type="date" class="form-control" style="border: 1px solid white; width: 100%"></td>
                    <td style="border: 1px solid black;"><select name='jenis_pajak[]' style="width:100%; height:30px; border: 1px solid white">
                            <option value='pilih'>Pilih...</option>
                            <option value='21'>Pasal 21</option>
                            <option value='22'>Pasal 22</option>
                            <option value='23'>Pasal 23</option>
                            <option value='24'>Pasal 24</option>
                            <option value='26'>Pasal 26</option>
                            <option value='DTP'>Pasal DTP</option>
                        </select> </td>
                    <td style="border: 1px solid black;"><input name="jumlahPPh_potong[]" class="jumlahpph" type="text" class="form-control" style="border: 1px solid white; width: 100%; text-align: right" oninput="formatJmlPPhDipotongDipungut(this.value)" name="jumlahPPh" id="jumlahPPh" placeholder="0"></td>
                </tr>
            </template>
        </form>


        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Import Data Daftar Pemotongan/Pemungutan</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="/DataPotongPungutImport" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="input-group mb-3">
                                <input type="file" name="file" class="form-control" accept=".csv">
                                <button class="btn btn-primary" type="submit">Submit</button>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>


    </div>
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
    <!-- <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous">
    </script> -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
    </script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/numeral.js/2.0.6/numeral.min.js"></script>

    <script>
        let nomor = 0;
        $(document).ready(function() {
            nomor = <?= count($data_potong_pungut) ?>;
            $("#nomortemplate").html(nomor + 1)
            formatJmlPPhDipotongDipungut();
            npwpWP();
        });
        let tr = 0;
        let counted = 0


        function addTableBagianA($this) {
            var countdata = <?= count($data_potong_pungut) ?>,
                template = document.querySelector('#rowTemplateBagianA'),
                tbl = document.querySelector('#BagianA'),
                td_choice = template.content.querySelectorAll("td"),
                last_td = $('#BagianA tr:last'),
                tr_count = tbl.rows.length;

            var nama_pemotong = last_td.find('td:eq(1)').find('input').val()
            var npwp_pemotong = last_td.find('td:eq(2)').find('input').val();
            var nomor_bupot = last_td.find('td:eq(3)').find('input').val();
            var tgl_bupot = last_td.find('td:eq(4)').find('input').val();
            var jenis_pajak = last_td.find('td:eq(5)').find('option:selected').val();
            var jumlahPPh_potong = last_td.find('td:eq(6)').find('input').val();

            var data = {
                nama_pemotong: nama_pemotong,
                npwp_pemotong: npwp_pemotong,
                nomor_bupot: nomor_bupot,
                tgl_bupot: tgl_bupot,
                jenis_pajak: jenis_pajak,
                jumlahPPh_potong: jumlahPPh_potong

            }
            console.log(data);
            if (nama_pemotong === '' || npwp_pemotong === '' || nomor_bupot === '' || tgl_bupot === '' || jenis_pajak === 'pilih' || jumlahPPh_potong === '') {

                alert('isi dulu datanya');
                return
            }
            if (counted == 0 && countdata > 0) {
                td_choice.textContent = tr_count;
                var clone = document.importNode(template.content, true);
                tbl.appendChild(clone);
                formatJmlPPhDipotongDipungut();
                nomor += 1
                $("#nomortemplate").html(nomor)

                counted += 1
                return
            }
            var data = {
                nama_pemotong: nama_pemotong,
                npwp_pemotong: npwp_pemotong,
                nomor_bupot: nomor_bupot,
                tgl_bupot: tgl_bupot,
                jenis_pajak: jenis_pajak,
                jumlahPPh_potong: jumlahPPh_potong

            }

            td_choice.textContent = tr_count;
            var clone = document.importNode(template.content, true);
            tbl.appendChild(clone);
            formatJmlPPhDipotongDipungut();
            nomor += 1
            $("#nomortemplate").html(nomor)

        }
        // function addTableBagianA($this) {
        //     var template = document.querySelector('#rowTemplateBagianA'),
        //         tbl = document.querySelector('#BagianA'),
        //         td_choice = template.content.querySelectorAll("td")[0],
        //         tr_count = tbl.rows.length;

        //     td_choice.textContent = tr_count;
        //     var clone = document.importNode(template.content, true);
        //     tbl.appendChild(clone);
        //     formatJmlPPhDipotongDipungut();
        // }


        function deleteTableBagianA(nama) {

            let tr_length = $('#' + nama + ' tr').length;

            if (tr_length == 2) {
                $.ajax({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    type: "POST",
                    url: 'http://localhost:8000/DataPotongPungut/delete',
                    success: function(res) {
                        $('#' + nama + ' tr:last').remove();
                        var countdata = <?= count($data_potong_pungut) ?>,
                            template = document.querySelector('#rowTemplateBagianA'),
                            tbl = document.querySelector('#BagianA'),
                            td_choice = template.content.querySelectorAll("td"),
                            last_td = $('#BagianA tr:last'),
                            tr_count = tbl.rows.length;
                        td_choice.textContent = tr_count;
                        var clone = document.importNode(template.content, true);
                        tbl.appendChild(clone);
                        formatJmlPPhDipotongDipungut();
                    }
                });
            }
            if (tr_length > 2) {
                $.ajax({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    type: "POST",
                    url: 'http://localhost:8000/DataPotongPungut/delete',
                    success: function(res) {
                        $('#' + nama + ' tr:last').remove();
                        formatJmlPPhDipotongDipungut();
                    }
                });
            }
            counted -= 1;
            formatJmlPPhDipotongDipungut();
        }
        // function deleteTableBagianA(nama) {

        //     let tr_length = $('#' + nama + ' tr').length;

        //     if (tr_length > 2) {
        //         $('#' + nama + ' tr:last').remove();
        //     }
        //     formatJmlPPhDipotongDipungut();
        // }
        // function myFunction($this) {
        //     var tableBody = $('#mytable');
        //     var trs = document.getElementById("table");

        //     if (tr === 0) {
        //         tr += 1;
        //         // alert('a');
        //         trs.style.display = 'revert';
        //         return 0;
        //     }
        //     trLast = tableBody.find("tr:last");
        //     trNew = trLast.clone();
        //     tr += 1;
        //     trLast.after(trNew);
        //     format();
        // }

        // function deleteTable($this) {
        //     var tableBody = $('#mytable');
        //     var trs = document.getElementById("table");

        //     console.log(tableBody);
        //     if (tr === 1) {
        //         tr -= 1;
        //         // alert('a');
        //         trs.style.display = 'none';
        //         return 0;
        //     }
        //     trLast = tableBody.find("tr:last");
        //     if (tr > 1) {
        //         tr -= 1;
        //         trLast.remove();
        //     }
        // }
    </script>
    <script>
        let sum = 0;
        let tmp = 0;

        function formatJmlPPhDipotongDipungut() {
            $('.jumlahpph').each(function() {
                if (this.value.length > 0 && this.value != 0) {
                    tmp2 = getNumPrice(this.value, '.');
                    this.value = numeral(this.value).format();
                    tmp += parseFloat(tmp2)
                } else {
                    tmp += 0
                }
            });
            sum = tmp
            console.log(sum)
            $('#hasilPPhDipotongDipungut').val(numeral(sum).format());
            tmp = 0;
        }

        function getNumPrice(price, decimalpoint) {
            var p = price.split(decimalpoint);
            for (var i = 0; i < p.length; i++) p[i] = p[i].replace(/\D/g, '');
            return p.join('.');
        }

        function formatNpwp(event) {
            console.log(event.value)
            formatnpwp = event.value
            formatnpwp2 = event
            if (!formatnpwp.match(/^[0-9./-]+$/i)) {
                alert('Angka saja')
                formatnpwp2.value = formatnpwp.slice(0, -1);
                return;
            }
            formatnpwp2.value = formatnpwp.replace(/(\d{2})(\d{3})(\d{3})(\d{1})(\d{3})(\d{3})/, '$1.$2.$3.$4-$5.$6');
        }

        // function formatNpwp2(event) {
        //     tmp = event.value
        //     if (typeof formatnpwp === 'string') {

        //     }
        //     event.value = tmp.replace(/(\d{2})(\d{3})(\d{3})(\d{1})(\d{3})(\d{3})/, '$1.$2.$3.$4-$5.$6');
        // }

        function formatNpwp2(event) {
            formatnpwp = event.value
            formatnpwp2 = event
            if (!formatnpwp.match(/^[0-9./-]+$/i)) {
                alert('Angka saja')
                formatnpwp2.value = formatnpwp.slice(0, -1);
                return;
            }
            formatnpwp2.value = formatnpwp.replace(/(\d{2})(\d{3})(\d{3})(\d{1})(\d{3})(\d{3})/, '$1.$2.$3.$4-$5.$6');
        }

        function npwpWP() {
                npwpWP = document.getElementById('npwpWP').value
                npwpWP2 = document.getElementById('npwpWP')
                if (typeof npwpWP === 'string') {

                }
                npwpWP2.value = npwpWP.replace(/(\d{2})(\d{3})(\d{3})(\d{1})(\d{3})(\d{3})/, '$1.$2.$3.$4-$5.$6');
            }
    </script>
    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"
        integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"
        integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous">
    </script>
    -->
</body>

</html><?php /**PATH C:\xampp\htdocs\E-Form\resources\views/formulir-II.blade.php ENDPATH**/ ?>