<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Formulir-III</title>
    <style>
        .bg-grey {
            font-family: arial;
            background-color: #ccc;
        }

        .vericaltext {
            writing-mode: vertical-lr;
            text-orientation: use-glyph-orientation;
        }

        .year {
            border: 1px solid black;
            width: 20px;
            font-size: 25px;
        }

        table tr th {
            border: 1px solid black;
            font-size: 25px;
        }
    </style>
</head>

<body class="bg-grey" style="padding: 1% 10% 1% 10%">
    <div class="container" style="width : 100%; background-color: #fff; overflow:auto">
        <div class="row" style="border-bottom: 2px solid black;">
            <div class="col-2" style="padding: 50px 0px 10px 10px">
                <h1 style="font-size: 20px; font-weight: bold; text-align: center;">FORMULIR</h1>
                <h1 style="font-size: 40px; font-weight: bold; text-align: center; margin-top: 30px">1770-III</h1>
                <p style="font-size: 10px; font-weight: bold; text-align: center; margin-top: 30px">KEMENTERIAN KEUANGAN RI DIREKTORAT JENDERAL PAJAK
                </p>
            </div>
            <div class="col-6" style="border-left: 2px solid black; border-right:2px solid black;">
                <div class="row">
                    <b style="font-size: 18px; text-align: center;">LAMPIRAN-III</b>
                    <p style=" font-size: 18px; font-weight: bold;  text-align: center; border-bottom: 2px solid black">
                        SPT TAHUNAN PPh WAJIB PAJAK ORANG PRIBADI</p>
                </div>
                <div class="row" style="font-size: 11px;">
                    <b>* PENGHASILAN YANG DIKENAKAN PAJAK FINAL DAN/ATAU BERSIFAT FINAL</b>
                    <b>* PENGHASILAN YANG TIDAK TERMASUK OBJEK PAJAK</b>
                    <b>* PENGHASILAN ISTERI/SUAMI YNG DIKENAKAN PAJAK SECARA TERPISAH</b>
                </div>
            </div>


            <div class="col-4" style="padding: 10px 10px 10px 10px">
                <!-- <b class="vericaltext fs-7">
                    TAHUN PAJAK
                </b> -->
                <a href="/formulir-III" class="btn btn-secondary" style="font-size: 12px; width: 120px; height: 30px; margin-left: 10px">Sebelumnya</a>
                <a href="/formulir-II" class="btn btn-secondary" style="font-size: 12px; width: 120px; height: 30px; margin-left: 10px">Selanjutnya</a>

                <div class="row" style="padding: 4% 10%;">
                    <div class="col">
                        <table>
                            <tr>
                                <th style="text-align: center" width="60px">2</th>
                                <th style="text-align: center" width="60px">2</th>
                                <th style="text-align: center" width="60px">2</th>
                                <th style="text-align: center" width="60px">2</th>
                            </tr>
                        </table>
                    </div>
                </div>
                <div class="row" style="padding: 1% 10%;">
                    <div class="col-4">
                        <table>
                            <tr>
                                <th>2</th>
                                <th>2</th>
                                <th>2</th>
                                <th>2</th>
                            </tr>
                        </table>
                    </div>
                    <div class="col-2">
                        <p style="margin: 15px;">sd</p>
                    </div>
                    <div class="col-4">
                        <table>
                            <tr>
                                <th>2</th>
                                <th>2</th>
                                <th>2</th>
                                <th>2</th>
                            </tr>
                        </table>
                    </div>
                </div>

                <div class="form-check" style="display:inline-block; margin-left: 10px">
                    <input style="display:inline;" class="form-check-input" type="radio" name="flexRadioDisabled" id="flexRadioDisabled">
                    <label class="form-check-label" for="flexRadioDisabled" style="font-size: 14px;">
                        Pembukuan
                    </label>
                </div>
                <div class="form-check" style="display:inline-block; margin-left: 10px">
                    <input class="form-check-input" type="radio" name="flexRadioDisabled" id="flexRadioCheckedDisabled">
                    <label class="form-check-label" for="flexRadioCheckedDisabled" style="font-size: 14px;">
                        Pencatatan
                    </label>
                </div>
                <div class="row" style="background-color: #F0E68C ; padding: 4px 10px 10px 10px ; height: 40PX; width: 270px; margin-left: 10px">
                    <div class="input-group mb-6">
                        <div class="input-group-prepend">
                            <div style="margin-left: -11px">
                                <input type="checkbox" aria-label="Checkbox for following text input" style="width: 20px;">
                            </div>
                        </div>
                        <label style="margin-left: 10px">SPT Pembetulan Ke</label>
                        <input class="col-lg-3" style="width:30px; margin-left: 20px; border: 1px solid;">

                    </div>
                </div>
            </div>
        </div>
        <div class="row" style="font-size: 12px; font-weight: bold; text-align:center">
            <b>DAFTAR JUMLAH PENGHASILAN BRUTO DAN PEMBAYARAN PPh FINAL BERDASARKAN PP 46 TAHUN 2013 DAN ATAU PP 23 TAHUN 2018</b>
            <b>PER MASA PAJAK SERTA DARI MASING-MASING TEMPAT USAHA</b>
        </div>
        <div style="padding: 5px;"></div>
        <div class="row" style="background-color: #F0E68C; padding: 4px 20px 10px 20px; width: 1030px; height: 100PX; border: 2px solid; margin-left: 10px">
            NPWP<input type="text" style="width: 700px; margin-left: 150px" placeholder="otomatis dari login">
            NAMA WAJIB PAJAK<input type="text" style="width: 700px; margin-left: 46px" placeholder="otomatis dari login">
            <div>
                ALAMAT<input type="text" style="width: 700px; margin-left: 125px;" placeholder="Masukkan alamat">
            </div>
        </div>
        <div style="padding: 10px;"></div>
        <table id="mytable" class="display" style="width:100%">
            <tr>
                <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 200px;  height: 30px">
                    NPWP</th>
                <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 200px">
                    MASA PAJAK</th>
                <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 200px">
                    ALAMAT</th>
                <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 200px">
                    PEREDARAN BRUTO</th>
                <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 200px">
                    JUMLAH PPh FINAL YANG DIBAYAR</th>
            </tr>
            <tr>
                <td><input type="text" style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 101.5%; height: 30px; margin-left: -1px; margin-top: -2px"></td>
                <td><input type="text" style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 102%; height: 30px; margin-left: -2px; margin-top: -2px"></td>
                <td><input type="text" style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 101.4%; height: 30px; margin-left: -1px; margin-top: -2px"></td>
                <td><input type="text" style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 101.6%; height: 30px; margin-left: -2px; margin-top: -2px"></td>
                <td><input type="text" style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 101%; height: 30px; margin-left: -1px; margin-top: -2px"></td>
            </tr>
            </br>
        </table>
        <div style="padding: 10px;"></div>
        <table>
            <tr>
                <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 670px;  height: 30px">PEREDARAN BRUTO</th>
                <th style="background-color: #F0E68C; border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 400px"></th>
                <th style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 400px">JUMLAH PPh FINAL YANG DIBAYAR</th>
                <th style="background-color: #F0E68C; border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 400px"></th>
            </tr>
        </table>
        <button type="button" onclick="myFunction(this)">Tambah</button>
        <button type="button" onclick="deleteTable(this)">Hapus</button>
    </div>
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
    </script>
    <script>
        let tr = 1;
        let tr2 = 1;
        let tr3 = 1;

        function myFunction($this) {
            var tableBody = $('#mytable');
            trLast = tableBody.find("tr:last");
            trNew = trLast.clone();
            tr += 1;
            trLast.after(trNew);
        }

        function deleteTable($this) {
            var tableBody = $('#mytable');
            trLast = tableBody.find("tr:last");
            console.log(tableBody);
            if (tr > 1) {
                trLast.remove();
            }
        }
    </script>
</body>

</html><?php /**PATH C:\xampp\htdocs\E-Form\resources\views/PP46.blade.php ENDPATH**/ ?>