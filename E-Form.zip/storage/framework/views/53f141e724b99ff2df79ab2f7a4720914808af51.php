<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Formulir-IV</title>
    <style>
        .bg-grey {
            font-family: arial;
            background-color: #ccc;
        }

        .vericaltext {
            writing-mode: vertical-lr;
            text-orientation: use-glyph-orientation;
        }

        .year {
            border: 1px solid black;
            width: 20px;
            font-size: 25px;
        }

        table tr th {
            border: 1px solid black;
            font-size: 25px;
        }
    </style>
</head>

<body class="bg-grey" style="padding: 1% 10% 1% 10%">
    <div class="container " style="width : 90%; background-color: #fff;">
        <div class="row" style="border-bottom: 2px solid black;">
            <div class="col-2" style="padding: 50px 0px 10px 10px">
                <h1 style="font-size: 20px; font-weight: bold; text-align: center;">FORMULIR</h1>
                <h1 style="font-size: 40px; font-weight: bold; text-align: center; margin-top: 30px">1770-IV</h1>
                <p style="font-size: 10px; font-weight: bold; text-align: center; margin-top: 30px">KEMENTERIAN KEUANGAN
                    RI DIREKTORAT JENDERAL PAJAK
                </p>
            </div>
            <div class="col-6" style="border-left: 2px solid black; border-right:2px solid black;">
                <div class="row">
                    <b style="font-size: 18px; text-align: center;">LAMPIRAN-IV</b>
                    <p style=" font-size: 18px; font-weight: bold;  text-align: center; border-bottom: 2px solid black">
                        SPT TAHUNAN PPh WAJIB PAJAK ORANG PRIBADI</p>
                </div>
                <div class="row">
                    <b style="font-size: 12px;">* HARTA PADA AKHIR TAHUN</b>
                    <b style="font-size: 12px;">* KEWAJIBAN/UTANG PADA AKHIR TAHUN</b>
                    <b style="font-size: 12px;">* DAFTAR SUSUNAN ANGGOTA KELUARGA</b>
                </div>
            </div>

            <div class="col-4" style="padding: 10px 10px 10px 10px">
                <!-- <b class="vericaltext fs-7">
                    TAHUN PAJAK
                </b> -->
                <a href="/formulir-III" class="btn btn-secondary"
                    style="font-size: 12px; width: 120px; height: 30px; margin-left: 150px">Selanjutnya</a>
                <div class="row" style="padding: 4% 10%;">
                    <div class="col">
                        <table>
                            <tr>
                                <th style="text-align: center" width="60px">2</th>
                                <th style="text-align: center" width="60px">2</th>
                                <th style="text-align: center" width="60px">2</th>
                                <th style="text-align: center" width="60px">2</th>
                            </tr>
                        </table>
                    </div>
                </div>
                <div class="row" style="padding: 1% 10%;">
                    <div class="col-4">
                        <table>
                            <tr>
                                <th>2</th>
                                <th>2</th>
                                <th>2</th>
                                <th>2</th>
                            </tr>
                        </table>
                    </div>
                    <div class="col-2">
                        <p style="margin: 15px;">sd</p>
                    </div>
                    <div class="col-4">
                        <table>
                            <tr>
                                <th>2</th>
                                <th>2</th>
                                <th>2</th>
                                <th>2</th>
                            </tr>
                        </table>
                    </div>
                </div>

                <div class="form-check" style="display:inline-block; margin-left: 10px">
                    <input style="display:inline;" class="form-check-input" type="radio" name="flexRadioDisabled"
                        id="flexRadioDisabled">
                    <label class="form-check-label" for="flexRadioDisabled" style="font-size: 14px;">
                        Pembukuan
                    </label>
                </div>
                <div class="form-check" style="display:inline-block; margin-left: 10px">
                    <input class="form-check-input" type="radio" name="flexRadioDisabled"
                        id="flexRadioCheckedDisabled">
                    <label class="form-check-label" for="flexRadioCheckedDisabled" style="font-size: 14px;">
                        Pencatatan
                    </label>
                </div>
                <div class="col-sm-12" style="background-color: #F0E68C ; padding: 4px 10px 10px 10px ; height: 30PX">
                    <div class="input-group mb-6">
                        <div class="input-group-prepend">
                            <div style="margin-left: -11px">
                                <input type="checkbox" aria-label="Checkbox for following text input" style="width: 20px;">
                            </div>
                        </div>
                        <label class="col-sm-9" style="font-size: 11px; text-align: center">SPT Pembetulan Ke</label>
                        <input  style="width:20px; height: 20px; border: 1px solid;">
                    </div>
                </div>
            </div>
        </div>
        <b style="font-size: 10px;">PERHATIAN *SEBELUM MENGISI BACALAH PETUNJUK PENGISIAN *ISI DENGAN HURU CETAK/DIKETIK
            DENGAN TINTA HITAM *BERI TANDA X DALAM KOTAK SESUAI PILIHAN</b>
            <div class="col-sm-11.5" style=" border: 1px solid black; background-color: #F0E68C ; padding: 4px 20px 10px 10px ; height: 80PX; border: 2px solid; margin-left: 10px">
            <div class="row">
                <label class="col-sm-3 col-form-label" style="font-size: 14px;">NPWP</label>
                <div class="col-sm-9">
                    <input class="form-control" type="text" style="border: 1px solid black; height: 30px; border-radius: 1px; " placeholder="" >
                </div>
            </div>
            <div class="row">
                <label class="col-sm-3 col-form-label" style="font-size: 14px;">NAMA WAJIB PAJAK</label>
                <div class="col-sm-9">
                    <input class="form-control" type="text" style="border: 1px solid black; height: 30px; border-radius: 1px;" placeholder="" >
                </div>
            </div>
        </div>
        <p style="font-size: 11px; padding: 0px 0px -7px 0px">BAGIAN A. HARTA PADA AKHIR TAHUN</p>
        <button type="button">Import Data</button>

        <table id="mytable" class="display" style="width:100%">
            <tr>
                <th
                    style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; height: 30px">
                    KODE HARTA</th>
                <th
                    style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; ">
                    NAMA HARTA</th>
                <th
                    style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; ">
                    TAHUN PEROLEHAN</th>
                <th
                    style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; ">
                    HARGA PEROLEHAN</th>
                <th
                    style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; ">
                    KETERANGAN</th>
            </tr>
            <tr>
                <td><select name='harta' style="width:270px; height: 28px; border: 1px solid; margin-left: -1px;">
                        <option value='pilih'>Pilih...</option>
                        <option value='pilih'>011 - Uang Tunai</option>
                        <option value='pilih'>012 - Tabungan</option>
                        <option value='pilih'>013 - Giro</option>
                        <option value='pilih'>014 - Deposito</option>
                        <option value='pilih'>019 - Setara Kas Lainnya</option>
                        <option value='pilih'>021 - Piutang</option>
                        <option value='pilih'>022 - Piutang Afiliasi (Piutang kepada pihak yang mempunyai hubungan
                            istimewa sebagaimana dimaksud)</option>
                        <option value='pilih'>029 - Piutang Lainnya</option>
                        <option value='pilih'>031 - Saham Yang Dibeli Untuk Dijual Kembali</option>
                        <option value='pilih'>032 - Saham</option>
                        <option value='pilih'>033 - Obligasi Perusahaan</option>
                        <option value='pilih'>034 - Obligasi Pemerintah Indonesia (Obligasi Ritel Indonesia atau ORI,
                            surat berharga syariah negara, dll)</option>
                        <option value='pilih'>035 - Surat Utang Lainnya</option>
                        <option value='pilih'>036 - Reksadana</option>
                        <option value='pilih'>037 - Instrumen Derivatif (Right, Warran, Kontrak Berjangka, Opsi, dll)
                        </option>
                        <option value='pilih'>038 - Penyertaan Modal Perusahaan Lain Yang Tidak Atas Saham Meliputi
                            Penyertaan Modal Pada CV, Firma, dan Sejenisnya</option>
                        <option value='pilih'>039 - Investasi Lainnya</option>
                        <option value='pilih'>041 - Sepeda</option>
                        <option value='pilih'>042 - Sepeda Motor</option>
                        <option value='pilih'>043 - Mobil </option>
                        <option value='pilih'>049 - Alat Transportasi Lainnya</option>
                        <option value='pilih'>051 - Logam Mulia (Emas Batangan, Emas Perhiasan, Platina Batangan,
                            Platina Perhiasan, Logam Mulia Lainnya)</option>
                        <option value='pilih'>052 - Batu Mulia (Intan, Berlian. Batu Mulia Lainnya)</option>
                        <option value='pilih'>053 - Barang Seni dan Antik (Barang-Barang Seni, Barang-Barang Antik)
                        </option>
                        <option value='pilih'>054 - Kapal Pesiar, Pesawat Terbang, Helikopter,Jetski dan Peralatan
                            Olahraga Khusus</option>
                        <option value='pilih'>055 - Peralatan Elektronik dan Furnitur</option>
                        <option value='pilih'>059 - Harta Bergerak Lainnya</option>
                        <option value='pilih'>061 - Tanah dan/atau Bangunan Untuk Tempat Tinggal</option>
                        <option value='pilih'>062 - Tanah dan/atau Bangunan Untuk Usaha (Toko, Pabrik, Gudang, dan
                            Sejenisnya)</option>
                        <option value='pilih'>063 - Tanah atau Lahan Untuk Usaha (Lahan Pertanian, Perkebunan,
                            Perikanan Darat, dan Sejenisnya)</option>
                        <option value='pilih'>069 - Harta Tidak Bergerak Lainnya</option>
                    </select></td>
                <td><input type="text"
                        style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 101.5%; height: 30px; margin-left: -1.2px; margin-top: -2px;">
                </td>
                <td><input type="text"
                        style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 102%; height: 30px; margin-left: -1.5px; margin-top: -2px">
                </td>
                <td><input type="text"
                        style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 102%; height: 30px; margin-left: -1.5px; margin-top: -2px">
                </td>
                <td><input type="text"
                        style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 101.5%; height: 30px; margin-left: -1.5px; margin-top: -2px">
                </td>
            </tr>
        </table>
        <div style="padding: 10px;"></div>
        <table>
            <tr>
                <th
                    style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 670px;  height: 30px">
                    JUMLAH</th>
                <th
                    style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 400px">
                </th>
            </tr>
        </table>
        <button type="button" onclick="myFunction(this)">Tambah</button>
        <button type="button" onclick="deleteTable(this)">Hapus</button>
        <p style="font-size: 11px; padding: 10px 0px 0px 0px">BAGIAN B : KEWAJIBAN/UTANG PADA AKHIR TAHUN</p>
        <button type="button">Import Data</button>
        <table id="mytable2" class="display" style="width:100%">
            <tr>
                <th
                    style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 200px;  height: 30px">
                    KODE UTANG</th>
                <th
                    style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 200px">
                    NAMA PEMBERI PINJAMAN</th>
                <th
                    style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 200px">
                    ALAMAT PEMBERI PINJAMAN</th>
                <th
                    style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 200px">
                    TAHUN PEMINJAMAN</th>
                <th
                    style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 200px">
                    JUMLAH PINJAMAN</th>

            </tr>
            <tr>
                <td><select name='harta' style="width:270px; height: 28px; border: 1px solid; margin-left: -1px;">
                        <option value='pilih'>Pilih...</option>
                        <option value='pilih'>101 - Utang Bank/Lembaga Keuangan Bukan Bank (KPR, Leasing Kendaraan
                            Bermotor, dan sejenisnya)</option>
                        <option value='pilih'>102 - Utang Kartu Kredit</option>
                        <option value='pilih'>103 - Utang Afiliasi (Pinjaman dari pihak yang memiliki hubungan
                            istimewasebagaimana dimaksud dalam Pasal 18 ayat (4) Undang-UndangPPh)</option>
                        <option value='pilih'>109 - Utang Lainnya</option>
                    </select></td>
                <td><input type="text"
                        style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 102%; height: 30px; margin-left: -1.2px; margin-top: -2px;">
                </td>
                <td><input type="text"
                        style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 101.4%; height: 30px; margin-left: -1.5px; margin-top: -2px">
                </td>
                <td><input type="text"
                        style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 101.6%; height: 30px; margin-left: -2px; margin-top: -2px">
                </td>
                <td><input type="text"
                        style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 101.5%; height: 30px; margin-left: -2px; margin-top: -2px">
                </td>
            </tr>
        </table>
        <div style="padding: 10px;"></div>
        <table>
            <tr>
                <th
                    style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 670px;  height: 30px">
                    JUMLAH</th>
                <th
                    style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 400px">
                </th>
            </tr>
        </table>
        <button type="button" onclick="myFunction2(this)">Tambah</button>
        <button type="button" onclick="deleteTable2(this)">Hapus</button>
        <p style="font-size: 11px; padding: 10px 0px 0px 0px">BAGIAN C : DAFTAR SUSUNAN ANGGOTA KELUARGA</p>
        <button type="button">Import Data</button>
        <table id="mytable3" class="display" style="width:100%">
            <tr>
                <th
                    style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 200px;  height: 30px">
                    NAMA ANGGOTA KELUARGA</th>
                <th
                    style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 200px">
                    NIK</th>
                <th
                    style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 200px">
                    HUBUNGAN</th>
                <th
                    style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 200px">
                    PEKERJAAN</th>
            </tr>
            <tr>
                <td><input type="text"
                        style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 100.9%; height: 30px; margin-left: -1px; margin-top: -2px">
                </td>
                <td><input type="text"
                        style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 101.5%; height: 30px; margin-left: -2px; margin-top: -2px">
                </td>
                <td><input type="text"
                        style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 101%; height: 30px; margin-left: -1px; margin-top: -2px">
                </td>
                <td><input type="text"
                        style="border: 1px solid black; font-size: 12px; font-weight: bold; text-align: center; width: 101%; height: 30px; margin-left: -1px; margin-top: -2px">
                </td>
            </tr>
        </table>
        <button type="button" onclick="myFunction3(this)">Tambah</button>
        <button type="button" onclick="deleteTable3(this)">Hapus</button>
    </div>


    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
    </script>
    <script>
        let tr = 1;
        let tr2= 1;
        let tr3 = 1;
        function myFunction($this) {
            var tableBody = $('#mytable');
            trLast = tableBody.find("tr:last");
            trNew = trLast.clone();
            tr+=1;
            trLast.after(trNew);
        }

        function deleteTable($this) {
            var tableBody = $('#mytable');
            trLast = tableBody.find("tr:last");
            console.log(tableBody);
            if(tr > 1){
                trLast.remove();
            }
        }

        function myFunction2($this) {
            var tableBody = $('#mytable2');
            trLast = tableBody.find("tr:last");
            trNew = trLast.clone();
            console.log(tableBody);
            trLast.after(trNew);
        }

        function deleteTable2($this) {
            var tableBody = $('#mytable2');
            trLast = tableBody.find("tr:last");
            console.log(tableBody);
            if(tr > 1){
                trLast.remove();
            }
        }

        function myFunction3($this) {
            var tableBody = $('#mytable3');
            trLast = tableBody.find("tr:last");
            trNew = trLast.clone();
            console.log(tableBody);
            trLast.after(trNew);
        }

        function deleteTable3($this) {
            var tableBody = $('#mytable3');
            trLast = tableBody.find("tr:last");
            console.log(tableBody);
            if(tr > 1){
                trLast.remove();
            }
        }
    </script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"
        integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"
        integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous">
    </script>
    -->

</body>

</html>
<?php /**PATH C:\xampp\htdocs\E-Form\resources\views/formulirIV.blade.php ENDPATH**/ ?>