<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/boostrap3.3.6.min.css')); ?>" />

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">

    <title>Index</title>
    <style>
        .box {
            width: 800px;
            margin: 0 auto;
        }

        .bg-body {
            background-image: url("<?php echo e(asset('poltek4.jpeg')); ?>");
            background-size: cover;
            position: relative;
        }

        a {
            color: white;
            border-radius: 0px 25px 0px 25px;
            /* border:1px solid #ccc;
            border-radius: 25px;*/
        }

        .nav-item {
            background-color: rgb(255, 157, 49);
            /*border-radius: 10px 30px 0px 0px;*/
        }

        .grey-nav {
            background-color: #f5f5f5;
            border-radius: 0px 25px 0px 25px;
        }

        .jarak-nav {
            padding-left: 3px;
        }

        .panel-default {
            background-color: #f5f5f5;
            border-radius: 0px 0px 7px 7px;
        }

        .card_8 {
            width: 736px;
            height: 60px;
            padding-left: 12px;
            /*padding-right: 15px; */
            padding-top: 10px;
            background-color: rgb(255, 157, 49);
            border-radius: 7px;

        }
        
    </style>
</head>

<body class="bg-body">

    <br />

    <div class="container box">
        <br />
        <form>
            <div class="tab-content">
                <div class="tab-pane active" id="lapor_detail">
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <div class="card card_8 box-shadow">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-sm-9">
                                            <ul class="nav nav-tabs">
                                                <li class="nav-item grey-nav">
                                                    <a href="#" class="font-dark-blue">Arsip SPT</a>
                                                </li>
                                                <li class="nav-item">
                                                    <a href="#">Buat SPT</a>
                                                </li>
                                                <li class="nav-item jarak-nav">
                                                    <a href="#">Tata Cara Pelaporan</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <br />

        </form>
</body>

</html><?php /**PATH C:\xampp\htdocs\E-Form\resources\views/index1.blade.php ENDPATH**/ ?>