<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <style>
        @media only screen and (max-width: 600px) {}

        * {
            box-sizing: border-box;
        }

        .bg-grey {
            font-family: arial;
        }

        .header {
            border: 1px solid red;
            padding: 15px;
        }

        .row::after {
            content: "";
            clear: both;
            display: table;
        }

        [class*="col-"] {
            float: left;
            padding: 15px;
            border: 1px solid red;
        }

        .col-1 {
            width: 8.33%;
        }

        .col-2 {
            width: 16.66%;
        }

        .col-3 {
            width: 25%;
            text-align: center;
            border: 0px;
        }

        .col-3 h6 {
            font-size: 12px;
            text-align: center;
            margin-top: 20px
        }

        .col-4 {
            width: 33.33%;
        }

        .col-5 {
            width: 41.66%;
        }

        .col-6 {
            width: 50%;
            border-top: 0px;
            border: 0px;
        }

        .col-6 h6 {
            font-weight: bold;
            text-align: center;
            border-bottom: 1px solid black;
            border-left: 1px solid black;
            border-right: 1px solid black;
        }

        .col-6 p {
            font-size: ;
            font-weight: bold;
            text-align: center;
            border-bottom: 1px solid black;
            border-left: 1px solid black;
            border-right: 1px solid black;
        }

        .col-7 {
            width: 58.33%;
        }

        .col-8 {
            width: 66.66%;
        }

        .col-9 {
            width: 75%;
        }

        .col-10 {
            width: 83.33%;
        }

        .col-11 {
            width: 91.66%;
        }

        .col-12 {
            width: 100%;
        }

        @media only screen and (max-width: 768px) {

            /* For mobile phones: */
            [class*="col-"] {
                width: 100%;
            }

        }
    </style>
</head>

<body class="bg-grey">
    <div class="container " style="width : 90%; background-color: #fff;">

        <div class="col-3">
            <h2>FORMULIR</h2>
            <h3>1770-IV</h3>
            <h6>KEMENTERIAN KEUANGAN RI DIREKTORAT JENDERAL PAJAK</h6>
        </div>

        <div class="col-6">
            <h6>LAMPIRAN-IV
                </br>SPT TAHUNAN PPh WAJIB PAJAK ORANG PRIBADI</h6>
            <p>* HARTA PADA AKHIR TAHUN</p>
            <p>* KEWAJIBAN/UTANG PADA AKHIR TAHUN</p>
            <p>* DAFTAR SUSUNAN ANGGOTA KELUARGA</p>
        </div>

        <div class="col-3">
            <ul>
                <li>The Flight</li>
                <li>The City</li>
                <li>The Island</li>
                <li>The Food</li>
            </ul>
        </div>

    </div>
    
        </body>

        </html>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
<?php /**PATH C:\xampp\htdocs\E-Form\resources\views/tes.blade.php ENDPATH**/ ?>